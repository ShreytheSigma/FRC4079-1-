# Robot Code Review and Bring-Up

Reviewed October 10-11, 2026. This is a corrected copy of the supplied project, not a claim that the physical robot is calibrated or competition-ready.

## Start Here

**October 11 deployment revision:** original motor IDs, CAN buses, SystemCore target and active drivetrain constants remain intact. The original pivot ratio is restored as an unverified placeholder, not replaced with CAD gearing. Deployment now requires one explicitly confirmed controller address, with no discovery fallback. A disabled-only field-pose setup is now wired. Arm guards, button scheduling, drive response and intake-unit corrections still materially change operation; this is not a behavior-identical replacement. Read `ORIGINAL-COMPARISON.txt` in the competition kit.

**Simulator correction:** follow-up inspection found `hs_err_pid60419.log` from the kit's prior desktop session, recording a native SIGSEGV in `libhalsim_gui.dylib` / `NetworkTablesSimGui`. Startup succeeded, but stable GUI operation or clean shutdown was not established. The exact trigger is unconfirmed; passing automated tests does not supersede that failure.

- Full Gradle build: PASS, including Java/Kotlin compilation and application packaging.
- Regression and WPILib motor-physics tests: 75 PASS, 0 failures.
- No code was deployed to a robot. No physical CAN devices, encoders, wiring, licenses, or mechanisms were accessible.
- **Real intake pivot and hood position control require calibration and disabled homing.** Unknown limits are represented by `Double.NaN`, and cannot be sent as motor targets. Fill in the measured configuration described below.
- **Distance shooting/feeding requires explicit known field-pose initialization.** Boot zero, stale pose, or recovered-but-unreferenced odometry cannot authorize a shot. See the localization section below.
- The original ZIP in Downloads was not modified.
- CAD follow-up: inspected the user's `SK robot copy` Onshape assembly without modifying CAD geometry, mates, configurations, or features. See the CAD findings below before deployment.
- Final priority: **SystemCore and code-defined motors take precedence over CAD materials.** The swerve simulation uses the supplied code's X60 model for both drive and steering. No roboRIO port was made.

## Final Checklist

- [x] Preserve the SystemCore deployment target, original CAN mapping, motor assumptions and vendor stack.
- [x] Correct controller bindings, swerve speed/angle behavior and steering/drive coupling.
- [x] Stop the drivetrain for missing/nonfinite feedback; latch swerve device resets or rejected control requests until robot-code restart.
- [x] Correct intake units and refresh both motors; gate real intake, shooter and feeder outputs on configuration/connection health.
- [x] Keep unknown arm motion guarded; prevent an unhomed hood from enabling the feeder.
- [x] Inspect only SK robot copy for additional arm-limit evidence without editing CAD.
- [x] Compile, package and pass all 75 regression/physics tests.
- [x] Fix Java 25 desktop launch flags. Keep the previously crashing native GUI optional; the kit simulator defaults to headless mode.
- [x] Pin deployment to one confirmed private IPv4 address and reject missing addresses/confirmation before discovery.
- [x] Add disabled-only measured field-pose setup and original hardware compatibility tests.
- [x] Include basic auto plus closed-loop 1.5 m taxi and a two-leg test path; keep Do Nothing as default.
- [x] Independent critic review of drivetrain and mechanisms, followed by targeted fixes and regression tests.
- [x] Reject unaccepted hood/shooter requests as feed-ready; check feeder interlocks after the scheduler.
- [ ] On robot: verify CAN IDs, Pro licenses, firmware, encoder offsets, module directions and active torque gains.
- [ ] On robot: map CAD arm angles to physical home/encoder direction, check clearance and configure verified limits before allowing pivot/hood movement.
- [ ] On robot: characterize shooter/hood lookup values and roller surface directions before collecting or firing balls.

The later user request authorized advanced auto and additional critic review. The `auto/advanced` subfolder now contains bounded, profiled relative-waypoint driving using WPILib motion profiles and odometry. AI recognition and automated scoring remain unimplemented because camera, arm and shooting calibration are unavailable. No physical robot was driven or certified by this review.

The uploaded sources exactly matched public `FRC4079/Rebuilt-2026-Offseason` commit `f920784a8ae088b8b14f38fc2ecf377f4df2e351`. The matching organization is FRC4079, rather than FRC409. Its season repository uses Malefix; this offseason project uses direct Phoenix calls and does not depend on Malefix. The season robot has different module ratios, so its constants were not copied into this robot.

## CAD Follow-Up: SK robot copy

Inspected [SK robot copy](https://cad.onshape.com/documents/ec60224c0368f3748aa4e618/w/f53540448bb01cb84392c3d5/e/f8972e398bb4f0b6c875e71f) as the user's designated hardware reference. Its QuantumARC/10183 labeling was not used to reject the user's confirmation. Inspection used the assembly tree, component selection and temporary isolation; no CAD design edits were made. The tab already exposed editing tools when inspection resumed; no Edit-mode button was clicked.

### CAD Evidence Versus Active Code

- **Intake pivot reduction:** the selected parts show an 8-tooth pinion driving a 48-tooth gear; a coaxial 26-tooth gear drives a 60-tooth gear; the output's 16-tooth sprocket drives the pivot's 36-tooth sprocket. The inferred reduction is `(48/8) * (60/26) * (36/16) = 405/13 = 31.153846:1`. This is reference evidence ONLY. The final revision restores the original code's `PIVOT_GEAR_RATIO = 1.0` to honor code-over-CAD priority. Neither value is verified on the built robot. Measure the actual transmission before entering limits and allowing movement.
- **Swerve motor model:** CAD shows an X44 steering motor, but the user's final instruction makes code authoritative. The earlier CAD-based X44 simulation change has been reverted to the supplied code's X60 model. Assumed inertias and simulation-only controller gains are still not hardware characterization.

### Values deliberately not guessed

- SDS identifies MK5n steering reduction as `287/11`, matching the code. Its published R1 drive stages are `54/12 * 25/32 * 30/15 = 7.03125`, also matching the code. The inspected CAD instance did not establish which motor pinion is installed on the physical robot; verify R1 rather than assuming the module model alone proves it. Keep the coupling ratio tied to the verified drive gearing.
- The MK5n has mirrored A/B layouts. Confirm each physical corner, steering direction and CANcoder direction. Do not infer correct software inversion from the assembly name alone.
- **New mate-limit evidence:** filtering SK robot copy by `:matelimits` showed intake `Revolute 2`, intake `Revolute 8`, and Shooter `Revolute 1`. Their untouched Animate dialogs showed ranges of **-120.289 to 0 degrees**, **0 to 0 degrees**, and **-40 to 0 degrees**, respectively. No animation was played and no limit position was applied. Onshape documents that mate limits populate these fields. These are CAD mate-coordinate ranges, not confirmed motor targets. The relationship to physical stow/home, encoder direction, and ball-shooting hood angles remains unverified. Keep the calibration guards until those mappings and clearance margins are measured; do not paste negative CAD values into a positive-angle shot lookup.
- The intake includes other pulleys, sprockets and multiple motors, but their CAN-ID mapping and complete roller drive paths were not established. Roller gearing/directions were not changed on the strength of part names alone.
- **Controller authority resolved:** CAD contains a roboRIO model, but the user explicitly confirmed **SystemCore**. The original SystemCore target and 2027 alpha WPILib stack are retained; the CAD electronics model does not override them.
- CAD cannot establish Phoenix Pro entitlement, live CAN connections, actual firmware, encoder magnet offsets, damage, or binding under load.

Sources: [SDS MK5n specifications](https://www.swervedrivespecialties.com/products/mk5n-swerve-module), [manufacturer drive-stage chart](https://cdn.shopify.com/s/files/1/0065/4308/1590/files/MK5n_Gear_Ratios_eddd1a62-7d51-432c-ba53-38352d5b2337.png?v=1747249162), and [Onshape mate animation/limit documentation](https://cad.onshape.com/help/Content/Assembly/mates.htm).

## Confirmed Problems Corrected

| Area | Original problem | Change |
| --- | --- | --- |
| Buttons | Kotlin `.run { ... }` executed at construction. A/X/Y commands were created but never scheduled; B reset the gyro at startup. | Real Commands v3 triggers; held commands cancel on release; controls limited to enabled teleop. |
| Driving command | `PadDrive.run()` returned after one execution, relying on default-command restarts and lacking cancellation cleanup. | Continuous coroutine with yielding and a stop on cancellation. |
| Stick response | Translation jumped directly from zero to about 0.66 m/s at the deadband boundary. Diagonal input exceeded the nominal maximum. | Rescaled radial deadband and bounded translation magnitude; rotation deadband rescaled too. |
| Swerve saturation | Combined translation and rotation could request wheel speeds above the configured maximum. | Desaturation preserves relative wheel speeds and limits the fastest wheel to 4.39 m/s. |
| Steering at rest | Zero-speed states could change steering direction; steering control was switched off near its target. | Hold the previous commanded angle at zero speed and retain closed-loop steering at its target. |
| Steering initialization | Fused feedback was configured before the CANcoder calibration, then manually reseeded without checking the absolute read. | Configure CANcoder first and let fused feedback establish its reference. |
| Steering/drive coupling | The exported coupling ratio was unused, so steering-induced motor rotation counted as wheel travel. | Compensate measured drive position/velocity and commanded drive velocity using the existing coupling ratio and continuous azimuth. |
| Swerve faults | Configuration retries silently failed; no Pro/fusion diagnosis, and missing encoder data could still be used to command motors. | Configuration results, Pro status, fusion fault alerts, and control status logs. A missing/invalid module stops the drivetrain. |
| Configuration writes | PID/brake updates reapplied the entire Talon configuration, including feedback settings; many asynchronous workers could race. | Apply only the relevant configuration group; serialize each module's brake updates. |
| Driver heading | Resetting the physical gyro also changed the heading seen by odometry and aiming. | Separate driver heading offset. Wheel odometry supplies heading during gyro loss; reconnection preserves heading continuity. |
| Intake units | 600 rad/s was passed to Phoenix as 600 rotations/s: 36,000 RPM instead of about 5,730 RPM. Position and measured velocity also used inconsistent units. | Convert mechanism radians to Phoenix rotations at the IO boundary and measurements back to radians. |
| Intake diagnostics | Stored signals were not refreshed and only the left motor's measurements were visible. | Refresh both motors; independent connection flags, positions, velocities, voltages, currents, configuration results and request statuses. |
| Intake inversion | Both motors shared a configuration with implicit direction. | Separate named left/right inversion parameters. Existing directions retained until physical direction is verified. PID-only updates preserve them. |
| Pivot | `DEPLOY(10.0)` requested ten mechanism revolutions with a 1:1 ratio, with no measured limits or reference. Boot zeroing assumed the arm's physical position. | Explicit mechanism-radian targets, measured-limit configuration, disabled manual homing and soft limits. Unknown geometry blocks position output and raises an alert. |
| Hood reference | The hood was also blindly zeroed at every startup without knowing its physical position. | Calibrated limits and disabled homing required before position control; rejected out-of-range commands stop output. |
| Pivot/transport telemetry | Angular velocity was populated from supply current. Cached transport signals were not correctly refreshed. | Read actual angular velocity and refresh all used signals. |
| Shooter/hood control | `disable()` or manual power could be overwritten by the following periodic closed-loop/state request. Shooter `setState()` did not set a state. | Explicit target ownership; disabling clears the target; manual power clears position/velocity control; shooter state uses its proper enum. |
| Hood power | A documented duty-cycle request was interpreted as volts. | Use a bounded duty-cycle request consistently with simulation. |
| Feeder | Stop IO was unimplemented and the feeder had no controller binding. | Implement motor stop and right-bumper feeding, gated by both flywheel speeds and hood position. |
| Control ramp | Voltage-controlled mechanisms configured a torque-current ramp, which did not affect their active request type. | Configure the voltage closed-loop ramp. |
| Autonomous | With no autonomous command selected, `!!` caused a null-pointer exception. | Safe Do Nothing default plus an optional short Drive Forward and Stop routine in its own folder. |
| Periodic ordering | Odometry and commands used the previous cycle's sensor data. | Update swerve inputs and odometry before running commands; add explicit disabled cleanup. |
| Aiming | Both hub poses were `(0, 0)`; alignment compared field heading to raw gyro heading and did not stop on natural completion. | Derive both hub centers from WPILib's welded 2026 field tags using the blue origin; compare consistent pose headings and stop on completion. |
| Shot validity | An invalid shot left the previous output active; distances outside the lookup range silently used endpoint shots. | Invalid or out-of-range distance stops shooter/hood and clears shoot state. |
| Gyro/logging | Gyro data was not passed to Logger, immutable gyro fields were skipped by the reflection logger, enum states were skipped, and pitch/roll rate axes were swapped. | Log gyro inputs, use mutable replay fields, serialize enum names, correct axes. |
| Camera geometry | A Rotation3d constructor received `180.0` radians for the intended 180-degree roll. | Use `Math.PI`. Verify the actual camera mounting axes separately. |
| Simulation | RobotContainer always created real devices. Desktop execution forced replay. Intake physics used zero inertia, zero volts, zero timestep; pivot simulation teleported its angle. | Separate real/sim/replay IO, repair mechanism physics and controls, add simulated swerve modules and gyro fallback. |
| Build tests | Annotation-processing preview flags were passed as processor options; test processing could not read Java 25 preview classes. | Correct javac preview options and test JVM flags. |
| Desktop launch | `gradlew run` failed because Java 25 preview features were not enabled, despite tests passing. | Share the required JVM flags across deployment, application scripts, tests and GradleRIO's explicit run task. Actual startup was verified. |
| Hood readiness | A target just outside a calibrated travel limit could still be within the readiness tolerance, despite hardware rejecting it. | Synchronous request acceptance required; rejection stops output, clears the target and removes readiness. Real and simulated hood share the same homing/limit guard. |
| Arm request faults | Position-control status was discarded. | Log/check hood and pivot request status, stop on failure; pivot revokes homing. Nonfinite feedback cannot authorize arm control. |
| Shooter readiness | Coasting flywheels could meet the speed tolerance after a rejected velocity request. | Both hardware requests must be accepted before readiness is true. |
| Localization | Shooting could use a frozen pose indefinitely after feedback loss, or treat boot zero as a known field position. | Explicit pose initialization and fresh healthy odometry required. Feedback loss or clock gaps revoke initialization. |
| Pose setup | The previous repair required pose initialization but exposed no operator workflow. | Enter measured pose in setup tunables and confirm with disabled Menu+B. Entries are validated and consumed; Limelight receives the field-frame heading. |
| Aiming deadband | The unused alignment helper could stall indefinitely at a small angle error. | Clear the module speed threshold with a bounded rotation request; stop at tolerance, on disable/fault, or after five seconds. It remains unbound. |
| Deployment identity | GradleRIO could try team, USB, Driver Station and generic hostname endpoints. | Remove all fallbacks and require an explicitly verified IPv4 address and confirmation before discovery. Address pinning does not authenticate the physical controller. |
| Feeder ordering | A newer feeder command could observe an older shot target before the shooting command invalidated it. | Read sensors first, run the scheduler, then recheck the complete interlock immediately before feeder output. |

## What the Reported Symptoms Still Require

### Swerve: wrong directions, erratic steering, grinding

The software issues above can contribute to poor control. They do not prove the cause of the grinding or establish that the configured offsets, ratios, and inversions match the hardware.

1. Support the robot with wheels clear of the floor. Inspect the noisy module's gears, shaft, bearings and wiring before commanding it again.
2. Confirm the CAN bus, IDs and physical corner mapping below in Phoenix Tuner. Operate one device at a time at low output, with someone ready to disable. A swapped steer/drive ID or corner is not detectable from this ZIP alone.
3. Point all wheels physically forward and inspect each CANcoder angle after its configured magnet offset. Each should read near zero with the same direction convention. Recalibrate offsets from the robot; do not guess their sign or reuse another robot's offsets.
4. Check that positive steering moves toward increasing azimuth and that the integrated/fused angle follows the absolute angle through a full revolution without jumping. Verify the motor-to-azimuth ratio is actually `287/11`, not the older season robot's ratio.
5. Check forward drive and measured wheel velocity sign on each corner, with the module facing forward. Only then test forward, strafe, and slow rotation.
6. Inspect `Swerve/Hardware/<drive ID>/Configured`, `ProLicensed`, `DriveControlStatus`, `SteerControlStatus` and alerts. Torque-current steering/drive requests require the correct licenses and compatible device firmware.
7. Tune steering gains in the active torque-current units. The original active gains are P=45, D=2 for steering and P=100 for drive. They are not the voltage gains in the commented-out Tuner export. This review does not claim those gains are tuned correctly.

All four wheels should agree for straight translation. Their angles and speeds intentionally differ during rotation. That is normal swerve kinematics.

**Coupling calibration:** Drive position and velocity now subtract steering-induced motion, and velocity demands include the corresponding compensation. This uses the existing exported `COUPLE_RATIO = 4.5` divided by drive reduction `7.03125`, with continuous azimuth rather than a wrapped angle. Confirm the ratio's magnitude and sign against the actual module and configured sensor directions before driving. The tests validate the compensation math, not that this exported hardware value is correct.

Odometry currently uses 50 Hz samples. The unused 250 Hz setting/thread is not evidence of working 250 Hz odometry. High-rate synchronized sampling and hardware latency have not been validated.

### Intake rollers: balls not entering

The configured devices are left CAN **14** and right CAN **41**, on **CAN_S1**. ID 41 is present in the supplied source; it is not assumed to be a typo. Both current limits are 40 A and the configured ratio is 1:1.

- Verify both devices appear on CAN_S1 with those exact IDs. Compare left/right connected flags and control statuses before diagnosing gearing.
- Inspect `Intake/Data/IntakeVelocityRadPerSec` and `RightVelocityRadPerSec`, each motor's voltage and current. High current with little motion suggests load/binding; missing data suggests power/CAN/configuration. These are diagnostic clues, not proof.
- Check the **surface direction where the rollers contact the ball**, not simply whether both shafts turn clockwise. The source cannot establish which way the second motor should be inverted. Adjust `IntakeParameters.LEFT_INVERTED` or `RIGHT_INVERTED` only after observing the hardware.
- The fixed command retains 600 rad/s as the requested mechanism speed. Tune that target and the ratio for your actual roller diameter, compression, gearing, and current draw. Correct units alone do not guarantee good ball handling.

### Intake deployment and hood

No dedicated pivot/hood absolute encoder or home switch is configured in this project. This does not prove that the robot lacks one; it means the code provides no trustworthy reference for it.

In `src/main/java/frc/robot/utils/RobotParameters.kt`, measure and set:

| Mechanism | Required values |
| --- | --- |
| Intake pivot | `PIVOT_GEAR_RATIO`, `STOW_ANGLE_RAD`, `DEPLOY_ANGLE_RAD`, `MIN_ANGLE_RAD`, `MAX_ANGLE_RAD` |
| Hood | `HOOD_GEAR_RATIO`, `HOME_ANGLE_RAD`, `MIN_ANGLE_RAD`, `MAX_ANGLE_RAD` |

Gear ratio means motor revolutions per mechanism revolution. The pivot's original 1:1 code value is retained but UNVERIFIED; do not treat it as calibration. CAD suggests a different ratio but is not authoritative over the actual robot. Measure before enabling. Angles are mechanism radians. Use a consistent physical zero and positive direction. Keep limits within the actual mechanical stops. Do not enter arbitrary numbers to bypass the calibration check. The original gains remain unvalidated. After deliberate calibration changes, update tests that explicitly assert this uncalibrated release configuration, and add tests for the measured limits; do not disable the test suite to deploy.

After calibration, on every boot or motor reset:

1. Physically place the intake at the calibrated stow position, keep the robot disabled, and press **Menu + View** to confirm its reference.
2. Physically place the hood at the calibrated home position, keep the robot disabled, and press **Menu + X** to confirm its reference.
3. Verify the corresponding homing alert clears before enabling position commands.

These actions only establish an encoder reference; they do not move or automatically home either mechanism. If an actual absolute sensor or limit switch exists, wire its real device/channel into the code and replace manual confirmation with sensor-based homing. Gravity feedforward, appropriate motion profiling, gains and real mechanical limits still need characterization.

## Controls

| Control | Behavior |
| --- | --- |
| Left stick | Field-oriented translation with radial deadband |
| Right stick X | Rotation at the existing half-scale maximum |
| Hold A | Run intake rollers; release stops them |
| Press B | Zero driver-relative heading, leaving field odometry unchanged |
| Hold Y | Deploy the calibrated, homed intake; release requests stow |
| Hold X | Spin shooter and aim hood for a valid 1.5-3.5 m lookup distance |
| Hold right bumper | Feed only while both flywheels are at speed and hood is at its requested angle |
| Disabled Menu + View | Confirm intake physically at calibrated stow |
| Disabled Menu + X | Confirm hood physically at calibrated home |
| Disabled Menu + B | Apply newly entered measured field pose while stationary |

Disabling clears motor targets and stops outputs. Feed readiness is a software condition; it cannot validate a wrongly calibrated hood or establish that a ball will hit the hub.

## Hardware Map from the ZIP

| Device | Bus | CAN ID |
| --- | --- | --- |
| Front-left steer / drive / encoder | CAN_S0 | 1 / 2 / 9 |
| Front-right steer / drive / encoder | CAN_S0 | 3 / 4 / 10 |
| Back-left steer / drive / encoder | CAN_S0 | 5 / 6 / 11 |
| Back-right steer / drive / encoder | CAN_S0 | 7 / 8 / 12 |
| Pigeon 2 | CAN_S0 | 13 |
| Intake left / right | CAN_S1 | 14 / 41 |
| Intake pivot | CAN_S1 | 15 |
| Shooter left / right | CAN_S1 | 16 / 17 |
| Indexer / hopper | CAN_S1 | 18 / 19 |
| Hood | CAN_S1 | 20 |
| REV power distribution | CAN_D0 | 1 |

No duplicate IDs exist within the configured motor buses. This table describes source configuration, not a live device scan.

## Build and Simulation

This is a **SystemCore / WPILib 2027.0.0-alpha-7 / Java 25** project, using Phoenix 26.70.0-alpha-2, Commands v3, Kotlin 2.4.10 and Gradle 9.4.1. It is not a standard 2026 roboRIO project. Preserve the matching software and firmware stack.

With a Java 25 JDK available:

```sh
./gradlew build
./gradlew test
./gradlew run -PheadlessSim=true
```

On Windows use `gradlew.bat`. Desktop execution selects simulated IO; real hardware selects real IO. Set `ROBOT_REPLAY=true` only when intentionally replaying an AdvantageKit log. The default simulator no longer requires a replay log.

Executed here: `gradlew build`, including 75 tests using the project's real WPILib math, Commands v3 scheduler, HAL/driver-station simulation, and DCMotorSim. Coverage includes straight/strafe/turn physics with code-defined X60 models, unknown-target rejection, coupling, desaturation, steering optimization, controller bindings, cancellation/disable, invalid feedback, motor stop persistence, shot lookup, and timed/closed-loop auto. Safety tests cover request acceptance, homing/reset/limits in the hood simulator, stale/uninitialized localization, same-cycle feeder interlocks, profiled auto distance and two-leg travel, motion bounds, loss of Driver Station, odometry jumps, no-progress detection, timeouts, infeasible-route rejection, and small heading-error correction across the module deadband. The final revision adds original CAN/geometry/gain compatibility assertions, the actual disabled Menu+B pose workflow, entry consumption, and small-angle aiming convergence/timeout tests.

This was **automated WPILib physics simulation**, not a full 3D field/ball-contact simulation or hardware-attached Phoenix test. The model uses assumed inertias and does not model real traction, backlash, electrical faults, fused-CANcoder firmware, ball compression, or the unidentified arm geometry. The proprietary Phoenix hardware path was compiled, but was not executed against motors. There are no physical wiring, license, or calibration results to report.

The additional desktop smoke check reached `Robot program startup complete`, opened the simulator GUI, and ran until manually interrupted. Its first cycle reported a loop-time overrun; no further output appeared during the follow-up observation. That is a startup check, not proof of real-time performance on SystemCore. A first-run missing `networktables.json` notice is expected when no persistent values have been saved. In this alpha toolchain, `simulateJava` prepares the external simulator launch configuration; `gradlew run` was used to execute the actual desktop program.

The final kit's revised `3-SIMULATE.command` was then tested without GUI extensions. It reached startup complete, remained disabled, and was manually interrupted; no new native crash report appeared. It also reported an initial loop overrun. This short headless smoke check avoids the previously crashing GUI library, but is not a GUI fix or hardware timing validation.

## Localization Before Shooting

The distance shooter and feeder now refuse an uninitialized or stale field pose. `Swerve/FieldPoseInitialized` and `Shoot/PoseReady` explain the guard. The software cannot learn an arbitrary field starting position from boot zero or from the existing one-meter vision filter.

With the robot disabled and stationary, enter the robot-center position in the matching WPILib dashboard's NetworkTables tunables:

- `/Tunables/Setup/FieldPose/XMeters`: measured blue-origin X in meters.
- `/Tunables/Setup/FieldPose/YMeters`: measured blue-origin Y in meters.
- `/Tunables/Setup/FieldPose/HeadingDegrees`: field heading in [-180, 180], with 0 along blue-origin +X and +90 along +Y. Do not alliance-mirror these values.

Then press **Menu + B** on Xbox port 0. Check `Setup/FieldPose/Result` in the AdvantageKit log/dashboard and `Swerve/FieldPoseInitialized` / `Shoot/PoseReady`. Editing the dashboard alone does not reset the pose. Missing/nonfinite/out-of-field values, moving wheels, unhealthy feedback, or enabled mode reject the confirmation. A successful entry is cleared to NaN to prevent blindly reusing stale coordinates. This calls `odometrySupplier.resetPose(knownPose)`; it does not move the robot, home arms, validate cameras, or change driver-relative heading. The relative autos do not need this global pose and do not establish it for shooting.

Missing drivetrain feedback, nonfinite values or an update gap over 0.1 seconds invalidate the reference. Recovery alone does not reauthorize shooting; explicitly reinitialize from a known pose. Accepted vision observations refine an already initialized pose. The lookup and hood calibration still must be validated independently.

## Deployment Kit

The adjacent `COMPETITION_READY` folder is an uncompressed, ready-to-open Apple Silicon Mac kit with source, bundled Java 25, Gradle, cached dependencies, check/deploy/simulate launchers, and a precompiled dependency bundle. Read its `START-HERE.txt`. The launcher uses the original GradleRIO SystemCore target and team 4079. It requires a verified private IPv4 address and typing `DEPLOY 4079@<that-address>`. It never tries `robot.local`, Driver Station discovery or another USB/team address. Confirm the actual controller identity yourself: IP pinning is not authentication. It does not image the controller or update firmware. A single JAR copied to the robot is not a complete installation because native libraries and runtime arguments are also required.

For a different machine with the matching toolchain, first run `gradlew verifyDeploymentTarget -ProbotAddress=<verified-ip>` without contacting the robot. The deployment command is `gradlew deploy -ProbotAddress=<verified-ip> -PconfirmRobot=4079@<verified-ip>` only after confirming the controller and keeping it disabled. Plain `gradlew deploy` is intentionally rejected before discovery. Use real values, not the angle-bracket placeholders. No default IP is supplied as an assumed physical identity.

`prepareRobotBundle` stages the release classpath and SystemCore native archives without contacting hardware. The launcher's deployment task graph has been validated with `--dry-run`, which skips discovery, transfer and restart. Actual deployment and on-controller startup remain untested because no robot is connected.

## Other Remaining Work

- Measure and validate the shot lookup RPM/hood angles, both shooter directions, speed tolerance and feeder speed. The supplied lookup data was retained, not experimentally certified.
- Use the correct welded/AndyMark field layout for the venue. The new hub lookup explicitly selects the welded layout.
- Initialize the robot's field pose before distance-based shooting as described below. Vision camera transforms still require on-robot validation.
- Basic and relative-waypoint autos are implemented and tested. Field-obstacle pathfinding, passing, LED behavior and ball recognition remain outside the completed core-control scope; original empty/stub features are not represented as finished functionality.
- Supply/stator current limits, drive/steer gains, wheel radius and gear ratios remain hardware values that must be checked. Malefix and the older team's templates are useful references, not replacements for those measurements.

## Sources Inspected

See also [WPILib motion profiles](https://docs.wpilib.org/en/stable/docs/software/advanced-controls/controllers/trapezoidal-profiles.html) for the advanced auto's profile primitive.

- [Exact offseason commit](https://github.com/FRC4079/Rebuilt-2026-Offseason/tree/f920784a8ae088b8b14f38fc2ecf377f4df2e351)
- [FRC4079 season repository](https://github.com/FRC4079/Rebuilt-2026)
- [Malefix motor wrapper](https://github.com/OmyDaGreat/Malefix/blob/main/src/main/kotlin/xyz/malefic/frc/pingu/motor/talonfx/TonguFX.kt)
- [Pinned Commands v3 API](https://github.com/wpilibsuite/allwpilib/tree/v2027.0.0-alpha-7/commandsv3/src/main/java/org/wpilib/command3)
- [Pinned WPILib wheel desaturation implementation](https://github.com/wpilibsuite/allwpilib/blob/v2027.0.0-alpha-7/wpimath/src/main/java/org/wpilib/math/kinematics/SwerveDriveKinematics.java)
- [Phoenix closed-loop units, output types and tuning](https://v6.docs.ctr-electronics.com/en/stable/docs/api-reference/device-specific/talonfx/closed-loop-requests.html)
- [Phoenix remote/fused sensor configuration](https://v6.docs.ctr-electronics.com/en/stable/docs/api-reference/device-specific/talonfx/remote-sensors.html)
- [Phoenix swerve drivetrain validation](https://v6.docs.ctr-electronics.com/en/stable/docs/tuner/tuner-swerve/validating-drivetrain.html)
- [Exact Phoenix alpha source archive](https://maven.ctr-electronics.com/release/com/ctre/phoenix6/wpiapi-java/26.70.0-alpha-2/wpiapi-java-26.70.0-alpha-2-sources.jar)
- [WPILib 2026 welded field data](https://github.com/wpilibsuite/allwpilib/blob/v2027.0.0-alpha-7/fields/src/main/native/resources/org/wpilib/fields/frc/2026-rebuilt-welded.json)

## Astra Setting

Extra High is my recommendation for this broad debugging/review task when time and usage are acceptable. High is a reasonable setting for subsequent focused changes. Higher effort is not proof of correctness; the build, tests and robot measurements are the evidence. [Official reasoning-effort guidance](https://developers.openai.com/api/docs/guides/reasoning).
