package frc.robot

import frc.robot.mechanisms.Vision
import frc.robot.mechanisms.OdometrySupplier
import frc.robot.mechanisms.drive.Swerve
import frc.robot.mechanisms.drive.gyro.GyroIO
import frc.robot.mechanisms.drive.module.ModuleIO
import frc.robot.mechanisms.drive.module.SimModuleIO
import frc.robot.mechanisms.intake.IntakeIO
import frc.robot.mechanisms.intake.SimIntakeIO
import frc.robot.mechanisms.pivot.PivotIO
import frc.robot.mechanisms.pivot.SimPivotIO
import frc.robot.mechanisms.shooter.ShooterIO
import frc.robot.mechanisms.shooter.SimShooterIO
import frc.robot.mechanisms.transport.TransportIO
import frc.robot.mechanisms.transport.SimsTransportIO
import frc.robot.utils.RobotParameters
import org.junit.jupiter.api.Assertions.*
import org.junit.jupiter.api.BeforeAll
import org.junit.jupiter.api.BeforeEach
import org.wpilib.simulation.AlertSim
import org.junit.jupiter.api.Test
import org.wpilib.command3.Scheduler
import org.wpilib.hardware.hal.HAL
import org.wpilib.hardware.hal.RobotMode
import org.wpilib.simulation.DriverStationSim
import org.wpilib.simulation.XboxControllerSim
import org.wpilib.tunable.MockTunableBackend
import org.wpilib.tunable.TunableRegistry
import kotlin.math.abs

class PhysicsSimulationTest {
    @BeforeEach fun resetAlerts() { AlertSim.resetData() }
    companion object {
        @JvmStatic @BeforeAll fun initialize() { HAL.initialize() }
    }

    @Test fun `original pivot ratio is retained without pretending it is calibrated`() {
        assertEquals(1.0, RobotParameters.PivotParameters.PIVOT_GEAR_RATIO)
        assertFalse(RobotParameters.PivotParameters.positionCalibrated)
    }

    @Test fun `unknown pivot deploy angle never produces simulated output`() {
        val io = SimPivotIO()
        val inputs = PivotIO.PivotIOInputs()
        assertFalse(RobotParameters.PivotParameters.positionCalibrated)
        io.setPivotPosition(PivotIO.PivotState.DEPLOY)
        repeat(100) { io.updateInputs(inputs) }
        assertEquals(0.0, inputs.data.pivotAppliedVolts)
        assertEquals(0.0, inputs.data.pivotPositionRad)
        assertTrue(inputs.data.pivotVelocityRadPerSec.isFinite())
    }

    @Test fun `intake physics advances in voltage and velocity modes and stops`() {
        val io = SimIntakeIO()
        val inputs = IntakeIO.IntakeIOInputs()
        io.setVoltage(6.0)
        repeat(100) { io.updateInputs(inputs) }
        assertTrue(inputs.data.intakePositionRad > 0.0)
        assertTrue(inputs.data.intakeVelocityRadPerSec > 0.0)
        assertEquals(6.0, inputs.data.intakeAppliedVolts)
        io.setVelocity(100.0)
        repeat(200) { io.updateInputs(inputs) }
        assertEquals(100.0, inputs.data.intakeVelocityRadPerSec, 10.0)
        val speedBeforeStop = inputs.data.intakeVelocityRadPerSec
        io.stop()
        repeat(100) { io.updateInputs(inputs) }
        assertEquals(0.0, inputs.data.intakeAppliedVolts)
        assertTrue(abs(inputs.data.intakeVelocityRadPerSec) < speedBeforeStop / 2.0)
    }

    @Test fun `shooter accelerates to requested speed and stop removes voltage`() {
        val io = SimShooterIO()
        val inputs = ShooterIO.ShooterIOInputs()
        io.setVelocity(300.0)
        repeat(250) { io.updateInputs(inputs) }
        assertEquals(300.0, inputs.data.topVelocityRadPerSec, 15.0)
        assertEquals(inputs.data.topVelocityRadPerSec, inputs.data.bottomVelocityRadPerSec, 1e-9)
        io.disablePower()
        io.updateInputs(inputs)
        assertEquals(0.0, inputs.data.topAppliedVolts)
        assertEquals(0.0, inputs.data.bottomAppliedVolts)
    }

    @Test fun `transport real and simulated state use the same radians per second`() {
        val io = SimsTransportIO()
        val inputs = TransportIO.TransportIOInputs()
        io.setTransportState(TransportIO.TransportState.ACTIVE)
        repeat(250) { io.updateInputs(inputs) }
        assertEquals(2.0 * Math.PI, inputs.data.hopperVelocityRadPerSec, 0.5)
        assertEquals(2.0 * Math.PI, inputs.data.indexerVelocityRadPerSec, 0.5)
        io.disablePower()
        io.updateInputs(inputs)
        assertEquals(0.0, inputs.data.hopperAppliedVolts)
        assertEquals(0.0, inputs.data.indexerAppliedVolts)
    }

    @Test fun `four simulated modules drive forward strafe and rotate with odometry`() {
        val swerve = Swerve(Array<ModuleIO>(4) { SimModuleIO() }, object : GyroIO {})
        val odometry = OdometrySupplier(swerve, Vision(emptyArray()))
        swerve.periodic()
        repeat(150) {
            swerve.setDriveSpeeds(1.0, 0.0, 0.0, false)
            swerve.periodic()
            odometry.periodic()
        }
        assertEquals(1.0, swerve.autoSpeeds.vx, 0.1)
        assertTrue(odometry.pose.x > 2.5)
        assertEquals(0.0, odometry.pose.y, 0.1)
        repeat(150) {
            swerve.setDriveSpeeds(0.0, 1.0, 0.0, false)
            swerve.periodic()
            odometry.periodic()
        }
        assertEquals(1.0, swerve.autoSpeeds.vy, 0.1)
        assertTrue(odometry.pose.y > 2.0)
        repeat(100) {
            swerve.setDriveSpeeds(0.0, 0.0, 1.0, false)
            swerve.periodic()
            odometry.periodic()
        }
        assertEquals(1.0, swerve.autoSpeeds.omega, 0.15)
        assertTrue(abs(swerve.gyroYaw.radians) > 0.5)
        swerve.stop()
        repeat(100) { swerve.periodic() }
        assertEquals(0.0, swerve.autoSpeeds.vx, 0.05)
        assertEquals(0.0, swerve.autoSpeeds.omega, 0.05)
    }

    @Test fun `actual controller bindings start and cancel intake and stay inactive while disabled`() {
        TunableRegistry.reset()
        TunableRegistry.registerBackend("/", MockTunableBackend())
        DriverStationSim.resetData()
        DriverStationSim.setDsAttached(true)
        DriverStationSim.setRobotMode(RobotMode.TELEOPERATED)
        DriverStationSim.setEnabled(false)
        val container = RobotContainer(RobotParameters.Mode.SIM)
        val pad = XboxControllerSim(container.pad)
        val inputs = IntakeIO.IntakeIOInputs()
        val scheduler = Scheduler.getDefault()
        pad.setAButton(false)
        pad.notifyNewData()
        scheduler.run()
        pad.setAButton(true)
        pad.notifyNewData()
        scheduler.run()
        container.intakeIO.updateInputs(inputs)
        assertEquals(0.0, inputs.data.intakeAppliedVolts)
        DriverStationSim.setEnabled(true)
        pad.notifyNewData()
        repeat(10) { container.swerve.periodic(); scheduler.run(); container.intakeIO.updateInputs(inputs) }
        assertTrue(inputs.data.intakeAppliedVolts > 0.0)
        pad.setAButton(false)
        pad.notifyNewData()
        scheduler.run()
        container.intakeIO.updateInputs(inputs)
        assertEquals(0.0, inputs.data.intakeAppliedVolts)
        DriverStationSim.setEnabled(false)
        pad.notifyNewData()
        scheduler.run()
        scheduler.cancelAll()
        container.stopAll()
        scheduler.defaultEventLoop.clear()
        TunableRegistry.reset()
    }
}
