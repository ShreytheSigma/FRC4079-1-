package frc.robot

import frc.robot.auto.advanced.RelativePathAuto
import frc.robot.mechanisms.drive.Swerve
import frc.robot.mechanisms.drive.gyro.GyroIO
import frc.robot.mechanisms.drive.module.ModuleIO
import frc.robot.mechanisms.drive.module.SimModuleIO
import org.junit.jupiter.api.Assertions.*
import org.junit.jupiter.api.BeforeAll
import org.junit.jupiter.api.BeforeEach
import org.junit.jupiter.api.AfterEach
import org.junit.jupiter.api.Test
import org.wpilib.command3.Scheduler
import org.wpilib.hardware.hal.HAL
import org.wpilib.hardware.hal.RobotMode
import org.wpilib.math.geometry.Rotation2d
import org.wpilib.math.geometry.Translation2d
import org.wpilib.simulation.AlertSim
import org.wpilib.simulation.DriverStationSim

class RelativePathAutoTest {
    companion object { @JvmStatic @BeforeAll fun initialize() { HAL.initialize() } }

    @BeforeEach fun reset() {
        AlertSim.resetData()
        DriverStationSim.resetData()
        DriverStationSim.setDsAttached(true)
        DriverStationSim.setRobotMode(RobotMode.AUTONOMOUS)
        DriverStationSim.setEnabled(true)
        DriverStationSim.notifyNewData()
    }

    @AfterEach fun disable() {
        DriverStationSim.setEnabled(false)
        DriverStationSim.notifyNewData()
    }

    private class FaultableModule : ModuleIO {
        val simulation = SimModuleIO()
        var healthy = true
        var frozen = false
        var positionOverride: Double? = null
        var velocityOverride: Double? = null
        var output = 0.0
        override fun updateInputs(inputs: ModuleIO.ModuleIOInputs) {
            simulation.updateInputs(inputs)
            inputs.data.driveConnected = healthy
            if (frozen) { inputs.data.drivePositionRad = 0.0; inputs.data.driveVelocityRadPerSec = 0.0 }
            positionOverride?.let { inputs.data.drivePositionRad = it }
            velocityOverride?.let { inputs.data.driveVelocityRadPerSec = it }
        }
        override fun runDriveVelocity(velocityRadPerSec: Double, feedforward: Double) {
            output = velocityRadPerSec
            simulation.runDriveVelocity(if (frozen) 0.0 else velocityRadPerSec, feedforward)
        }
        override fun runTurnPosition(rotation: Rotation2d) { simulation.runTurnPosition(rotation) }
        override fun runDriveOpenLoop(output: Double) { this.output = output; simulation.runDriveOpenLoop(output) }
        override fun runTurnOpenLoop(output: Double) { simulation.runTurnOpenLoop(output) }
    }

    private class Fixture(route: List<Translation2d> = listOf(Translation2d(1.5, 0.0)), initialYaw: Double = 0.0) {
        val modules = Array(4) { FaultableModule() }
        var yaw = initialYaw
        var gyroConnected = true
        val swerve = Swerve(Array<ModuleIO>(4) { modules[it] }, object : GyroIO {
            override fun updateInputs(inputs: GyroIO.GyroIOInputs) {
                inputs.data.connected = gyroConnected
                inputs.data.yawPosition = Rotation2d.fromDegrees(yaw)
            }
        })
        var time = 0.0
        var stops = 0
        val scheduler = Scheduler.createIndependentScheduler()
        val command = RelativePathAuto(swerve, { stops++; swerve.stop() }, route, now = { time })
        fun start() { swerve.periodic(); scheduler.schedule(command); scheduler.run() }
        fun tick(dt: Double = 0.02) { time += dt; swerve.periodic(); scheduler.run() }
        fun stopped() {
            assertFalse(scheduler.isRunning(command))
            assertTrue(modules.all { it.output == 0.0 })
        }
    }

    @Test fun `profiled taxi reaches distance and stops using simulated motors`() {
        val f = Fixture()
        f.start()
        var previousSpeed = 0.0
        repeat(400) {
            f.tick()
            val speed = f.command.requestedVelocity.vx
            assertTrue(kotlin.math.abs(speed) <= 0.600001)
            if (f.scheduler.isRunning(f.command)) assertTrue(kotlin.math.abs(speed - previousSpeed) <= 0.012001)
            previousSpeed = speed
        }
        f.stopped()
        assertEquals("Completed", f.command.result)
        assertEquals(1.5, f.command.localPose.x, 0.05)
        assertEquals(0.0, f.command.localPose.y, 0.03)
        assertTrue(f.stops >= 2)
    }

    @Test fun `two leg path is relative to robot start even with nonzero gyro yaw`() {
        val f = Fixture(listOf(Translation2d(0.75, 0.0), Translation2d(0.75, 0.5)), 137.0)
        f.start()
        repeat(600) { f.tick() }
        f.stopped()
        assertEquals("Completed", f.command.result)
        assertEquals(0.75, f.command.localPose.x, 0.05)
        assertEquals(0.5, f.command.localPose.y, 0.05)
    }

    @Test fun `frozen drive feedback aborts instead of pushing indefinitely`() {
        val f = Fixture()
        f.modules.forEach { it.frozen = true }
        f.start(); repeat(150) { f.tick() }
        f.stopped()
        assertTrue(f.command.result.contains("no measured progress") || f.command.result.contains("tracking error"))
    }

    @Test fun `feedback failure latches auto stopped`() {
        val f = Fixture()
        f.start(); repeat(30) { f.tick() }
        f.modules[2].healthy = false
        f.tick(); f.stopped()
        assertTrue(f.command.result.contains("feedback unavailable"))
        f.modules[2].healthy = true
        repeat(30) { f.tick() }
        f.stopped()
    }

    @Test fun `odometry discontinuity and nonfinite feedback abort`() {
        for (badPosition in listOf(100.0, Double.NaN)) {
            AlertSim.resetData()
            val f = Fixture()
            f.start(); repeat(20) { f.tick() }
            f.modules.forEach { it.positionOverride = badPosition }
            f.tick(); f.stopped()
            assertTrue(f.command.result.startsWith("Stopped:"))
        }
    }

    @Test fun `heading excursion stops the path`() {
        val f = Fixture()
        f.start(); repeat(20) { f.tick() }
        f.yaw = 35.0
        f.tick(); f.stopped()
        assertTrue(f.command.result.contains("heading error"))
    }

    @Test fun `cancel and reschedule reset path origin and clock`() {
        val f = Fixture()
        f.start(); repeat(30) { f.tick() }
        f.scheduler.cancel(f.command); f.stopped()
        repeat(60) { f.tick() }
        f.time = 100.0
        f.start(); repeat(400) { f.tick() }
        f.stopped()
        assertEquals("Completed", f.command.result)
        assertEquals(1.5, f.command.localPose.x, 0.05)
    }

    @Test fun `clock failure and disabled mode stop the path`() {
        val f = Fixture()
        f.start(); f.tick(0.3); f.stopped()
        assertTrue(f.command.result.contains("clock"))
        f.start(); f.time = Double.NaN; f.scheduler.run(); f.stopped()
        DriverStationSim.setEnabled(false)
        DriverStationSim.notifyNewData()
        f.time = 0.0; f.start(); f.stopped()
        assertTrue(f.command.result.contains("not enabled"))
    }

    @Test fun `path validation rejects nonfinite excessive and empty paths`() {
        val f = Fixture()
        for (route in listOf(emptyList(), listOf(Translation2d.ZERO), listOf(Translation2d(3.0, 0.0)),
            listOf(Translation2d(Double.NaN, 0.0)), List(5) { Translation2d(0.5, 0.0) })) {
            assertThrows(IllegalArgumentException::class.java) { RelativePathAuto(f.swerve, {}, route) }
        }
    }

    @Test fun `moving start and driver station loss refuse continued output`() {
        val f = Fixture()
        f.modules.forEach { it.velocityOverride = 10.0 }
        f.start(); f.stopped()
        assertTrue(f.command.result.contains("not stationary"))
        f.modules.forEach { it.velocityOverride = null }
        f.start(); repeat(20) { f.tick() }
        DriverStationSim.setDsAttached(false)
        org.wpilib.driverstation.internal.DriverStationBackend.refreshData()
        f.tick(); f.stopped()
    }

    @Test fun `routes with no completion time margin are rejected before motion`() {
        assertThrows(IllegalArgumentException::class.java) {
            Fixture(listOf(Translation2d(1.0, 0.0), Translation2d.ZERO, Translation2d(1.0, 0.0), Translation2d.ZERO))
        }
    }

    @Test fun `per leg deadline stops feedback that remains just outside goal tolerance`() {
        val f = Fixture()
        f.start(); repeat(205) { f.tick() }
        f.modules.forEach { it.positionOverride = 1.44 / 0.0508; it.velocityOverride = 0.0 }
        repeat(200) { f.tick() }
        f.stopped()
        assertTrue(f.command.result.contains("timeout"), f.command.result)
    }

    @Test fun `small heading error at endpoint clears module deadband and converges`() {
        for (error in listOf(-4.0, 4.0)) {
            AlertSim.resetData()
            val f = Fixture()
            f.start(); repeat(222) { f.tick() }
            assertTrue(f.scheduler.isRunning(f.command))
            f.yaw = error
            f.tick()
            // Wheel-derived heading follows the simulated rotation after the injected gyro offset.
            f.gyroConnected = false
            repeat(140) { f.tick() }
            f.stopped()
            assertEquals("Completed", f.command.result)
            assertTrue(kotlin.math.abs(f.command.localPose.rotation.degrees) <= 3.0)
        }
    }
}
