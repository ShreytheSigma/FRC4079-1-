package frc.robot

import frc.robot.commands.driving.PadDrive
import frc.robot.commands.manipulating.FeedBalls
import frc.robot.mechanisms.transport.Transport
import frc.robot.mechanisms.transport.TransportIO
import frc.robot.mechanisms.drive.Swerve
import frc.robot.mechanisms.drive.gyro.GyroIO
import frc.robot.mechanisms.drive.module.ModuleIO
import frc.robot.mechanisms.drive.module.SwerveModule
import frc.robot.mechanisms.hood.Hood
import frc.robot.mechanisms.hood.HoodIO
import frc.robot.mechanisms.shooter.Shooter
import frc.robot.mechanisms.shooter.ShooterIO
import frc.robot.utils.RobotParameters
import frc.robot.utils.ShotTable
import org.junit.jupiter.api.Assertions.*
import org.junit.jupiter.api.BeforeAll
import org.junit.jupiter.api.BeforeEach
import org.wpilib.simulation.AlertSim
import org.junit.jupiter.api.Test
import org.wpilib.command3.Scheduler
import org.wpilib.driverstation.XboxController
import org.wpilib.hardware.hal.HAL
import org.wpilib.hardware.hal.RobotMode
import org.wpilib.math.geometry.Rotation2d
import org.wpilib.math.kinematics.ChassisVelocities
import org.wpilib.math.kinematics.SwerveModuleVelocity
import org.wpilib.simulation.DriverStationSim
import org.wpilib.simulation.XboxControllerSim
import kotlin.math.abs

class RobotControlTest {
    @BeforeEach fun resetAlerts() { AlertSim.resetData() }
    companion object {
        @JvmStatic @BeforeAll fun initialize() { HAL.initialize() }
    }

    private class ModuleRecorder : ModuleIO {
        var measuredAngle = Rotation2d.ZERO
        var desiredAngle = Rotation2d.ZERO
        var desiredSpeed = 0.0
        var connected = true
        var measuredPosition = 0.0
        var driveOpenLoop = false
        var steerOpenLoop = false
        override fun updateInputs(inputs: ModuleIO.ModuleIOInputs) {
            inputs.data.driveConnected = connected
            inputs.data.turnConnected = connected
            inputs.data.turnEncoderConnected = connected
            inputs.data.turnPosition = measuredAngle
            inputs.data.turnAbsolutePosition = measuredAngle
            inputs.data.drivePositionRad = measuredPosition
        }
        override fun runDriveVelocity(velocityRadPerSec: Double, feedforward: Double) { desiredSpeed = velocityRadPerSec * 0.0508; driveOpenLoop = false }
        override fun runTurnPosition(rotation: Rotation2d) { desiredAngle = rotation; steerOpenLoop = false }
        override fun runDriveOpenLoop(output: Double) { desiredSpeed = output; driveOpenLoop = true }
        override fun runTurnOpenLoop(output: Double) { steerOpenLoop = true }
    }

    @Test fun `forward gives all four wheels the same direction and speed`() {
        val ios = Array(4) { ModuleRecorder() }
        val swerve = Swerve(Array<ModuleIO>(4) { ios[it] }, object : GyroIO {})
        swerve.periodic()
        swerve.setDriveSpeeds(1.0, 0.0, 0.0, false)
        ios.forEach { assertEquals(1.0, it.desiredSpeed, 1e-9); assertEquals(0.0, it.desiredAngle.radians, 1e-9) }
    }

    @Test fun `combined translation and rotation preserves wheel ratios within max speed`() {
        val ios = Array(4) { ModuleRecorder() }
        val swerve = Swerve(Array<ModuleIO>(4) { ios[it] }, object : GyroIO {})
        val speeds = ChassisVelocities(4.39, 4.39, 7.0)
        val raw = RobotParameters.SwerveParameters.PhysicalParameters.kinematics.toSwerveModuleVelocities(speeds)
        ios.forEachIndexed { i, io -> io.measuredAngle = raw[i].angle }
        swerve.periodic()
        swerve.runVelocity(speeds)
        assertEquals(4.39, ios.maxOf { abs(it.desiredSpeed) }, 1e-9)
        val scale = ios[0].desiredSpeed / raw[0].velocity
        ios.forEachIndexed { i, io -> assertEquals(raw[i].velocity * scale, io.desiredSpeed, 1e-9) }
    }

    @Test fun `steering crosses wrap by shortest path and reverses drive when needed`() {
        val io = ModuleRecorder()
        val module = SwerveModule(io, 0)
        io.measuredAngle = Rotation2d.fromDegrees(179.0)
        module.updateInputs()
        module.runSetpoint(SwerveModuleVelocity(1.0, Rotation2d.fromDegrees(-179.0)))
        assertTrue(abs(io.desiredAngle.minus(io.measuredAngle).degrees) < 3.0)
        assertTrue(io.desiredSpeed > 0.99)
        io.measuredAngle = Rotation2d.ZERO
        module.updateInputs()
        module.runSetpoint(SwerveModuleVelocity(1.0, Rotation2d.fromDegrees(180.0)))
        assertEquals(-1.0, io.desiredSpeed, 1e-9)
        assertEquals(0.0, io.desiredAngle.radians, 1e-9)
    }

    @Test fun `zero speed retains steering angle and disconnected encoder stops module`() {
        val io = ModuleRecorder()
        val module = SwerveModule(io, 0)
        io.measuredAngle = Rotation2d.fromDegrees(45.0)
        module.updateInputs()
        module.runSetpoint(SwerveModuleVelocity(1.0, io.measuredAngle))
        module.runSetpoint(SwerveModuleVelocity(0.0, Rotation2d.ZERO))
        assertEquals(45.0, io.desiredAngle.degrees, 1e-9)
        assertEquals(0.0, io.desiredSpeed)
        assertFalse(io.steerOpenLoop)
        io.connected = false
        module.updateInputs()
        module.runSetpoint(SwerveModuleVelocity(2.0, Rotation2d.ZERO))
        assertTrue(io.driveOpenLoop && io.steerOpenLoop)
        assertEquals(0.0, io.desiredSpeed)
    }

    @Test fun `nonfinite drive demand stops every module`() {
        val ios = Array(4) { ModuleRecorder() }
        val swerve = Swerve(Array<ModuleIO>(4) { ios[it] }, object : GyroIO {})
        swerve.periodic()
        swerve.runVelocity(ChassisVelocities(1.0, 0.0, 0.0))
        swerve.runVelocity(ChassisVelocities(Double.NaN, 0.0, 0.0))
        ios.forEach { assertEquals(0.0, it.desiredSpeed); assertTrue(it.steerOpenLoop) }
    }

    @Test fun `one unavailable module stops the whole drivetrain`() {
        val ios = Array(4) { ModuleRecorder() }
        val swerve = Swerve(Array<ModuleIO>(4) { ios[it] }, object : GyroIO {})
        swerve.periodic()
        swerve.runVelocity(ChassisVelocities(1.0, 0.0, 0.0))
        ios[2].connected = false
        swerve.periodic()
        swerve.runVelocity(ChassisVelocities(1.0, 0.0, 0.0))
        assertTrue(ios.all { it.desiredSpeed == 0.0 && it.steerOpenLoop })
    }

    @Test fun `joystick response starts smoothly after deadband and diagonal stays within max`() {
        val pad = XboxController(3)
        val sim = XboxControllerSim(pad)
        sim.setLeftX(0.1501)
        sim.setLeftY(0.0)
        sim.notifyNewData()
        assertTrue(abs(PadDrive.positionSet(pad).first) < 0.01)
        sim.setLeftX(1.0)
        sim.setLeftY(1.0)
        sim.notifyNewData()
        val result = PadDrive.positionSet(pad)
        assertEquals(4.39, kotlin.math.hypot(result.first, result.second), 1e-9)
    }

    @Test fun `nonfinite encoder position stops drive without corrupting fallback heading`() {
        val ios = Array(4) { ModuleRecorder() }
        val swerve = Swerve(Array<ModuleIO>(4) { ios[it] }, object : GyroIO {})
        swerve.periodic()
        swerve.setDriveSpeeds(1.0, 0.0, 0.0, false)
        ios[0].measuredPosition = Double.NaN
        swerve.periodic()
        assertFalse(swerve.readyForAuto)
        assertTrue(ios.all { it.desiredSpeed == 0.0 })
        assertTrue(swerve.gyroYaw.radians.isFinite())
        ios[0].measuredPosition = 0.0
        swerve.periodic()
        assertTrue(swerve.gyroYaw.radians.isFinite())
    }

    @Test fun `feeder starts only while ready and stops immediately on readiness loss or cancel`() {
        var running = false
        var ready = false
        val transport = Transport(object : TransportIO {
            override fun setTransportState(state: TransportIO.TransportState) { running = state == TransportIO.TransportState.ACTIVE }
            override fun disablePower() { running = false }
        }, { ready })
        val command = FeedBalls(transport) { ready }
        val scheduler = Scheduler.createIndependentScheduler()
        scheduler.schedule(command)
        scheduler.run()
        transport.periodic()
        assertFalse(running)
        ready = true
        scheduler.run()
        transport.periodic()
        assertTrue(running)
        ready = false
        scheduler.run()
        assertFalse(running)
        ready = true
        scheduler.run()
        transport.periodic()
        scheduler.cancel(command)
        transport.periodic()
        assertFalse(running)
    }

    @Test fun `driver heading reset leaves odometry heading unchanged`() {
        val ios = Array(4) { ModuleRecorder() }
        val gyro = object : GyroIO {
            override fun updateInputs(inputs: GyroIO.GyroIOInputs) {
                inputs.data.connected = true
                inputs.data.yawPosition = Rotation2d.fromDegrees(90.0)
            }
        }
        val swerve = Swerve(Array<ModuleIO>(4) { ios[it] }, gyro)
        swerve.periodic()
        swerve.resetGyro()
        assertEquals(90.0, swerve.gyroYaw.degrees, 1e-9)
        swerve.setDriveSpeeds(1.0, 0.0, 0.0, true)
        ios.forEach { assertEquals(0.0, it.desiredAngle.radians, 1e-9); assertEquals(1.0, it.desiredSpeed, 1e-9) }
    }

    @Test fun `PadDrive remains scheduled and reacts to changed sticks then stops on cancel`() {
        DriverStationSim.resetData()
        DriverStationSim.setDsAttached(true)
        DriverStationSim.setRobotMode(RobotMode.TELEOPERATED)
        DriverStationSim.setEnabled(true)
        val pad = XboxController(1)
        val padSim = XboxControllerSim(pad)
        val ios = Array(4) { ModuleRecorder() }
        val swerve = Swerve(Array<ModuleIO>(4) { ios[it] }, object : GyroIO {})
        swerve.periodic()
        val scheduler = Scheduler.createIndependentScheduler()
        val command = PadDrive(swerve, pad)
        padSim.setLeftY(-0.5)
        padSim.notifyNewData()
        scheduler.schedule(command)
        scheduler.run()
        assertTrue(scheduler.isRunning(command))
        assertTrue(ios.all { it.desiredSpeed > 0.0 })
        padSim.setLeftY(0.5)
        padSim.notifyNewData()
        scheduler.run()
        assertTrue(ios.all { it.desiredSpeed < 0.0 })
        scheduler.cancel(command)
        assertTrue(ios.all { it.desiredSpeed == 0.0 })
        DriverStationSim.setEnabled(false)
        DriverStationSim.notifyNewData()
    }

    @Test fun `disable persists through periodic and manual power is not overwritten`() {
        var shooterWrites = 0
        var hoodWrites = 0
        var stops = 0
        val shooter = Shooter(object : ShooterIO {
            override fun setVelocity(velocityRadPerSec: Double) { shooterWrites++ }
            override fun setShooterState(state: ShooterIO.ShooterState) { shooterWrites++ }
            override fun disablePower() { stops++ }
        })
        val hood = Hood(object : HoodIO {
            override fun isPositionRequestAccepted(positionRad: Double) = true
            override fun setPosition(positionRad: Double) { hoodWrites++ }
            override fun setHoodState(state: HoodIO.HoodPositionState) { hoodWrites++ }
            override fun disablePower() { stops++ }
        })
        shooter.setVelocity(300.0)
        hood.setPosition(0.4)
        shooter.disable()
        hood.disable()
        repeat(5) { shooter.periodic(); hood.periodic() }
        assertEquals(1, shooterWrites)
        assertEquals(1, hoodWrites)
        assertEquals(2, stops)
        shooter.setVelocity(300.0)
        hood.setPosition(0.4)
        shooter.setPower(0.2, 0.2)
        hood.setPower(0.2)
        repeat(5) { shooter.periodic(); hood.periodic() }
        assertEquals(2, shooterWrites)
        assertEquals(2, hoodWrites)
    }

    @Test fun `shot lookup interpolates calibrated range and rejects invalid or out of range poses`() {
        assertEquals(3000.0, ShotTable.getShot(2.25)!!.flywheelRPM, 1e-9)
        assertEquals(27.5, ShotTable.getShot(2.25)!!.hoodAngleDegrees, 1e-9)
        assertNotNull(ShotTable.getShot(1.5))
        assertNotNull(ShotTable.getShot(3.5))
        listOf(-1.0, 0.0, 4.0, Double.NaN, Double.POSITIVE_INFINITY).forEach { assertNull(ShotTable.getShot(it)) }
    }
}
