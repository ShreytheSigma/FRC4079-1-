package frc.robot

import com.ctre.phoenix6.signals.InvertedValue
import frc.robot.utils.RobotParameters
import frc.robot.utils.RobotParameters.CANBusParameters as CAN
import frc.robot.utils.RobotParameters.SwerveParameters as Swerve
import org.junit.jupiter.api.Assertions.*
import org.junit.jupiter.api.Test
import org.wpilib.hardware.bus.CANPort

/** Snapshot of the supplied ZIP's hardware identity, not a wiring/calibration test. */
class HardwareCompatibilityTest {
    @Test fun `swerve corners ids offsets and inversions match original`() {
        assertEquals(CANPort.CAN_S0, CAN.SWERVE_CANBUS_ID)
        val expectedOffsets = listOf(0.247802734375, -0.34326171875, 0.450927734375, -0.032958984375)
        Swerve.MODULE_CONFIGS.forEachIndexed { i, module ->
            assertEquals(2 * i + 1, module.turnMotorId)
            assertEquals(2 * i + 2, module.driveMotorId)
            assertEquals(9 + i, module.encoderID)
            assertEquals(expectedOffsets[i], module.encoderOffset.rotations, 1e-12)
            assertEquals(i % 2 == 1, module.driveInverted)
            assertFalse(module.turnInverted)
            assertFalse(module.encoderInverted)
            assertEquals(CANPort.CAN_S0, module.canBUS)
        }
        assertEquals(13, CAN.PIDGEY_ID)
    }

    @Test fun `all mechanism motor ids and CAN ports match original`() {
        val ids = listOf(
            RobotParameters.IntakeParameters.intakeMotorLeft,
            RobotParameters.IntakeParameters.intakeMotorRight,
            RobotParameters.PivotParameters.pivotMotor,
            RobotParameters.ShooterParameters.shooterLeftMotor,
            RobotParameters.ShooterParameters.shooterRightMotor,
            RobotParameters.TransportParameters.indexerMotor,
            RobotParameters.TransportParameters.hopperMotor,
            RobotParameters.HoodParameters.hoodMotor,
        )
        assertEquals(listOf(14, 41, 15, 16, 17, 18, 19, 20), ids)
        assertEquals(ids.size, ids.toSet().size)
        listOf(
            RobotParameters.IntakeParameters.INTAKE_CANPORT,
            RobotParameters.PivotParameters.PIVOT_CANPORT,
            RobotParameters.ShooterParameters.SHOOTER_CANPORT,
            RobotParameters.TransportParameters.INDEXER_CANPORT,
            RobotParameters.TransportParameters.HOPPER_CANPORT,
            RobotParameters.HoodParameters.HOOD_CANPORT,
        ).forEach { assertEquals(CANPort.CAN_S1, it) }
        assertEquals(InvertedValue.CounterClockwise_Positive, RobotParameters.IntakeParameters.LEFT_INVERTED)
        assertEquals(InvertedValue.CounterClockwise_Positive, RobotParameters.IntakeParameters.RIGHT_INVERTED)
    }

    @Test fun `swerve geometry limits and active gains match original`() {
        val p = Swerve.PhysicalParameters
        assertEquals(7.03125, p.DRIVE_MOTOR_GEAR_RATIO)
        assertEquals(287.0 / 11.0, p.STEER_MOTOR_GEAR_RATIO)
        assertEquals(4.5, p.COUPLE_RATIO)
        assertEquals(0.1016, p.WHEEL_DIAMETER)
        assertEquals(4.39, p.MAX_SPEED)
        assertEquals(14 * Math.PI / 3, p.MAX_ANGULAR_SPEED)
        assertEquals(120.0, p.DRIVE_CURRENT_LIMIT)
        assertEquals(60.0, p.STEER_CURRENT_LIMIT)
        p.MODULE_LOCATIONS.forEachIndexed { i, location ->
            assertEquals(if (i < 2) 0.240665 else -0.240665, location.x)
            assertEquals(if (i % 2 == 0) 0.240665 else -0.240665, location.y)
        }
        assertEquals(45.0, Swerve.PIDParameters.STEER_PID_TELE.p)
        assertEquals(2.0, Swerve.PIDParameters.STEER_PID_TELE.d)
        assertEquals(100.0, Swerve.PIDParameters.DRIVE_PID_TELE.p)
    }
}
