package frc.robot

import frc.robot.commands.manipulating.FeedBalls
import frc.robot.commands.shooting.ShootWithDistance
import frc.robot.mechanisms.OdometrySupplier
import frc.robot.mechanisms.Vision
import frc.robot.mechanisms.drive.Swerve
import frc.robot.mechanisms.drive.gyro.GyroIO
import frc.robot.mechanisms.drive.module.ModuleIO
import frc.robot.mechanisms.hood.Hood
import frc.robot.mechanisms.hood.HoodIO
import frc.robot.mechanisms.shooter.Shooter
import frc.robot.mechanisms.shooter.ShooterIO
import frc.robot.mechanisms.transport.Transport
import frc.robot.mechanisms.transport.TransportIO
import frc.robot.utils.PoseLookup
import org.junit.jupiter.api.Assertions.*
import org.junit.jupiter.api.BeforeAll
import org.junit.jupiter.api.BeforeEach
import org.junit.jupiter.api.Test
import org.wpilib.command3.Command
import org.wpilib.command3.Coroutine
import org.wpilib.command3.Scheduler
import org.wpilib.hardware.hal.HAL
import org.wpilib.math.geometry.Pose2d
import org.wpilib.math.geometry.Rotation2d
import org.wpilib.simulation.AlertSim

class LocalizationSafetyTest {
    companion object { @JvmStatic @BeforeAll fun initialize() { HAL.initialize() } }
    @BeforeEach fun reset() { AlertSim.resetData() }

    private class Fixture {
        var healthy = true
        var time = 0.0
        val swerve = Swerve(Array<ModuleIO>(4) { object : ModuleIO {
            override fun updateInputs(inputs: ModuleIO.ModuleIOInputs) {
                inputs.data.driveConnected = healthy
                inputs.data.turnConnected = healthy
                inputs.data.turnEncoderConnected = healthy
            }
        } }, object : GyroIO {})
        val odometry = OdometrySupplier(swerve, Vision(emptyArray()), { time })
        fun update() { swerve.periodic(); odometry.periodic() }
        fun setKnownPose() {
            val hub = PoseLookup.hubPose
            assertTrue(odometry.resetPose(Pose2d(hub.x - 2.0, hub.y, Rotation2d.ZERO)))
        }
    }

    @Test fun `boot zero is not a known field pose and explicit finite reset establishes readiness`() {
        val f = Fixture()
        f.update()
        assertFalse(f.odometry.readyForShooting)
        assertTrue(f.odometry.getDistanceToHub().isNaN())
        f.setKnownPose()
        assertTrue(f.odometry.readyForShooting)
        assertEquals(2.0, f.odometry.getDistanceToHub(), 1e-9)
        assertFalse(f.odometry.resetPose(Pose2d(Double.NaN, 0.0, Rotation2d.ZERO)))
        assertFalse(f.odometry.readyForShooting)
    }

    @Test fun `drive loss invalidates pose until explicit reinitialization`() {
        val f = Fixture()
        f.update(); f.setKnownPose()
        f.healthy = false; f.time += 0.02; f.update()
        assertFalse(f.odometry.readyForShooting)
        f.healthy = true; f.time += 0.02; f.update()
        assertFalse(f.odometry.readyForShooting)
        f.setKnownPose()
        assertTrue(f.odometry.readyForShooting)
    }

    @Test fun `stale or backward clock cannot authorize shooting`() {
        val f = Fixture()
        f.update(); f.setKnownPose()
        f.time = 0.2
        assertFalse(f.odometry.readyForShooting)
        f.update()
        assertFalse(f.odometry.readyForShooting)
        f.setKnownPose()
        f.time = 0.1; f.update()
        assertFalse(f.odometry.readyForShooting)
    }

    @Test fun `distance shooting stops when retained pose becomes unavailable`() {
        val f = Fixture()
        f.update(); f.setKnownPose()
        var speed = 0.0
        val shooter = Shooter(object : ShooterIO {
            override fun setVelocity(velocityRadPerSec: Double) { speed = velocityRadPerSec }
            override fun disablePower() { speed = 0.0 }
        })
        val hood = Hood(object : HoodIO {})
        val command = ShootWithDistance(shooter, hood, f.odometry)
        val scheduler = Scheduler.createIndependentScheduler()
        scheduler.schedule(command); scheduler.run()
        assertTrue(speed > 0.0)
        f.healthy = false; f.time += 0.02; f.update()
        scheduler.run()
        assertEquals(0.0, speed)
        scheduler.cancelAll()
    }

    @Test fun `feeder output interlock sees same cycle invalidation regardless of command ordering`() {
        for (feedFirst in listOf(false, true)) {
            AlertSim.resetData()
            var ready = true
            var invalidate = false
            var powered = false
            val transport = Transport(object : TransportIO {
                override fun setTransportState(state: TransportIO.TransportState) { powered = true }
                override fun disablePower() { powered = false }
            }, { ready })
            val feeder = FeedBalls(transport) { ready }
            val validator = object : Command {
                override fun name() = "Invalidate shot fixture"
                override fun requirements() = emptySet<org.wpilib.command3.Mechanism>()
                override fun run(coroutine: Coroutine) {
                    while (true) { if (invalidate) ready = false; coroutine.yield() }
                }
            }
            val scheduler = Scheduler.createIndependentScheduler()
            if (feedFirst) { scheduler.schedule(feeder); scheduler.schedule(validator) }
            else { scheduler.schedule(validator); scheduler.schedule(feeder) }
            transport.updateInputs(); scheduler.run(); transport.applyOutputs()
            assertTrue(powered)
            invalidate = true
            transport.updateInputs(); scheduler.run(); transport.applyOutputs()
            assertFalse(powered)
            scheduler.cancelAll()
        }
    }

    @Test fun `coasting shooter feedback cannot authorize feeding after a rejected request`() {
        var accepted = true
        val shooter = Shooter(object : ShooterIO {
            override fun disablePower() {}
            override fun isVelocityRequestAccepted(velocityRadPerSec: Double) = accepted
            override fun updateInputs(inputs: ShooterIO.ShooterIOInputs) {
                inputs.data.topMotorConnected = true
                inputs.data.bottomMotorConnected = true
                inputs.data.topVelocityRadPerSec = 300.0
                inputs.data.bottomVelocityRadPerSec = 300.0
            }
        })
        shooter.setVelocity(300.0); shooter.periodic()
        assertTrue(shooter.atSpeed)
        accepted = false
        assertFalse(shooter.atSpeed)
        shooter.disable()
        assertFalse(shooter.atSpeed)
    }
}
