package frc.robot

import frc.robot.auto.AutoManager
import frc.robot.auto.DriveForwardAuto
import frc.robot.mechanisms.OdometrySupplier
import frc.robot.mechanisms.Vision
import frc.robot.mechanisms.drive.Swerve
import frc.robot.mechanisms.drive.gyro.GyroIO
import frc.robot.mechanisms.drive.module.ModuleIO
import frc.robot.mechanisms.drive.module.SimModuleIO
import frc.robot.mechanisms.hood.Hood
import frc.robot.mechanisms.hood.HoodIO
import org.junit.jupiter.api.Assertions.*
import org.junit.jupiter.api.BeforeAll
import org.junit.jupiter.api.BeforeEach
import org.junit.jupiter.api.AfterEach
import org.junit.jupiter.api.Test
import org.wpilib.command3.Scheduler
import org.wpilib.hardware.hal.HAL
import org.wpilib.hardware.hal.RobotMode
import org.wpilib.math.geometry.Rotation2d
import org.wpilib.simulation.AlertSim
import org.wpilib.simulation.DriverStationSim
import org.wpilib.tunable.MockTunableBackend
import org.wpilib.tunable.TunableRegistry

class AutoTest {
    companion object { @JvmStatic @BeforeAll fun initialize() { HAL.initialize() } }

    @BeforeEach fun reset() {
        AlertSim.resetData()
        DriverStationSim.resetData()
        DriverStationSim.setDsAttached(true)
        DriverStationSim.setRobotMode(RobotMode.AUTONOMOUS)
        DriverStationSim.setEnabled(true)
        DriverStationSim.notifyNewData()
    }

    @AfterEach fun disable() {
        DriverStationSim.setEnabled(false)
        DriverStationSim.notifyNewData()
        TunableRegistry.reset()
    }

    private class Recorder : ModuleIO {
        var speed = 0.0
        var connected = true
        override fun updateInputs(inputs: ModuleIO.ModuleIOInputs) {
            inputs.data.driveConnected = connected
            inputs.data.turnConnected = connected
            inputs.data.turnEncoderConnected = connected
            inputs.data.turnPosition = Rotation2d.ZERO
        }
        override fun runDriveVelocity(velocityRadPerSec: Double, feedforward: Double) { speed = velocityRadPerSec * 0.0508 }
        override fun runDriveOpenLoop(output: Double) { speed = output }
    }

    private class Fixture {
        val modules = Array(4) { Recorder() }
        var yawDegrees = 0.0
        val swerve = Swerve(Array<ModuleIO>(4) { modules[it] }, object : GyroIO {
            override fun updateInputs(inputs: GyroIO.GyroIOInputs) {
                inputs.data.connected = true
                inputs.data.yawPosition = Rotation2d.fromDegrees(yawDegrees)
            }
        })
        val scheduler = Scheduler.createIndependentScheduler()
        var time = 0.0
        var stops = 0
        val command = DriveForwardAuto(swerve, { stops++; swerve.stop() }, now = { time })
        fun start() { swerve.periodic(); scheduler.schedule(command); scheduler.run() }
        fun tick(dt: Double = 0.02) { time += dt; swerve.periodic(); scheduler.run() }
        fun assertStopped() { assertTrue(modules.all { it.speed == 0.0 }); assertFalse(scheduler.isRunning(command)) }
    }

    @Test fun `timed auto ramps caps speed and stops on natural completion`() {
        val f = Fixture()
        f.start()
        assertTrue(f.command.requirements().contains(f.swerve))
        repeat(20) { f.tick(); assertTrue(f.modules.all { it.speed in 0.0..0.500001 }) }
        assertEquals(0.5, f.modules[0].speed, 1e-6)
        repeat(85) { f.tick() }
        f.assertStopped()
        assertEquals("Completed", f.command.result)
        assertTrue(f.stops >= 2)
    }

    @Test fun `cancel stops immediately and same command starts with a fresh clock`() {
        val f = Fixture()
        f.start(); repeat(25) { f.tick() }
        f.scheduler.cancel(f.command)
        f.assertStopped()
        f.time = 10.0
        f.start(); repeat(25) { f.tick() }
        assertTrue(f.scheduler.isRunning(f.command))
        assertEquals(0.5, f.modules[0].speed, 1e-6)
        f.scheduler.cancelAll()
    }

    @Test fun `auto refuses teleop and disabled modes`() {
        val f = Fixture()
        DriverStationSim.setRobotMode(RobotMode.TELEOPERATED)
        DriverStationSim.notifyNewData()
        f.start(); f.assertStopped()
        DriverStationSim.setRobotMode(RobotMode.AUTONOMOUS)
        DriverStationSim.setEnabled(false)
        DriverStationSim.notifyNewData()
        f.start(); f.assertStopped()
    }

    @Test fun `disable while driving stops without needing external cancellation`() {
        val f = Fixture()
        f.start(); repeat(20) { f.tick() }
        DriverStationSim.setEnabled(false)
        DriverStationSim.notifyNewData()
        f.tick(); f.assertStopped()
    }

    @Test fun `module fault aborts and does not restart after reconnection`() {
        val f = Fixture()
        f.start(); repeat(20) { f.tick() }
        f.modules[1].connected = false
        f.tick(); f.assertStopped()
        f.modules[1].connected = true
        repeat(20) { f.tick() }
        f.assertStopped()
        assertTrue(f.command.result.contains("feedback unavailable"))
    }

    @Test fun `heading wrap is allowed but large rotation aborts`() {
        val f = Fixture()
        f.yawDegrees = 179.0
        f.start()
        f.yawDegrees = -179.0
        f.tick()
        assertTrue(f.scheduler.isRunning(f.command))
        f.yawDegrees = -130.0
        f.tick(); f.assertStopped()
        assertTrue(f.command.result.contains("heading error"))
    }

    @Test fun `clock discontinuity stops auto`() {
        val f = Fixture()
        f.start(); f.tick(0.4); f.assertStopped()
        f.start(); f.time = Double.NaN; f.scheduler.run(); f.assertStopped()
        f.time = 10.0; f.start(); f.time = 9.0; f.scheduler.run(); f.assertStopped()
    }

    @Test fun `settings reject dangerous or nonfinite requests`() {
        assertThrows(IllegalArgumentException::class.java) { DriveForwardAuto.Settings(speedMetersPerSecond = 2.0) }
        assertThrows(IllegalArgumentException::class.java) { DriveForwardAuto.Settings(durationSeconds = 30.0) }
        assertThrows(IllegalArgumentException::class.java) { DriveForwardAuto.Settings(rampSeconds = 0.0) }
        assertThrows(IllegalArgumentException::class.java) { DriveForwardAuto.Settings(speedMetersPerSecond = Double.NaN) }
        assertEquals(0.0, DriveForwardAuto.Settings().speedAt(Double.NaN))
    }

    @Test fun `auto chooser defaults safely and unknown option falls back to do nothing`() {
        TunableRegistry.reset()
        val backend = MockTunableBackend()
        TunableRegistry.registerBackend("/", backend)
        val f = Fixture()
        val manager = AutoManager(f.swerve, { f.swerve.stop() }, setOf(f.swerve))
        assertEquals("Do Nothing Auto", manager.createSelected().name())
        backend.setValue("/Auto/Routine/selected", "Drive Forward and Stop")
        TunableRegistry.update()
        assertTrue(manager.createSelected() is DriveForwardAuto)
        backend.setValue("/Auto/Routine/selected", "not a routine")
        TunableRegistry.update()
        val command = manager.createSelected()
        assertEquals("Do Nothing Auto", command.name())
        f.modules.forEach { it.speed = 0.5 }
        f.scheduler.schedule(command); f.scheduler.run()
        assertTrue(f.modules.all { it.speed == 0.0 })
    }

    @Test fun `basic auto moves simulated robot then removes all drive output`() {
        var time = 0.0
        val swerve = Swerve(Array<ModuleIO>(4) { SimModuleIO() }, object : GyroIO {})
        val odometry = OdometrySupplier(swerve, Vision(emptyArray()))
        val scheduler = Scheduler.createIndependentScheduler()
        val command = DriveForwardAuto(swerve, { swerve.stop() }, now = { time })
        swerve.periodic()
        scheduler.schedule(command)
        repeat(170) {
            swerve.periodic(); odometry.periodic(); scheduler.run(); time += 0.02
        }
        assertEquals("Completed", command.result)
        assertTrue(odometry.pose.x in 0.55..1.05)
        assertEquals(0.0, odometry.pose.y, 0.05)
        assertEquals(0.0, swerve.autoSpeeds.vx, 0.05)
    }

    @Test fun `unhomed hood cannot make feed readiness true`() {
        var ready = false
        val hood = Hood(object : HoodIO {
            override fun isPositionRequestAccepted(positionRad: Double) = ready && positionRad == 0.5
            override fun updateInputs(inputs: HoodIO.HoodIOInputs) {
                inputs.data.hoodConnected = true
                inputs.data.hoodPositionRad = 0.5
                inputs.data.positionControlReady = ready
            }
        })
        hood.setPosition(0.5); hood.periodic()
        assertFalse(hood.atPosition)
        ready = true; hood.setPosition(0.5); hood.periodic()
        assertTrue(hood.atPosition)
        hood.disable()
        assertFalse(hood.atPosition)
    }
}
