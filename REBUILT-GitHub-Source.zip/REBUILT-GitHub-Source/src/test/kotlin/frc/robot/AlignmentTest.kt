package frc.robot

import frc.robot.commands.driving.AlignSwerveToShoot
import frc.robot.mechanisms.OdometrySupplier
import frc.robot.mechanisms.Vision
import frc.robot.mechanisms.drive.Swerve
import frc.robot.mechanisms.drive.gyro.GyroIO
import frc.robot.mechanisms.drive.module.ModuleIO
import frc.robot.mechanisms.drive.module.SimModuleIO
import frc.robot.utils.PoseLookup
import org.junit.jupiter.api.Assertions.*
import org.junit.jupiter.api.BeforeAll
import org.junit.jupiter.api.BeforeEach
import org.junit.jupiter.api.AfterEach
import org.junit.jupiter.api.Test
import org.wpilib.command3.Scheduler
import org.wpilib.hardware.hal.HAL
import org.wpilib.hardware.hal.RobotMode
import org.wpilib.math.geometry.Pose2d
import org.wpilib.math.geometry.Rotation2d
import org.wpilib.simulation.AlertSim
import org.wpilib.simulation.DriverStationSim

class AlignmentTest {
    companion object { @JvmStatic @BeforeAll fun initialize() { HAL.initialize() } }
    @BeforeEach fun reset() {
        AlertSim.resetData()
        DriverStationSim.resetData()
        DriverStationSim.setDsAttached(true)
        DriverStationSim.setRobotMode(RobotMode.TELEOPERATED)
        DriverStationSim.setEnabled(true)
        DriverStationSim.notifyNewData()
    }
    @AfterEach fun disable() {
        DriverStationSim.setEnabled(false)
        DriverStationSim.notifyNewData()
    }
    private class Fixture(simulate: Boolean = true) {
        var time = 0.0
        var demand = 0.0
        val swerve = Swerve(Array<ModuleIO>(4) {
            if (simulate) SimModuleIO() else object : ModuleIO {
                override fun updateInputs(inputs: ModuleIO.ModuleIOInputs) {
                    inputs.data.driveConnected = true
                    inputs.data.turnConnected = true
                    inputs.data.turnEncoderConnected = true
                }
                override fun runDriveVelocity(velocityRadPerSec: Double, feedforward: Double) { demand = velocityRadPerSec }
                override fun runDriveOpenLoop(output: Double) { demand = output }
            }
        }, object : GyroIO {})
        val odometry = OdometrySupplier(swerve, Vision(emptyArray()), { time })
        val command = AlignSwerveToShoot(swerve, odometry, { time })
        val scheduler = Scheduler.createIndependentScheduler()
        fun start(errorDegrees: Double) {
            swerve.periodic(); odometry.periodic()
            val hub = PoseLookup.hubPose
            assertTrue(odometry.resetPose(Pose2d(hub.x - 2.0, hub.y, Rotation2d.fromDegrees(errorDegrees))))
            scheduler.schedule(command); scheduler.run()
        }
        fun tick() { time += 0.02; swerve.periodic(); odometry.periodic(); scheduler.run() }
    }

    @Test fun `small heading errors in both directions converge through the module deadband`() {
        for (angle in listOf(-5.0, 5.0, -2.0, 2.0)) {
            AlertSim.resetData()
            val f = Fixture()
            f.start(angle)
            repeat(200) { f.tick() }
            assertFalse(f.scheduler.isRunning(f.command))
            val error = f.odometry.getAngleToHub().minus(f.odometry.pose.rotation).radians
            assertEquals(0.0, error, 0.022)
            assertEquals(0.0, f.swerve.autoSpeeds.omega, 0.03)
        }
    }

    @Test fun `frozen feedback times out and releases drivetrain`() {
        val f = Fixture(false)
        f.start(5.0)
        repeat(260) { f.tick() }
        assertFalse(f.scheduler.isRunning(f.command))
        assertEquals(0.0, f.demand)
    }

    @Test fun `disabled or discontinuous clock stops alignment`() {
        val f = Fixture(false)
        f.start(10.0)
        DriverStationSim.setEnabled(false); DriverStationSim.notifyNewData()
        f.tick()
        assertFalse(f.scheduler.isRunning(f.command))
        assertEquals(0.0, f.demand)
        DriverStationSim.setEnabled(true); DriverStationSim.notifyNewData()
        f.start(10.0)
        f.time += 0.3
        f.scheduler.run()
        assertFalse(f.scheduler.isRunning(f.command))
        assertEquals(0.0, f.demand)
    }
}
