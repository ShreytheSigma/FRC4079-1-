package frc.robot

import frc.robot.mechanisms.OdometrySupplier
import frc.robot.mechanisms.Vision
import frc.robot.mechanisms.drive.Swerve
import frc.robot.mechanisms.drive.gyro.GyroIO
import frc.robot.mechanisms.drive.module.ModuleIO
import frc.robot.utils.FieldPoseSetup
import frc.robot.utils.RobotParameters
import org.junit.jupiter.api.Assertions.*
import org.junit.jupiter.api.BeforeAll
import org.junit.jupiter.api.BeforeEach
import org.junit.jupiter.api.AfterEach
import org.junit.jupiter.api.Test
import org.wpilib.command3.Scheduler
import org.wpilib.hardware.hal.HAL
import org.wpilib.hardware.hal.RobotMode
import org.wpilib.simulation.AlertSim
import org.wpilib.simulation.DriverStationSim
import org.wpilib.simulation.XboxControllerSim
import org.wpilib.tunable.MockTunableBackend
import org.wpilib.tunable.TunableRegistry

class FieldPoseSetupTest {
    companion object { @JvmStatic @BeforeAll fun initialize() { HAL.initialize() } }
    private lateinit var backend: MockTunableBackend

    @BeforeEach fun reset() {
        AlertSim.resetData()
        DriverStationSim.resetData()
        DriverStationSim.setDsAttached(true)
        DriverStationSim.setRobotMode(RobotMode.TELEOPERATED)
        DriverStationSim.setEnabled(false)
        DriverStationSim.notifyNewData()
        TunableRegistry.reset()
        backend = MockTunableBackend()
        TunableRegistry.registerBackend("/", backend)
    }

    @AfterEach fun cleanup() {
        DriverStationSim.setEnabled(false)
        DriverStationSim.notifyNewData()
        Scheduler.getDefault().cancelAll()
        Scheduler.getDefault().defaultEventLoop.clear()
        TunableRegistry.reset()
    }

    private class Fixture {
        var healthy = true
        var speed = 0.0
        val swerve = Swerve(Array<ModuleIO>(4) { object : ModuleIO {
            override fun updateInputs(inputs: ModuleIO.ModuleIOInputs) {
                inputs.data.driveConnected = healthy
                inputs.data.turnConnected = healthy
                inputs.data.turnEncoderConnected = healthy
                inputs.data.driveVelocityRadPerSec = speed / 0.0508
            }
        } }, object : GyroIO {})
        val odometry = OdometrySupplier(swerve, Vision(emptyArray()), { 0.0 })
        val setup = FieldPoseSetup(swerve, odometry)
        fun update() { swerve.periodic(); odometry.periodic() }
        init { update() }
    }

    private fun enter(x: Double = 3.0, y: Double = 2.0, heading: Double = 90.0) {
        backend.setDouble("/Setup/FieldPose/XMeters", x)
        backend.setDouble("/Setup/FieldPose/YMeters", y)
        backend.setDouble("/Setup/FieldPose/HeadingDegrees", heading)
        TunableRegistry.update()
    }

    @Test fun `blank setup rejects and dashboard edits alone cannot initialize pose`() {
        val f = Fixture()
        assertFalse(f.setup.confirm())
        enter()
        assertFalse(f.odometry.readyForShooting)
        assertTrue(f.setup.confirm())
        assertTrue(f.odometry.readyForShooting)
        assertEquals(3.0, f.odometry.pose.x)
        assertEquals(2.0, f.odometry.pose.y)
        assertEquals(90.0, f.odometry.pose.rotation.degrees, 1e-9)
    }

    @Test fun `enabled robot moving wheels or disconnected feedback cannot reset pose`() {
        val f = Fixture()
        enter()
        DriverStationSim.setEnabled(true); DriverStationSim.notifyNewData()
        assertFalse(f.setup.confirm())
        DriverStationSim.setEnabled(false); DriverStationSim.notifyNewData()
        f.speed = 0.1; f.update()
        assertFalse(f.setup.confirm())
        f.speed = 0.0; f.healthy = false; f.update()
        assertFalse(f.setup.confirm())
        f.healthy = true; f.update()
        assertTrue(f.setup.confirm())
    }

    @Test fun `nonfinite out of field and ambiguous heading entries are rejected`() {
        val f = Fixture()
        for ((x, y, heading) in listOf(
            Triple(Double.NaN, 2.0, 0.0), Triple(2.0, Double.POSITIVE_INFINITY, 0.0),
            Triple(2.0, 2.0, Double.NaN), Triple(-1.0, 2.0, 0.0),
            Triple(200.0, 2.0, 0.0), Triple(2.0, 200.0, 0.0), Triple(2.0, 2.0, 360.0),
        )) {
            enter(x, y, heading)
            assertFalse(f.setup.confirm())
        }
        assertFalse(f.odometry.readyForShooting)
    }

    @Test fun `accepted entry is consumed and loss needs newly entered pose`() {
        val f = Fixture()
        enter(); assertTrue(f.setup.confirm())
        f.healthy = false; f.update()
        f.healthy = true; f.update()
        assertFalse(f.setup.confirm())
        assertFalse(f.odometry.readyForShooting)
        enter(); assertTrue(f.setup.confirm())
    }

    @Test fun `actual disabled menu B binding initializes pose without starting a mechanism`() {
        val container = RobotContainer(RobotParameters.Mode.SIM)
        val pad = XboxControllerSim(container.pad)
        val scheduler = Scheduler.getDefault()
        pad.setMenuButton(false); pad.setBButton(false); pad.notifyNewData()
        container.swerve.periodic(); container.odometrySupplier.periodic(); scheduler.run()
        enter()
        pad.setMenuButton(true); pad.setBButton(true); pad.notifyNewData()
        container.swerve.periodic(); container.odometrySupplier.periodic(); scheduler.run()
        assertEquals("Accepted", container.fieldPoseSetup.result)
        assertEquals(3.0, container.odometrySupplier.pose.x)
        assertEquals(90.0, container.odometrySupplier.pose.rotation.degrees, 1e-9)
        assertEquals(0.0, container.swerve.autoSpeeds.vx)
        pad.setMenuButton(false); pad.setBButton(false); pad.notifyNewData()
        scheduler.run()
        container.stopAll()
    }
}
