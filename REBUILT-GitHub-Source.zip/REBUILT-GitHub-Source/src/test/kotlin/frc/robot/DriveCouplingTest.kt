package frc.robot

import frc.robot.utils.swerve.DriveCoupling
import org.junit.jupiter.api.Assertions.*
import org.junit.jupiter.api.Test

class DriveCouplingTest {
    @Test fun `steering alone produces zero wheel travel at any starting azimuth`() {
        val coupling = DriveCoupling(4.5, 7.03125)
        val start = 1.7
        assertEquals(0.0, coupling.wheelPosition(0.0, start), 1e-9)
        val oneTurn = 2.0 * Math.PI
        assertEquals(0.0, coupling.wheelPosition(oneTurn * 4.5 / 7.03125, start + oneTurn), 1e-9)
        assertEquals(0.0, coupling.wheelPosition(-oneTurn * 4.5 / 7.03125, start - oneTurn), 1e-9)
    }

    @Test fun `rolling travel remains after removing steering motion`() {
        val coupling = DriveCoupling(4.5, 7.03125)
        coupling.wheelPosition(0.0, 0.3)
        val rolling = 12.0
        val steering = 1.2
        assertEquals(rolling, coupling.wheelPosition(rolling + steering * 4.5 / 7.03125, 0.3 + steering), 1e-9)
    }

    @Test fun `velocity compensation and measurement are inverses for both rotation directions`() {
        for (ratio in listOf(-4.5, 0.0, 4.5)) {
            val coupling = DriveCoupling(ratio, 7.03125)
            for (wheel in listOf(-50.0, 0.0, 50.0)) {
                for (steer in listOf(-10.0, 0.0, 10.0)) {
                    val demand = coupling.driveVelocity(wheel, steer)
                    assertEquals(wheel, coupling.wheelVelocity(demand, steer), 1e-9)
                }
            }
        }
    }
}
