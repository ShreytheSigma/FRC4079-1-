package frc.robot

import frc.robot.mechanisms.hood.Hood
import frc.robot.mechanisms.hood.HoodCalibration
import frc.robot.mechanisms.hood.HoodIO
import frc.robot.mechanisms.hood.HoodPositionSafety
import frc.robot.mechanisms.hood.SimHoodIO
import org.junit.jupiter.api.Assertions.*
import org.junit.jupiter.api.AfterEach
import org.junit.jupiter.api.BeforeAll
import org.junit.jupiter.api.BeforeEach
import org.junit.jupiter.api.Test
import org.wpilib.hardware.hal.HAL
import org.wpilib.hardware.hal.RobotMode
import org.wpilib.simulation.AlertSim
import org.wpilib.simulation.DriverStationSim

class HoodSafetyTest {
    companion object {
        @JvmStatic @BeforeAll fun initialize() { HAL.initialize() }
    }

    private val calibration = HoodCalibration(
        homeAngleRad = 0.2,
        minAngleRad = 0.1,
        maxAngleRad = 0.6,
        gearRatio = 1.0,
    )

    @BeforeEach fun reset() {
        AlertSim.resetData()
        DriverStationSim.resetData()
        DriverStationSim.setDsAttached(true)
        DriverStationSim.setRobotMode(RobotMode.TELEOPERATED)
        setEnabled(false)
    }

    @AfterEach fun disable() { setEnabled(false) }

    private fun setEnabled(enabled: Boolean) {
        DriverStationSim.setEnabled(enabled)
        DriverStationSim.notifyNewData()
    }

    private class RecordingHoodIO(calibration: HoodCalibration) : HoodIO {
        var measuredPosition = calibration.homeAngleRad
        var output = 0.0
        var failControl = false
        var positionWrites = 0
        val safety = HoodPositionSafety(calibration) { output = 0.0 }

        override fun updateInputs(inputs: HoodIO.HoodIOInputs) {
            inputs.data.hoodConnected = true
            inputs.data.positionControlReady = safety.positionControlReady
            inputs.data.hoodPositionRad = measuredPosition
        }

        override fun setPosition(positionRad: Double) {
            safety.requestPosition(positionRad, true) {
                positionWrites++
                if (!failControl) output = 4.0
                !failControl
            }
        }

        override fun isPositionRequestAccepted(positionRad: Double): Boolean =
            safety.isPositionRequestAccepted(positionRad)

        override fun disablePower() { safety.stop() }

        override fun zeroAtHome(): Boolean = safety.home(true, true) { true }
    }

    @Test fun `targets just outside either limit stop and revoke cached readiness immediately`() {
        val io = RecordingHoodIO(calibration)
        val hood = Hood(io)
        for ((boundary, rejected) in listOf(
            calibration.minAngleRad to calibration.minAngleRad - Math.toRadians(1.0),
            calibration.maxAngleRad to calibration.maxAngleRad + Math.toRadians(1.0),
        )) {
            assertTrue(hood.zeroAtHome())
            io.measuredPosition = boundary
            hood.setPosition(boundary)
            hood.periodic()
            assertTrue(hood.atPosition)
            assertEquals(4.0, io.output)
            val writes = io.positionWrites

            hood.setPosition(rejected)
            assertFalse(hood.atPosition)
            assertFalse(io.safety.positionControlReady)
            assertEquals(0.0, io.output)
            assertEquals(writes, io.positionWrites)
            repeat(3) { hood.periodic() }
            assertEquals(writes, io.positionWrites)
            assertFalse(hood.atPosition)
        }
    }

    @Test fun `failed position write stops previous output before another input refresh`() {
        val io = RecordingHoodIO(calibration)
        val hood = Hood(io)
        assertTrue(hood.zeroAtHome())
        hood.setPosition(calibration.homeAngleRad)
        hood.periodic()
        assertTrue(hood.atPosition)
        assertEquals(4.0, io.output)

        io.failControl = true
        hood.setPosition(calibration.homeAngleRad)
        assertFalse(hood.atPosition)
        assertFalse(io.safety.positionControlReady)
        assertEquals(0.0, io.output)
        val writes = io.positionWrites
        io.failControl = false
        repeat(3) { hood.periodic() }
        assertEquals(writes, io.positionWrites)
        assertFalse(hood.atPosition)
    }

    @Test fun `periodic write failure clears the stored target`() {
        val io = RecordingHoodIO(calibration)
        val hood = Hood(io)
        assertTrue(hood.zeroAtHome())
        hood.setPosition(calibration.homeAngleRad)
        hood.periodic()
        assertTrue(hood.atPosition)
        io.failControl = true
        hood.periodic()
        assertEquals(0.0, io.output)
        assertFalse(hood.atPosition)
        val writes = io.positionWrites
        io.failControl = false
        hood.periodic()
        assertEquals(writes, io.positionWrites)
    }

    @Test fun `failed manual request also stops output and revokes position readiness`() {
        var output = 0.0
        val safety = HoodPositionSafety(calibration) { output = 0.0 }
        assertTrue(safety.home(true, true) { true })
        safety.requestPosition(calibration.homeAngleRad, true) { output = 5.0; true }
        safety.requestPower(0.4, true) { false }
        assertEquals(0.0, output)
        assertFalse(safety.positionControlReady)
    }

    @Test fun `nonfinite demands cannot preserve an accepted target`() {
        val io = RecordingHoodIO(calibration)
        val hood = Hood(io)
        assertTrue(hood.zeroAtHome())
        for (target in listOf(Double.NaN, Double.POSITIVE_INFINITY, Double.NEGATIVE_INFINITY)) {
            hood.setPosition(calibration.homeAngleRad)
            hood.periodic()
            assertTrue(hood.atPosition)
            hood.setPosition(target)
            assertFalse(hood.atPosition)
            assertEquals(0.0, io.output)
        }
    }

    @Test fun `default simulator retains unknown calibration and refuses homing and output`() {
        val io = SimHoodIO()
        val inputs = HoodIO.HoodIOInputs()
        assertFalse(io.zeroAtHome())
        io.setPosition(0.0)
        io.setPower(1.0)
        repeat(10) { io.updateInputs(inputs) }
        assertFalse(inputs.data.positionControlReady)
        assertFalse(io.isPositionRequestAccepted(0.0))
        assertEquals(0.0, inputs.data.hoodAppliedVolts)
        assertTrue(inputs.data.hoodPositionRad.isFinite())
    }

    @Test fun `calibrated simulator requires disabled homing and rehoming after motor reset`() {
        val io = SimHoodIO(calibration)
        val hood = Hood(io)
        val inputs = HoodIO.HoodIOInputs()
        hood.setPosition(calibration.homeAngleRad)
        hood.periodic()
        assertFalse(hood.atPosition)
        setEnabled(true)
        assertFalse(hood.zeroAtHome())
        setEnabled(false)
        assertTrue(hood.zeroAtHome())
        setEnabled(true)
        hood.setPosition(calibration.homeAngleRad)
        hood.periodic()
        assertTrue(hood.atPosition)

        io.simulateMotorReset()
        assertFalse(hood.atPosition)
        hood.periodic()
        io.updateInputs(inputs)
        assertEquals(0.0, inputs.data.hoodAppliedVolts)
        assertFalse(inputs.data.positionControlReady)
        assertFalse(hood.zeroAtHome())
        setEnabled(false)
        assertTrue(hood.zeroAtHome())
        hood.periodic()
        assertFalse(hood.atPosition)
        hood.setPosition(calibration.homeAngleRad)
        hood.periodic()
        assertTrue(hood.atPosition)
    }

    @Test fun `failed homing and lost availability stop and revoke the reference`() {
        var output = 0.0
        val safety = HoodPositionSafety(calibration) { output = 0.0 }
        assertTrue(safety.home(true, true) { true })
        safety.requestPosition(calibration.homeAngleRad, true) { output = 4.0; true }
        assertFalse(safety.home(true, true) { false })
        assertEquals(0.0, output)
        assertFalse(safety.homed)
        assertFalse(safety.positionControlReady)
        assertFalse(safety.home(true, false) { fail("Unavailable hardware must not be homed") })
    }

    @Test fun `simulator rejects nonfinite or inconsistent calibration`() {
        val invalid = listOf(
            calibration.copy(minAngleRad = Double.NaN),
            calibration.copy(maxAngleRad = Double.POSITIVE_INFINITY),
            calibration.copy(homeAngleRad = Double.NaN),
            calibration.copy(minAngleRad = calibration.maxAngleRad),
            calibration.copy(minAngleRad = calibration.maxAngleRad + 0.1),
            calibration.copy(homeAngleRad = calibration.maxAngleRad + 0.1),
            calibration.copy(gearRatio = 0.0),
            calibration.copy(gearRatio = -1.0),
            calibration.copy(gearRatio = Double.NaN),
            calibration.copy(gearRatio = Double.POSITIVE_INFINITY),
        )
        for (values in invalid) {
            val io = SimHoodIO(values)
            val inputs = HoodIO.HoodIOInputs()
            assertFalse(io.zeroAtHome())
            io.setPosition(calibration.homeAngleRad)
            io.setPower(1.0)
            io.updateInputs(inputs)
            assertFalse(inputs.data.positionControlReady)
            assertEquals(0.0, inputs.data.hoodAppliedVolts)
            assertTrue(inputs.data.hoodPositionRad.isFinite())
            assertTrue(inputs.data.hoodVelocityRadPerSec.isFinite())
        }
    }

    @Test fun `simulated manual motion respects both travel limits and permits retreat`() {
        val io = SimHoodIO(calibration)
        val inputs = HoodIO.HoodIOInputs()
        assertTrue(io.zeroAtHome())
        setEnabled(true)
        for ((power, boundary) in listOf(1.0 to calibration.maxAngleRad, -1.0 to calibration.minAngleRad)) {
            repeat(150) {
                io.setPower(power)
                io.updateInputs(inputs)
                assertTrue(inputs.data.hoodPositionRad in calibration.minAngleRad..calibration.maxAngleRad)
                assertTrue(inputs.data.hoodVelocityRadPerSec.isFinite())
                assertFalse(inputs.data.positionControlReady)
            }
            assertEquals(boundary, inputs.data.hoodPositionRad, 1e-9)
            assertEquals(0.0, inputs.data.hoodVelocityRadPerSec)
            assertEquals(0.0, inputs.data.hoodAppliedVolts)
        }
    }

    @Test fun `simulator rejects targets outside travel and nonfinite requests without continuing output`() {
        val io = SimHoodIO(calibration)
        val inputs = HoodIO.HoodIOInputs()
        assertTrue(io.zeroAtHome())
        for (rejected in listOf(
            calibration.minAngleRad - 1e-6, calibration.maxAngleRad + 1e-6,
            Double.NaN, Double.POSITIVE_INFINITY, Double.NEGATIVE_INFINITY,
        )) {
            io.setPosition(calibration.maxAngleRad)
            io.updateInputs(inputs)
            assertTrue(inputs.data.positionControlReady)
            io.setPosition(rejected)
            assertFalse(io.isPositionRequestAccepted(calibration.maxAngleRad))
            io.updateInputs(inputs)
            assertFalse(inputs.data.positionControlReady)
            assertEquals(0.0, inputs.data.hoodAppliedVolts)
        }
        io.setPower(0.5)
        io.setPower(Double.NaN)
        io.updateInputs(inputs)
        assertEquals(0.0, inputs.data.hoodAppliedVolts)
    }
}
