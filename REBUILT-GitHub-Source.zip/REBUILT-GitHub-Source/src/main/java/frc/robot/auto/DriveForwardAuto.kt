package frc.robot.auto

import frc.robot.mechanisms.drive.Swerve
import org.littletonrobotics.junction.Logger
import org.wpilib.command3.Command
import org.wpilib.command3.Coroutine
import org.wpilib.command3.Mechanism
import org.wpilib.driverstation.RobotState
import org.wpilib.math.util.MathUtil
import org.wpilib.system.Timer
import kotlin.math.abs

/** Short commissioning auto, not a field path or a scoring routine. */
class DriveForwardAuto(
    private val swerve: Swerve,
    private val stopAll: () -> Unit,
    private val ownedMechanisms: Set<Mechanism> = setOf(swerve),
    private val settings: Settings = Settings(),
    private val now: () -> Double = { Timer.getTimestamp() },
) : Command {
    data class Settings(
        val speedMetersPerSecond: Double = 0.5,
        val durationSeconds: Double = 2.0,
        val rampSeconds: Double = 0.4,
    ) {
        init {
            require(speedMetersPerSecond.isFinite() && speedMetersPerSecond > 0.0 && speedMetersPerSecond <= 1.0)
            require(durationSeconds.isFinite() && durationSeconds > 0.0 && durationSeconds <= 5.0)
            require(rampSeconds.isFinite() && rampSeconds > 0.0 && rampSeconds <= durationSeconds / 2.0)
        }

        fun speedAt(elapsed: Double): Double {
            if (!elapsed.isFinite() || elapsed <= 0.0 || elapsed >= durationSeconds) return 0.0
            return speedMetersPerSecond * minOf(1.0, elapsed / rampSeconds, (durationSeconds - elapsed) / rampSeconds)
        }
    }

    var result: String = "Not started"
        private set

    override fun name(): String = "Drive Forward and Stop"
    override fun requirements(): Set<Mechanism> = ownedMechanisms + swerve

    private fun finish(reason: String) {
        result = reason
        stopAll()
        swerve.stop()
        Logger.recordOutput("Auto/Result", result)
    }

    override fun run(coroutine: Coroutine) {
        stopAll()
        swerve.stop()
        val start = now()
        val initialHeading = swerve.gyroYaw.radians
        var previous = start
        result = "Running"
        Logger.recordOutput("Auto/Result", result)
        while (true) {
            if (!RobotState.isAutonomousEnabled() || !RobotState.isDSAttached() || RobotState.isEStopped()) {
                finish("Stopped: not enabled autonomous")
                return
            }
            if (!swerve.readyForAuto) {
                finish("Stopped: drivetrain feedback unavailable")
                return
            }
            val current = now()
            if (!start.isFinite() || !current.isFinite() || current < previous || current - previous > 0.25) {
                finish("Stopped: invalid or interrupted clock")
                return
            }
            previous = current
            val elapsed = current - start
            if (elapsed >= settings.durationSeconds) {
                finish("Completed")
                return
            }
            val error = MathUtil.angleModulus(initialHeading - swerve.gyroYaw.radians)
            if (!error.isFinite() || abs(error) > Math.toRadians(30.0)) {
                finish("Stopped: excessive heading error")
                return
            }
            val speed = settings.speedAt(elapsed)
            // Heading is relative to the start, independent of alliance and the driver's B reset.
            val rotation = (2.0 * error).coerceIn(-0.6, 0.6)
            swerve.setDriveSpeeds(speed, 0.0, rotation, false)
            Logger.recordOutput("Auto/ElapsedSeconds", elapsed)
            Logger.recordOutput("Auto/ForwardMetersPerSecond", speed)
            coroutine.yield()
        }
    }

    override fun onCancel() = finish("Canceled")
}
