package frc.robot.auto.advanced

import frc.robot.mechanisms.drive.Swerve
import frc.robot.utils.RobotParameters.SwerveParameters
import org.littletonrobotics.junction.Logger
import org.wpilib.command3.Command
import org.wpilib.command3.Coroutine
import org.wpilib.command3.Mechanism
import org.wpilib.driverstation.RobotState
import org.wpilib.math.controller.PIDController
import org.wpilib.math.geometry.Pose2d
import org.wpilib.math.geometry.Translation2d
import org.wpilib.math.kinematics.ChassisVelocities
import org.wpilib.math.kinematics.SwerveDriveOdometry
import org.wpilib.math.trajectory.TrapezoidProfile
import org.wpilib.math.util.MathUtil
import org.wpilib.system.Timer
import kotlin.math.abs
import kotlin.math.hypot

/** Low-speed stop-at-waypoint paths. Coordinates are meters forward/left from the start. */
class RelativePathAuto(
    private val swerve: Swerve,
    private val stopAll: () -> Unit,
    waypoints: List<Translation2d>,
    private val ownedMechanisms: Set<Mechanism> = setOf(swerve),
    private val now: () -> Double = { Timer.getTimestamp() },
) : Command {
    private val route = waypoints.toList()

    init {
        require(route.size in 1..4) { "Auto needs one to four waypoints" }
        var previous = Translation2d.ZERO
        var distance = 0.0
        var nominalSeconds = 0.0
        for (point in route) {
            require(point.x.isFinite() && point.y.isFinite() && point.norm <= 3.0)
            val length = point.getDistance(previous)
            require(length in 0.1..2.0) { "Each auto leg must be 0.1 to 2 meters" }
            distance += length
            val profile = TrapezoidProfile(TrapezoidProfile.Constraints(0.45, 0.4))
            profile.calculate(0.0, TrapezoidProfile.State(), TrapezoidProfile.State(length, 0.0))
            nominalSeconds += profile.duration() + 0.2
            previous = point
        }
        require(distance <= 4.0) { "Auto path is too long" }
        require(nominalSeconds <= 10.0) { "Auto needs at least two seconds of timeout margin" }
    }

    var result = "Not started"
        private set
    var localPose = Pose2d()
        private set
    var requestedVelocity = ChassisVelocities()
        private set

    override fun name() = "Profiled Relative Path"
    override fun requirements() = ownedMechanisms + swerve

    private fun finish(reason: String) {
        result = reason
        stopAll()
        swerve.stop()
        requestedVelocity = ChassisVelocities()
        Logger.recordOutput("Auto/Result", reason)
        Logger.recordOutput("Auto/RequestedVelocity", ChassisVelocities())
    }

    override fun run(coroutine: Coroutine) {
        stopAll()
        swerve.stop()
        if (!swerve.readyForAuto || hypot(swerve.autoSpeeds.vx, swerve.autoSpeeds.vy) > 0.15 ||
            abs(swerve.autoSpeeds.omega) > 0.2) {
            finish("Stopped: drivetrain not ready or not stationary")
            return
        }
        // Independent odometry avoids uninitialized field poses and vision jumps changing the route.
        val odometry = SwerveDriveOdometry(
            SwerveParameters.PhysicalParameters.kinematics,
            swerve.gyroYaw, swerve.modulePositions, Pose2d(),
        )
        val xController = PIDController(1.5, 0.0, 0.0)
        val yController = PIDController(1.5, 0.0, 0.0)
        val start = now()
        var previousTime = start
        var previousPose = Pose2d()
        var lastRequest = Translation2d.ZERO
        var lastRotation = 0.0
        var legStart = Translation2d.ZERO
        result = "Running"
        Logger.recordOutput("Auto/Result", result)
        for ((index, target) in route.withIndex()) {
            val legVector = target.minus(legStart)
            val length = legVector.norm
            val direction = legVector.div(length)
            val profile = TrapezoidProfile(TrapezoidProfile.Constraints(0.45, 0.4))
            val initial = TrapezoidProfile.State(0.0, 0.0)
            val goal = TrapezoidProfile.State(length, 0.0)
            profile.calculate(0.0, initial, goal)
            val duration = profile.duration()
            val legTime = previousTime
            var settledSince: Double? = null
            var progressSince: Double? = null
            var progressPosition = previousPose.translation
            while (true) {
                if (!RobotState.isAutonomousEnabled() || !RobotState.isDSAttached() || RobotState.isEStopped()) {
                    finish("Stopped: not enabled autonomous"); return
                }
                if (!swerve.readyForAuto) { finish("Stopped: drivetrain feedback unavailable"); return }
                val current = now()
                val dt = current - previousTime
                if (!start.isFinite() || !current.isFinite() || dt < 0.0 || dt > 0.25) {
                    finish("Stopped: invalid or interrupted clock"); return
                }
                previousTime = current
                if (current - start >= 12.0 || current - legTime >= duration + 2.0) {
                    finish("Stopped: path timeout"); return
                }
                localPose = odometry.update(swerve.gyroYaw, swerve.modulePositions)
                val headingError = MathUtil.angleModulus(-localPose.rotation.radians)
                if (!localPose.x.isFinite() || !localPose.y.isFinite() || !headingError.isFinite() ||
                    localPose.translation.getDistance(previousPose.translation) > 0.15) {
                    finish("Stopped: invalid or discontinuous odometry"); return
                }
                previousPose = localPose
                if (abs(headingError) > Math.toRadians(25.0)) {
                    finish("Stopped: excessive heading error"); return
                }
                val elapsed = current - legTime
                val reference = profile.calculate(elapsed.coerceAtMost(duration), initial, goal)
                val desired = legStart.plus(direction.times(reference.position))
                if (localPose.translation.getDistance(desired) > 0.45) {
                    finish("Stopped: excessive tracking error"); return
                }
                val atGoal = elapsed >= duration && localPose.translation.getDistance(target) <= 0.05 &&
                    abs(headingError) <= Math.toRadians(3.0) &&
                    hypot(swerve.autoSpeeds.vx, swerve.autoSpeeds.vy) < 0.08 && abs(swerve.autoSpeeds.omega) < 0.1
                settledSince = if (atGoal) settledSince ?: current else null
                if (settledSince != null && current - settledSince >= 0.2) break

                var request = Translation2d(
                    direction.x * reference.velocity + xController.calculate(localPose.x, desired.x),
                    direction.y * reference.velocity + yController.calculate(localPose.y, desired.y),
                )
                if (request.norm > 0.6) request = request.times(0.6 / request.norm)
                val delta = request.minus(lastRequest)
                if (delta.norm > 0.6 * dt) request = lastRequest.plus(delta.times(0.6 * dt / delta.norm))
                // At 3 degrees this exceeds the module's 0.05 m/s cutoff for pure rotation.
                val rotation = (3.0 * headingError).coerceIn(-0.6, 0.6)
                    .coerceIn(lastRotation - dt, lastRotation + dt)
                if (request.norm > 0.15) {
                    if (progressSince == null) { progressSince = current; progressPosition = localPose.translation }
                    if (current - progressSince >= 0.75) {
                        if (localPose.translation.getDistance(progressPosition) < 0.03) {
                            finish("Stopped: no measured progress"); return
                        }
                        progressSince = current
                        progressPosition = localPose.translation
                    }
                } else progressSince = null
                lastRequest = request
                lastRotation = rotation
                val speeds = ChassisVelocities(request.x, request.y, rotation).toRobotRelative(localPose.rotation)
                requestedVelocity = speeds
                swerve.setDriveSpeeds(speeds.vx, speeds.vy, speeds.omega, false)
                Logger.recordOutput("Auto/LocalPose", localPose)
                Logger.recordOutput("Auto/Waypoint", index + 1)
                Logger.recordOutput("Auto/Target", Pose2d(target, localPose.rotation))
                Logger.recordOutput("Auto/ElapsedSeconds", current - start)
                Logger.recordOutput("Auto/RequestedVelocity", speeds)
                coroutine.yield()
            }
            // Every leg ends at rest before a direction change; faults never advance to another leg.
            swerve.setDriveSpeeds(0.0, 0.0, 0.0, false)
            lastRequest = Translation2d.ZERO
            lastRotation = 0.0
            legStart = target
        }
        finish("Completed")
    }

    override fun onCancel() = finish("Canceled")
}
