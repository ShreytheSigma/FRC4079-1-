# Autonomous Routines

This folder is separate from teleop commands. Core robot commissioning comes first.

## Selection

Use the project's matching WPILib 2027 alpha dashboard/tunable interface, connected to SystemCore. The selectable is `Auto/Routine` (under the standard `/Tunables` NetworkTables prefix).

- `Do Nothing`: default. Clears mechanism outputs and does not move.
- `Drive Forward and Stop`: ramps to 0.5 m/s, holds starting heading, and stops after 2 seconds. The nominal speed-profile integral is 0.8 m, not a guaranteed measured distance.
- `Taxi 1.5 m (closed loop)`: measured-distance drive forward 1.5 m with profiled acceleration/deceleration and heading hold. Implemented in the separate `advanced/` subfolder.
- `TEST ONLY: forward then left`: stop at (0.75 m forward, 0 m left), then strafe to (0.75 m forward, 0.5 m left). A two-leg commissioning demonstration, not a validated competition field route.

Select while disabled. `Robot.autonomousInit()` samples the selection once and creates a fresh command. Changing the selection during a run does not change that run. An unknown selection falls back to Do Nothing. Enable Autonomous through Driver Station only after checking the robot and clearing its path.

## Preconditions

First verify all four modules' angle offsets, positive drive/steer directions, feedback, Pro licenses and gains with wheels off the ground. Then verify low-speed teleop on a clear floor. Point the robot's physical forward direction into an unobstructed area before trying auto. This routine has no obstacle detection and must not be used near people or field obstructions.

The routine is robot-relative: it does not require an alliance origin, AprilTag pose, driver B reset, or a calibrated intake/hood. It does not collect or shoot balls. When gyro data is unavailable, the drivetrain's existing wheel-derived heading is used; that is not an independent heading sensor.

## Stop Conditions

- Natural completion or command cancellation.
- Robot disabled, outside autonomous, E-stopped, or Driver Station detached.
- Missing/invalid module feedback or latched swerve fault.
- Heading error exceeding 30 degrees from the initial heading.
- Invalid/backward clock, or a scheduler interval exceeding 0.25 seconds.

Fault exits do not automatically restart after recovery. Logs include `Auto/Selected`, `Auto/Result`, `Auto/ElapsedSeconds`, and `Auto/ForwardMetersPerSecond`.

`DriveForwardAuto.Settings` bounds speed to at most 1 m/s and duration to at most 5 seconds; defaults are deliberately lower. Tests cover the actual Commands v3 scheduler and WPILib motor physics. No physical-robot validation is claimed.

## Profiled Paths

`advanced/RelativePathAuto.kt` uses WPILib `TrapezoidProfile`, PID controllers and `SwerveDriveOdometry`. Its local pose is zeroed only inside the routine, from the measured wheel positions and initial heading. It does not reset global field odometry, depend on driver heading zero, or accept vision corrections. Forward/left always refer to the robot's orientation when the routine starts. There is no alliance mirroring.

Each leg profiles at 0.45 m/s and 0.4 m/s^2. Feedback requests are capped at 0.6 m/s and limited to 0.6 m/s^2; rotation is capped at 0.6 rad/s and limited to 1 rad/s^2. It stops at every waypoint and requires 0.2 seconds within 5 cm and 3 degrees with low measured velocity. These are commissioning settings, not hardware-tuned gains or guaranteed position accuracy.

Additional aborts: robot not stationary at start, odometry jump over 15 cm per update, heading error over 25 degrees, reference-tracking error over 45 cm, no measured progress over 0.75 seconds at significant demand, per-leg timeout, and a 12-second overall timeout. Every completion/cancel/fault removes outputs. The motion-limiting ramp is deliberately bypassed for emergency/fault stops. Auto owns all motor mechanisms so teleop commands cannot compete with it.

Custom routes are rejected before motion if their nominal profile plus settling time exceeds 10 seconds, preserving at least two seconds of overall timeout margin. Heading correction is chosen to clear the existing module low-speed cutoff at the 3-degree completion boundary; both positive and negative 4-degree endpoint disturbances are covered by simulation tests.

Logs add `Auto/LocalPose`, `Auto/Target`, `Auto/Waypoint`, and `Auto/RequestedVelocity`. All moving routines require a clear route including the robot's full footprint and stopping margin. Wheel slip, bad offsets, incorrect gearing and mechanical binding can invalidate odometry; these checks are not collision avoidance.

No scoring routine or AI ball recognition is enabled: camera calibration, field pose, arm references, shooter lookup and real ball-handling behavior are not verified. Keep Do Nothing selected until an on-robot test succeeds.

Reference: [WPILib trapezoidal motion profiles](https://docs.wpilib.org/en/stable/docs/software/advanced-controls/controllers/trapezoidal-profiles.html). The code uses the project's pinned 2027 alpha API, which differs from stable 2026 examples.
