package frc.robot.auto

import frc.robot.mechanisms.drive.Swerve
import frc.robot.auto.advanced.RelativePathAuto
import org.wpilib.math.geometry.Translation2d
import org.littletonrobotics.junction.Logger
import org.wpilib.command3.Command
import org.wpilib.command3.Coroutine
import org.wpilib.command3.Mechanism
import org.wpilib.tunable.Selectable
import org.wpilib.tunable.Tunables

/** Selection is sampled once at autonomousInit, never changed during a run. */
class AutoManager(
    private val swerve: Swerve,
    private val stopAll: () -> Unit,
    private val mechanisms: Set<Mechanism>,
) {
    enum class Routine(val label: String) {
        DO_NOTHING("Do Nothing"),
        DRIVE_FORWARD("Drive Forward and Stop"),
        TAXI_DISTANCE("Taxi 1.5 m (closed loop)"),
        TWO_LEG_TEST("TEST ONLY: forward then left"),
    }

    private val chooser = Selectable<Routine>().apply {
        addDefault(Routine.DO_NOTHING.label, Routine.DO_NOTHING)
        Routine.entries.filter { it != Routine.DO_NOTHING }.forEach { add(it.label, it) }
    }

    init { Tunables.publish("/Auto/Routine", chooser) }

    fun createSelected(): Command = create(chooser.selected ?: Routine.DO_NOTHING)

    fun create(routine: Routine): Command {
        Logger.recordOutput("Auto/Selected", routine.label)
        return when (routine) {
            Routine.DRIVE_FORWARD -> DriveForwardAuto(swerve, stopAll, mechanisms)
            Routine.TAXI_DISTANCE -> RelativePathAuto(swerve, stopAll, listOf(Translation2d(1.5, 0.0)), mechanisms)
            Routine.TWO_LEG_TEST -> RelativePathAuto(
                swerve, stopAll, listOf(Translation2d(0.75, 0.0), Translation2d(0.75, 0.5)), mechanisms,
            )
            Routine.DO_NOTHING -> object : Command {
                override fun name(): String = "Do Nothing Auto"
                override fun requirements(): Set<Mechanism> = mechanisms + swerve
                override fun run(coroutine: Coroutine) {
                    stopAll()
                    swerve.stop()
                    Logger.recordOutput("Auto/Result", "Do Nothing")
                }
                override fun onCancel() { stopAll(); swerve.stop() }
            }
        }
    }
}
