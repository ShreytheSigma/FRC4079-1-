package frc.robot.utils

import org.wpilib.driverstation.Alliance
import org.wpilib.driverstation.MatchState
import org.wpilib.math.geometry.Pose2d
import org.wpilib.math.geometry.Rotation2d
import org.wpilib.fields.Fields

object PoseLookup {
    // All poses use the blue-alliance origin, including the red hub.
    private val field = Fields.FRC_2026_REBUILT_WELDED.loadField()
    private fun hubBetween(firstTag: Int, oppositeTag: Int): Pose2d {
        val first = field.getTagPose(firstTag).orElseThrow()
        val opposite = field.getTagPose(oppositeTag).orElseThrow()
        return Pose2d((first.x + opposite.x) / 2.0, (first.y + opposite.y) / 2.0, Rotation2d.ZERO)
    }
    private val RED_HUB_POSE = hubBetween(4, 10)
    private val BLUE_HUB_POSE = hubBetween(26, 20)

    val ally: Alliance
        get() = MatchState.getAlliance().orElse(Alliance.BLUE) ?: Alliance.BLUE

    val hubPose: Pose2d
        get() =
            if (ally == Alliance.RED) {
                RED_HUB_POSE
            } else {
                BLUE_HUB_POSE
            }
}
