package frc.robot.utils.swerve

/** Removes drive sensor motion caused by steering; inputs use mechanism radians. */
class DriveCoupling(coupledMotorRotationsPerAzimuthRotation: Double, driveReduction: Double) {
    private val wheelRotationsPerAzimuthRotation: Double
    private var initialAzimuth: Double? = null

    init {
        require(coupledMotorRotationsPerAzimuthRotation.isFinite())
        require(driveReduction.isFinite() && driveReduction > 0.0)
        wheelRotationsPerAzimuthRotation = coupledMotorRotationsPerAzimuthRotation / driveReduction
    }

    fun wheelPosition(drivePositionRad: Double, azimuthPositionRad: Double): Double {
        // The drive encoder is zeroed at boot; preserve that origin for any boot azimuth.
        val reference = initialAzimuth ?: azimuthPositionRad.also { initialAzimuth = it }
        return drivePositionRad - (azimuthPositionRad - reference) * wheelRotationsPerAzimuthRotation
    }

    fun wheelVelocity(driveVelocityRadPerSec: Double, azimuthVelocityRadPerSec: Double): Double =
        driveVelocityRadPerSec - azimuthVelocityRadPerSec * wheelRotationsPerAzimuthRotation

    fun driveVelocity(wheelVelocityRadPerSec: Double, azimuthVelocityRadPerSec: Double): Double =
        wheelVelocityRadPerSec + azimuthVelocityRadPerSec * wheelRotationsPerAzimuthRotation
}
