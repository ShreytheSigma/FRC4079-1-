package frc.robot.utils

import frc.robot.mechanisms.OdometrySupplier
import frc.robot.mechanisms.drive.Swerve
import org.littletonrobotics.junction.Logger
import org.wpilib.driverstation.RobotState
import org.wpilib.fields.Fields
import org.wpilib.math.geometry.Pose2d
import org.wpilib.math.geometry.Rotation2d
import org.wpilib.tunable.Tunables
import kotlin.math.abs

/** Operator-supplied blue-origin pose. Dashboard edits alone never reset localization. */
class FieldPoseSetup(
    private val swerve: Swerve,
    private val odometry: OdometrySupplier,
) {
    private val xMeters = Tunables.addDouble("/Setup/FieldPose/XMeters", Double.NaN)
    private val yMeters = Tunables.addDouble("/Setup/FieldPose/YMeters", Double.NaN)
    private val headingDegrees = Tunables.addDouble("/Setup/FieldPose/HeadingDegrees", Double.NaN)

    var result = "Not initialized"
        private set

    fun confirm(): Boolean {
        val x = xMeters.get()
        val y = yMeters.get()
        val heading = headingDegrees.get()
        val field = Fields.FRC_2026_REBUILT_WELDED
        result = when {
            !RobotState.isDisabled() -> "Rejected: robot must be disabled"
            !swerve.readyForAuto -> "Rejected: drive feedback unavailable"
            swerve.moduleStates.any { !it.velocity.isFinite() || abs(it.velocity) > 0.05 } ->
                "Rejected: wheels must be stationary"
            !x.isFinite() || !y.isFinite() || !heading.isFinite() ||
                x !in 0.0..field.length || y !in 0.0..field.width || heading !in -180.0..180.0 ->
                "Rejected: enter measured blue-origin X, Y and heading"
            !odometry.resetPose(Pose2d(x, y, Rotation2d.fromDegrees(heading))) ->
                "Rejected: pose reset failed"
            else -> "Accepted"
        }
        Logger.recordOutput("Setup/FieldPose/Result", result)
        if (result != "Accepted") return false
        // Consume the entry so feedback loss cannot be cleared with stale coordinates.
        xMeters.set(Double.NaN)
        yMeters.set(Double.NaN)
        headingDegrees.set(Double.NaN)
        return true
    }
}
