package frc.robot.utils.phoenix

import com.ctre.phoenix6.StatusCode
import org.littletonrobotics.junction.Logger
import org.wpilib.util.Alert

object PhoenixConfiguration {
    private val alerts = mutableMapOf<String, Alert>()

    fun apply(name: String, action: () -> StatusCode): Boolean {
        var status = StatusCode.OK
        for (attempt in 1..5) {
            status = action()
            if (status.isOK) break
        }
        Logger.recordOutput("Configuration/$name", status.toString())
        alerts.getOrPut(name) {
            Alert("Hardware configuration", name, "Failed to configure $name. Check CAN bus, ID, firmware and power.", Alert.Level.HIGH)
        }.set(!status.isOK)
        return status.isOK
    }
}
