package frc.robot.commands.driving

import frc.robot.mechanisms.drive.Swerve
import frc.robot.utils.RobotParameters
import org.littletonrobotics.junction.Logger
import org.wpilib.command3.Command
import org.wpilib.command3.Coroutine
import org.wpilib.command3.Mechanism
import org.wpilib.driverstation.XboxController
import org.wpilib.math.util.MathUtil
import kotlin.math.hypot
import org.wpilib.driverstation.RobotState as DriverStationState
import kotlin.math.abs

/** Command to control the robot's swerve drive using the Xbox controller. */
class PadDrive(
    private val swerve: Swerve,
    private val pad: XboxController,
) : Command {
    /**
     * Called every time the scheduler runs while the command is scheduled. This method retrieves the
     * current position from the controller, calculates the rotation, logs the joystick values, and
     * sets the drive speeds for the swerve subsystem.
     */
    override fun run(coroutine: Coroutine) {
        while (true) {
            if (DriverStationState.isTeleopEnabled()) {
                driveOnce()
            } else {
                swerve.stop()
            }
            coroutine.yield()
        }
    }

    private fun driveOnce() {
        val position = positionSet(pad)
        val rotation = -MathUtil.applyDeadband(pad.rightX, 0.1) * RobotParameters.SwerveParameters.PhysicalParameters.MAX_ANGULAR_SPEED

        Logger.recordOutput("PadDrive/XJoystick", position.first)
        Logger.recordOutput("PadDrive/YJoystick", position.second)
        Logger.recordOutput("PadDrive/Rotation", rotation)

        swerve.setDriveSpeeds(position.second, position.first, rotation * 0.5)
    }

    override fun onCancel() {
        swerve.stop()
    }

    override fun name(): String = "PadDrive"

    override fun requirements(): Set<Mechanism> = setOf(swerve)

    companion object {
        /**
         * Sets the position based on the input from the controller.
         *
         * @param pad The controller.
         * @return The coordinate representing the position. The first element is the x-coordinate, and
         * the second element is the y-coordinate.
         */
        fun positionSet(pad: XboxController): Pair<Double, Double> {
            val x = -pad.leftX
            val y = -pad.leftY
            val magnitude = hypot(x, y)
            if (magnitude == 0.0) return 0.0 to 0.0
            val speed = MathUtil.applyDeadband(magnitude.coerceAtMost(1.0), RobotParameters.SwerveParameters.Thresholds.JOYSTICK_TRANSLATION_DEADBAND) *
                RobotParameters.SwerveParameters.PhysicalParameters.MAX_SPEED
            return x / magnitude * speed to y / magnitude * speed
        }
    }
}
