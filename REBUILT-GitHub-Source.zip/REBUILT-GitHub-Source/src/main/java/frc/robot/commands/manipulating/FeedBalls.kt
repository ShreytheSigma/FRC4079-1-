package frc.robot.commands.manipulating

import frc.robot.mechanisms.transport.Transport
import frc.robot.mechanisms.transport.TransportIO
import org.wpilib.command3.Command
import org.wpilib.command3.Coroutine
import org.wpilib.command3.Mechanism

class FeedBalls(
    val transport: Transport,
    private val ready: () -> Boolean = { true },
) : Command {
    override fun name(): String = "FeedBalls"

    override fun requirements(): Set<Mechanism> = setOf(transport)

    override fun run(coroutine: Coroutine) {
        while (true) {
            if (ready()) transport.setState(TransportIO.TransportState.ACTIVE) else transport.disable()
            coroutine.yield()
        }
    }

    override fun onCancel() {
        transport.disable()
    }
}
