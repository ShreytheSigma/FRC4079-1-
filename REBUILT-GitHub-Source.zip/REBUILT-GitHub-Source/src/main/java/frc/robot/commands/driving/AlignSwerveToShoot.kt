package frc.robot.commands.driving

import frc.robot.mechanisms.OdometrySupplier
import frc.robot.mechanisms.drive.Swerve
import frc.robot.utils.RobotParameters
import org.littletonrobotics.junction.Logger
import org.wpilib.command3.Command
import org.wpilib.command3.Coroutine
import org.wpilib.command3.Mechanism
import org.wpilib.driverstation.RobotState
import org.wpilib.math.geometry.Rotation2d
import org.wpilib.system.Timer
import kotlin.math.abs
import kotlin.math.sign

/**
 * Points the robot at the hub so it can shoot. The hub is chosen based on the current alliance (see
 * [frc.robot.utils.PoseLookup]). Only rotates in place; the robot does not translate.
 */
class AlignSwerveToShoot(
    private val swerve: Swerve,
    private val odometrySupplier: OdometrySupplier,
    private val now: () -> Double = { Timer.getTimestamp() },
) : Command {
    var angleToTurn: Rotation2d = Rotation2d.ZERO

    init {
        RobotParameters.SwerveParameters.PIDParameters.ROTATIONAL_PID
            .enableContinuousInput(-Math.PI, Math.PI)
        RobotParameters.SwerveParameters.PIDParameters.ROTATIONAL_PID
            .setTolerance(TOLERANCE_RAD)
    }

    override fun name(): String = "AlignSwerveToShoot"

    override fun requirements(): Set<Mechanism> = setOf(swerve)

    override fun run(coroutine: Coroutine) {
        RobotParameters.SwerveParameters.PIDParameters.ROTATIONAL_PID
            .reset()
        val started = now()
        var previous = started

        while (true) {
            val timestamp = now()
            if (!RobotState.isEnabled() || !odometrySupplier.readyForShooting ||
                !timestamp.isFinite() || !started.isFinite() || timestamp < previous ||
                timestamp - previous > 0.25 || timestamp - started >= 5.0) break
            previous = timestamp
            angleToTurn = odometrySupplier.getAngleToHub()
            val currentYaw = odometrySupplier.pose.rotation
            val pidOutput =
                RobotParameters.SwerveParameters.PIDParameters.ROTATIONAL_PID
                    .calculate(currentYaw.radians, angleToTurn.radians)
            if (!pidOutput.isFinite()) break
            if (RobotParameters.SwerveParameters.PIDParameters.ROTATIONAL_PID.atSetpoint()) break
            // Clear the wheel-speed hold threshold even for a small remaining yaw error.
            val output = sign(pidOutput) * abs(pidOutput).coerceIn(MIN_ROTATION_RAD_PER_SEC, 1.0)

            Logger.recordOutput("AlignSwerveToShoot/AngleToTurnDegrees", angleToTurn.degrees)
            Logger.recordOutput("AlignSwerveToShoot/CurrentYawDegrees", currentYaw.degrees)
            Logger.recordOutput("AlignSwerveToShoot/Output", output)

            swerve.setDriveSpeeds(0.0, 0.0, output, false)
            coroutine.yield()
        }
        swerve.stop()
    }

    override fun onCancel() {
        swerve.stop()
        RobotParameters.SwerveParameters.PIDParameters.ROTATIONAL_PID
            .reset()
    }

    companion object {
        private const val TOLERANCE_RAD = 0.02
        private val MIN_ROTATION_RAD_PER_SEC =
            1.1 * RobotParameters.SwerveParameters.Thresholds.STATE_SPEED_THRESHOLD /
                RobotParameters.SwerveParameters.PhysicalParameters.MODULE_LOCATIONS.minOf { it.norm }
    }
}
