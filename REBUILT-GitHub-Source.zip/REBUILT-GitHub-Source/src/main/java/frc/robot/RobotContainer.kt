package frc.robot

import frc.robot.auto.AutoManager
import frc.robot.commands.driving.PadDrive
import frc.robot.commands.manipulating.DeployIntake
import frc.robot.commands.manipulating.FeedBalls
import frc.robot.commands.manipulating.SpinIntake
import frc.robot.commands.shooting.ShootWithDistance
import frc.robot.mechanisms.OdometrySupplier
import frc.robot.mechanisms.Vision
import frc.robot.mechanisms.drive.Swerve
import frc.robot.mechanisms.drive.gyro.RealGyroIO
import frc.robot.mechanisms.drive.gyro.GyroIO
import frc.robot.mechanisms.drive.module.SimModuleIO
import frc.robot.mechanisms.intake.SimIntakeIO
import frc.robot.mechanisms.pivot.SimPivotIO
import frc.robot.mechanisms.shooter.SimShooterIO
import frc.robot.mechanisms.hood.SimHoodIO
import frc.robot.mechanisms.transport.SimsTransportIO
import frc.robot.mechanisms.drive.module.ModuleIO
import frc.robot.mechanisms.drive.module.RealModuleIO
import frc.robot.mechanisms.hood.Hood
import frc.robot.mechanisms.hood.HoodIO
import frc.robot.mechanisms.hood.RealHoodIO
import frc.robot.mechanisms.intake.Intake
import frc.robot.mechanisms.intake.IntakeIO
import frc.robot.mechanisms.intake.RealIntakeIO
import frc.robot.mechanisms.pivot.Pivot
import frc.robot.mechanisms.pivot.PivotIO
import frc.robot.mechanisms.pivot.RealPivotIO
import frc.robot.mechanisms.shooter.RealShooterIO
import frc.robot.mechanisms.shooter.Shooter
import frc.robot.mechanisms.shooter.ShooterIO
import frc.robot.mechanisms.transport.RealTransportIO
import frc.robot.mechanisms.transport.Transport
import frc.robot.mechanisms.transport.TransportIO
import frc.robot.utils.RobotParameters
import frc.robot.utils.ShotTable
import frc.robot.utils.FieldPoseSetup
import org.wpilib.command3.Command
import org.wpilib.command3.Trigger
import org.wpilib.driverstation.RobotState as DriverStationState
import org.wpilib.driverstation.XboxController

/**
 * This class is where the bulk of the robot should be declared. Since Command-based is a
 * "declarative" paradigm, very little robot logic should actually be handled in the [Robot]
 * periodic methods (other than the scheduler calls). Instead, the structure of the robot (including
 * subsystems, commands, and trigger mappings) should be declared here.
 */
class RobotContainer(private val mode: RobotParameters.Mode = RobotParameters.GlobalParameters.MODE) {
    val pad: XboxController = XboxController(0)

    // CREATE IOS

    val moduleIOs: Array<ModuleIO> =
        RobotParameters.SwerveParameters.MODULE_CONFIGS
            .map { config -> when (mode) {
                RobotParameters.Mode.REAL -> RealModuleIO(config)
                RobotParameters.Mode.SIM -> SimModuleIO()
                RobotParameters.Mode.REPLAY -> object : ModuleIO {}
            } }
            .toTypedArray()

    val intakeIO: IntakeIO = when (mode) {
        RobotParameters.Mode.REAL -> RealIntakeIO()
        RobotParameters.Mode.SIM -> SimIntakeIO()
        RobotParameters.Mode.REPLAY -> object : IntakeIO {}
    }
    val pivotIO: PivotIO = when (mode) {
        RobotParameters.Mode.REAL -> RealPivotIO()
        RobotParameters.Mode.SIM -> SimPivotIO()
        RobotParameters.Mode.REPLAY -> object : PivotIO {}
    }
    val shooterIO: ShooterIO = when (mode) {
        RobotParameters.Mode.REAL -> RealShooterIO()
        RobotParameters.Mode.SIM -> SimShooterIO()
        RobotParameters.Mode.REPLAY -> object : ShooterIO { override fun disablePower() {} }
    }
    val transportIO: TransportIO = when (mode) {
        RobotParameters.Mode.REAL -> RealTransportIO()
        RobotParameters.Mode.SIM -> SimsTransportIO()
        RobotParameters.Mode.REPLAY -> object : TransportIO {}
    }
    val hoodIO: HoodIO = when (mode) {
        RobotParameters.Mode.REAL -> RealHoodIO()
        RobotParameters.Mode.SIM -> SimHoodIO()
        RobotParameters.Mode.REPLAY -> object : HoodIO {}
    }

    // CREATE ALL SUBSYSTEMS HERE

    val swerve: Swerve = Swerve(moduleIOs, if (mode == RobotParameters.Mode.REAL) RealGyroIO else object : GyroIO {})
    val intake: Intake = Intake(intakeIO)
    val pivot: Pivot = Pivot(pivotIO)
    val shooter: Shooter = Shooter(shooterIO)
    val transport: Transport = Transport(transportIO, ::readyToFeed)
    val hood: Hood = Hood(hoodIO)

    // VIRTUAL SUBSYSTEMS
    val vision: Vision = Vision(if (mode == RobotParameters.Mode.REAL) RobotParameters.VisionParameters.CAMERAS else emptyArray())
    val odometrySupplier: OdometrySupplier = OdometrySupplier(swerve, vision)
    val fieldPoseSetup = FieldPoseSetup(swerve, odometrySupplier)

    val autoManager = AutoManager(swerve, ::stopAll, setOf(swerve, intake, pivot, shooter, transport, hood))

    /** The container for the robot. Contains subsystems, IO devices, and commands.  */
    init {
        swerve.defaultCommand = PadDrive(swerve, pad)
        configureBindings()
    }

    /**
     * Use this method to define your trigger->command mappings. Triggers can be created via the
     * [Trigger] or our [JoystickButton] constructor with an arbitrary predicate, or via
     * the named factories in [CommandGenericHID]'s subclasses for [ ]/[CommandPS4Controller] controllers or [CommandJoystick].
     */
    private fun configureBindings() {
        Trigger { DriverStationState.isTeleopEnabled() && pad.aButton }
            .whileTrue(SpinIntake(intake))
        Trigger { DriverStationState.isTeleopEnabled() && pad.bButton }
            .onTrue(swerve.run { swerve.resetGyro() }.named("Zero driver heading"))
        Trigger { DriverStationState.isTeleopEnabled() && pad.xButton }
            .whileTrue(ShootWithDistance(shooter, hood, odometrySupplier))
        Trigger { DriverStationState.isTeleopEnabled() && pad.yButton }
            .whileTrue(DeployIntake(pivot))
        Trigger { DriverStationState.isTeleopEnabled() && pad.rightBumperButton }
            .whileTrue(FeedBalls(transport, ::readyToFeed))
        Trigger { DriverStationState.isDisabled() && pad.menuButton && pad.viewButton }
            .onTrue(Command.noRequirements { pivot.zeroAtStow() }.named("Confirm pivot physically at stow"))
        Trigger { DriverStationState.isDisabled() && pad.menuButton && pad.xButton }
            .onTrue(Command.noRequirements { hood.zeroAtHome() }.named("Confirm hood physically at home"))
        Trigger { DriverStationState.isDisabled() && pad.menuButton && pad.bButton }
            .onTrue(Command.noRequirements { fieldPoseSetup.confirm() }.named("Confirm measured field pose"))
    }

    private fun readyToFeed(): Boolean =
        DriverStationState.isTeleopEnabled() && odometrySupplier.readyForShooting &&
            ShotTable.getShot(odometrySupplier.getDistanceToHub()) != null && shooter.atSpeed && hood.atPosition

    fun stopAll() {
        swerve.stop()
        intake.stop()
        pivot.disable()
        shooter.disable()
        hood.disable()
        transport.disable()
    }

    val autonomousCommand: Command
        get() = autoManager.createSelected()
}
