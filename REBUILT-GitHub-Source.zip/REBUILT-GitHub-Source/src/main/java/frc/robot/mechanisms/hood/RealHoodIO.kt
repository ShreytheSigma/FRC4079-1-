package frc.robot.mechanisms.hood

import com.ctre.phoenix6.BaseStatusSignal
import com.ctre.phoenix6.CANBus
import com.ctre.phoenix6.StatusCode
import com.ctre.phoenix6.StatusSignal
import com.ctre.phoenix6.configs.Slot0Configs
import com.ctre.phoenix6.configs.TalonFXConfiguration
import com.ctre.phoenix6.controls.DutyCycleOut
import com.ctre.phoenix6.controls.PositionVoltage
import com.ctre.phoenix6.hardware.TalonFX
import com.ctre.phoenix6.signals.InvertedValue
import com.ctre.phoenix6.signals.NeutralModeValue
import frc.robot.utils.RobotParameters.HoodParameters
import frc.robot.utils.phoenix.PhoenixConfiguration
import org.littletonrobotics.junction.Logger
import org.wpilib.driverstation.RobotState
import org.wpilib.util.Alert
import org.wpilib.math.util.Units
import org.wpilib.units.measure.Angle
import org.wpilib.units.measure.AngularVelocity
import org.wpilib.units.measure.Current
import org.wpilib.units.measure.Voltage

class RealHoodIO : HoodIO {
    private val hoodTalon = TalonFX(HoodParameters.hoodMotor, CANBus(HoodParameters.HOOD_CANPORT))
    private val hoodConfig = TalonFXConfiguration()
    private val calibration = HoodCalibration()
    private val safety = HoodPositionSafety(calibration) { hoodTalon.stopMotor() }
    private var configured = false
    private var connected = false
    private val homingAlert = Alert("Hood", "NotHomed", "Hood needs measured limits and disabled homing before position control.", Alert.Level.HIGH)
    private val controlAlert = Alert("Hood", "ControlFailed", "Hood control request failed; output stopped.", Alert.Level.HIGH)
    private val hoodPositionRequest: PositionVoltage = PositionVoltage(0.0).withSlot(0)
    private val hoodPosition: StatusSignal<Angle>
    private val hoodVelocity: StatusSignal<AngularVelocity>
    private val hoodVoltage: StatusSignal<Voltage>
    private val hoodSupplyCurrent: StatusSignal<Current>
    private val hoodTorqueCurrent: StatusSignal<Current>

    init {
        hoodConfig.MotorOutput.NeutralMode = NeutralModeValue.Brake
        hoodConfig.MotorOutput.Inverted = InvertedValue.Clockwise_Positive

        hoodConfig.Slot0 =
            Slot0Configs()
                .withKP(HoodParameters.PIDParameters.HOOD_PID.p)
                .withKI(HoodParameters.PIDParameters.HOOD_PID.i)
                .withKD(HoodParameters.PIDParameters.HOOD_PID.d)
        hoodConfig.Feedback.SensorToMechanismRatio = HoodParameters.HOOD_GEAR_RATIO

        hoodConfig.TorqueCurrent.PeakForwardTorqueCurrent = HoodParameters.PhysicalParameters.HOOD_CURRENT_LIMIT
        hoodConfig.TorqueCurrent.PeakReverseTorqueCurrent = -HoodParameters.PhysicalParameters.HOOD_CURRENT_LIMIT
        hoodConfig.CurrentLimits.StatorCurrentLimit = HoodParameters.PhysicalParameters.HOOD_CURRENT_LIMIT
        hoodConfig.CurrentLimits.StatorCurrentLimitEnable = true

        hoodConfig.ClosedLoopRamps.VoltageClosedLoopRampPeriod = 0.02

        if (calibration.valid) {
            hoodConfig.SoftwareLimitSwitch.ForwardSoftLimitEnable = true
            hoodConfig.SoftwareLimitSwitch.ReverseSoftLimitEnable = true
            hoodConfig.SoftwareLimitSwitch.ForwardSoftLimitThreshold = Units.radiansToRotations(HoodParameters.MAX_ANGLE_RAD)
            hoodConfig.SoftwareLimitSwitch.ReverseSoftLimitThreshold = Units.radiansToRotations(HoodParameters.MIN_ANGLE_RAD)
        }
        configured = PhoenixConfiguration.apply("Hood CAN ${HoodParameters.hoodMotor}") {
            hoodTalon.configurator.apply(hoodConfig, 0.25)
        }

        hoodPosition = hoodTalon.position
        hoodVelocity = hoodTalon.velocity
        hoodVoltage = hoodTalon.motorVoltage
        hoodSupplyCurrent = hoodTalon.supplyCurrent
        hoodTorqueCurrent = hoodTalon.torqueCurrent

        BaseStatusSignal.setUpdateFrequencyForAll(
            50.0,
            hoodPosition,
            hoodVelocity,
            hoodVoltage,
            hoodSupplyCurrent,
            hoodTorqueCurrent,
        )
    }

    override fun updateInputs(inputs: HoodIO.HoodIOInputs) {
        BaseStatusSignal.refreshAll(hoodPosition, hoodVelocity, hoodVoltage, hoodSupplyCurrent, hoodTorqueCurrent)
        if (hoodTalon.hasResetOccurred()) safety.invalidateHome()
        inputs.data.hoodConnected =
            configured && BaseStatusSignal.isAllGood(
                hoodPosition,
                hoodVelocity,
                hoodVoltage,
                hoodSupplyCurrent,
                hoodTorqueCurrent,
            ) && hoodPosition.valueAsDouble.isFinite() && hoodVelocity.valueAsDouble.isFinite()
        inputs.data.hoodPositionRad = Units.rotationsToRadians(hoodPosition.valueAsDouble)
        inputs.data.hoodVelocityRadPerSec = Units.rotationsToRadians(hoodVelocity.valueAsDouble)
        inputs.data.hoodAppliedVolts = hoodVoltage.valueAsDouble
        inputs.data.hoodSupplyCurrentAmps = hoodSupplyCurrent.valueAsDouble
        inputs.data.hoodTorqueCurrentAmps = hoodTorqueCurrent.valueAsDouble
        connected = inputs.data.hoodConnected
        if (!connected) safety.invalidateHome()
        inputs.data.positionControlReady = connected && safety.positionControlReady
        homingAlert.set(!safety.homed || !calibration.valid)
    }

    override fun setPower(power: Double) {
        safety.requestPower(power, connected && configured) {
            checkControl(hoodTalon.setControl(DutyCycleOut(it)))
        }
    }

    override fun setHoodState(state: HoodIO.HoodPositionState) {
        setPosition(state.positionRad)
    }

    override fun setPosition(positionRad: Double) {
        safety.requestPosition(positionRad, connected && configured) {
            checkControl(hoodTalon.setControl(hoodPositionRequest.withPosition(Units.radiansToRotations(it))))
        }
    }

    override fun isPositionRequestAccepted(positionRad: Double): Boolean =
        connected && configured && safety.isPositionRequestAccepted(positionRad)

    private fun checkControl(status: StatusCode): Boolean {
        Logger.recordOutput("Hood/ControlStatus", status.toString())
        controlAlert.set(!status.isOK)
        return status.isOK
    }

    override fun zeroAtHome(): Boolean {
        return safety.home(RobotState.isDisabled(), connected && configured) {
            hoodTalon.hasResetOccurred()
            PhoenixConfiguration.apply("Hood home") {
                hoodTalon.setPosition(Units.radiansToRotations(calibration.homeAngleRad), 0.25)
            }
        }
    }

    override fun disablePower() {
        safety.stop()
    }

    override fun setCurrentLimit(currentLimit: Int) {
        if (currentLimit <= 0) { disablePower(); return }
        hoodConfig.CurrentLimits.StatorCurrentLimit = currentLimit.toDouble()
        for (i in 0..4) {
            if (hoodTalon.configurator.apply(hoodConfig.CurrentLimits, 0.25).isOK) break
        }
    }
}
