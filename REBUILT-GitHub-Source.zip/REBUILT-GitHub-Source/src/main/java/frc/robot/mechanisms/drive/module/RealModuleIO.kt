package frc.robot.mechanisms.drive.module

import com.ctre.phoenix6.BaseStatusSignal
import com.ctre.phoenix6.CANBus
import com.ctre.phoenix6.StatusSignal
import com.ctre.phoenix6.configs.CANcoderConfiguration
import com.ctre.phoenix6.configs.Slot0Configs
import com.ctre.phoenix6.configs.TalonFXConfiguration
import com.ctre.phoenix6.controls.PositionTorqueCurrentFOC
import com.ctre.phoenix6.controls.VelocityTorqueCurrentFOC
import com.ctre.phoenix6.hardware.CANcoder
import com.ctre.phoenix6.hardware.ParentDevice
import com.ctre.phoenix6.hardware.TalonFX
import com.ctre.phoenix6.signals.FeedbackSensorSourceValue
import com.ctre.phoenix6.signals.InvertedValue
import com.ctre.phoenix6.signals.NeutralModeValue
import com.ctre.phoenix6.signals.SensorDirectionValue
import frc.robot.utils.RobotParameters.SwerveParameters
import frc.robot.utils.phoenix.PhoenixConfiguration
import frc.robot.utils.swerve.DriveCoupling
import org.littletonrobotics.junction.Logger
import org.wpilib.util.Alert
import org.wpilib.math.geometry.Rotation2d
import org.wpilib.math.util.Units
import org.wpilib.units.measure.Angle
import org.wpilib.units.measure.AngularVelocity
import org.wpilib.units.measure.Current
import org.wpilib.units.measure.Voltage
import java.util.concurrent.Executors

class RealModuleIO(
    config: SwerveParameters.ModuleConfig,
) : ModuleIO {
    private val brakeModeExecutor = Executors.newSingleThreadExecutor { task -> Thread(task, "SwerveBrake-${config.driveMotorId}").apply { isDaemon = true } }
    private val driveTalon = TalonFX(config.driveMotorId, CANBus(config.canBUS))
    private val turnTalon = TalonFX(config.turnMotorId, CANBus(config.canBUS))
    private val encoder = CANcoder(config.encoderID, CANBus(config.canBUS))
    private val driveConfig = TalonFXConfiguration()
    private val turnConfig = TalonFXConfiguration()
    private val coupling = DriveCoupling(
        SwerveParameters.PhysicalParameters.COUPLE_RATIO,
        SwerveParameters.PhysicalParameters.DRIVE_MOTOR_GEAR_RATIO,
    )
    private val logName = "Swerve/Hardware/${config.driveMotorId}"
    private var configured = true
    private val resetAlert = Alert("Swerve", "Reset${config.driveMotorId}", "Swerve device reset or rejected control. Disable, inspect logs, then restart robot code.", Alert.Level.HIGH)
    private val proAlert = Alert("Swerve", "Pro${config.driveMotorId}", "Swerve module ${config.driveMotorId}: torque control requires Phoenix Pro on BOTH motors.", Alert.Level.HIGH)
    private val fusionAlert = Alert("Swerve", "Fusion${config.driveMotorId}", "Swerve module ${config.driveMotorId}: fused encoder out of sync. Check ratio and sensor direction.", Alert.Level.HIGH)
    private val drivePro = driveTalon.isProLicensed
    private val turnPro = turnTalon.isProLicensed
    private val fusionFault = turnTalon.fault_FusedSensorOutOfSync

    // Pro-licensed closed-loop requests (FOC torque current)
    private val positionTorqueRequest = PositionTorqueCurrentFOC(0.0).withSlot(0)
    private val velocityTorqueRequest = VelocityTorqueCurrentFOC(0.0).withSlot(0)

    private val drivePosition: StatusSignal<Angle>
    private val driveVelocity: StatusSignal<AngularVelocity>
    private val driveAppliedVolts: StatusSignal<Voltage>
    private val driveSupplyCurrentAmps: StatusSignal<Current>
    private val driveTorqueCurrentAmps: StatusSignal<Current>

    private val turnAbsolutePosition: StatusSignal<Angle>
    private val turnPosition: StatusSignal<Angle>
    private val turnVelocity: StatusSignal<AngularVelocity>
    private val turnAppliedVolts: StatusSignal<Voltage>
    private val turnSupplyCurrentAmps: StatusSignal<Current>
    private val turnTorqueCurrentAmps: StatusSignal<Current>

    init {
        // Configure drive motor
        driveConfig.MotorOutput.NeutralMode = NeutralModeValue.Brake
        driveConfig.MotorOutput.Inverted =
            if (config.driveInverted) {
                InvertedValue.Clockwise_Positive
            } else {
                InvertedValue.CounterClockwise_Positive
            }
        driveConfig.Slot0 =
            Slot0Configs()
                .withKP(SwerveParameters.PIDParameters.DRIVE_PID_TELE.p)
                .withKI(SwerveParameters.PIDParameters.DRIVE_PID_TELE.i)
                .withKD(SwerveParameters.PIDParameters.DRIVE_PID_TELE.d)

        driveConfig.Feedback.SensorToMechanismRatio = SwerveParameters.PhysicalParameters.DRIVE_MOTOR_GEAR_RATIO
        driveConfig.TorqueCurrent.PeakForwardTorqueCurrent = SwerveParameters.PhysicalParameters.DRIVE_CURRENT_LIMIT
        driveConfig.TorqueCurrent.PeakReverseTorqueCurrent = -SwerveParameters.PhysicalParameters.DRIVE_CURRENT_LIMIT
        driveConfig.CurrentLimits.StatorCurrentLimit = SwerveParameters.PhysicalParameters.DRIVE_CURRENT_LIMIT
        driveConfig.CurrentLimits.StatorCurrentLimitEnable = true
        driveConfig.ClosedLoopRamps.TorqueClosedLoopRampPeriod = 0.02

        configured = PhoenixConfiguration.apply("${logName}/Drive") { driveTalon.configurator.apply(driveConfig, 0.25) } && configured
        for (i in 0..4) {
            if (driveTalon.setPosition(0.0, 0.25).isOK) break
        }

        // Configure turn motor
        turnConfig.MotorOutput.NeutralMode = NeutralModeValue.Brake
        turnConfig.Slot0 =
            Slot0Configs()
                .withKP(SwerveParameters.PIDParameters.STEER_PID_TELE.p)
                .withKI(SwerveParameters.PIDParameters.STEER_PID_TELE.i)
                .withKD(SwerveParameters.PIDParameters.STEER_PID_TELE.d)

        // FusedCANcoder (Pro): rotor position fused with CANcoder for the full 1:1
        // azimuth range instead of absolute-position syncing
        turnConfig.Feedback.FeedbackRemoteSensorID = config.encoderID
        turnConfig.Feedback.FeedbackSensorSource = FeedbackSensorSourceValue.FusedCANcoder
        turnConfig.Feedback.RotorToSensorRatio = SwerveParameters.PhysicalParameters.STEER_MOTOR_GEAR_RATIO
        turnConfig.ClosedLoopGeneral.ContinuousWrap = true
        turnConfig.TorqueCurrent.PeakForwardTorqueCurrent = SwerveParameters.PhysicalParameters.STEER_CURRENT_LIMIT
        turnConfig.TorqueCurrent.PeakReverseTorqueCurrent = -SwerveParameters.PhysicalParameters.STEER_CURRENT_LIMIT
        turnConfig.CurrentLimits.StatorCurrentLimit = SwerveParameters.PhysicalParameters.STEER_CURRENT_LIMIT
        turnConfig.CurrentLimits.StatorCurrentLimitEnable = true
        turnConfig.MotorOutput.Inverted =
            if (config.turnInverted) {
                InvertedValue.Clockwise_Positive
            } else {
                InvertedValue.CounterClockwise_Positive
            }

        // Configure CANCoder
        val cancoderConfig = CANcoderConfiguration()
        cancoderConfig.MagnetSensor.MagnetOffset = config.encoderOffset.rotations
        cancoderConfig.MagnetSensor.SensorDirection =
            if (config.encoderInverted) {
                SensorDirectionValue.Clockwise_Positive
            } else {
                SensorDirectionValue.CounterClockwise_Positive
            }

        configured = PhoenixConfiguration.apply("${logName}/CANcoder") { encoder.configurator.apply(cancoderConfig, 0.25) } && configured
        // Fused feedback establishes its own reference. Configure the absolute sensor first.
        configured = PhoenixConfiguration.apply("${logName}/Steer") { turnTalon.configurator.apply(turnConfig, 0.25) } && configured

        // Create drive status signals
        drivePosition = driveTalon.position
        driveVelocity = driveTalon.velocity
        driveAppliedVolts = driveTalon.motorVoltage
        driveSupplyCurrentAmps = driveTalon.supplyCurrent
        driveTorqueCurrentAmps = driveTalon.torqueCurrent

        // Create turn status signals
        turnAbsolutePosition = encoder.absolutePosition
        turnPosition = turnTalon.position
        turnVelocity = turnTalon.velocity
        turnAppliedVolts = turnTalon.motorVoltage
        turnSupplyCurrentAmps = turnTalon.supplyCurrent
        turnTorqueCurrentAmps = turnTalon.torqueCurrent

        BaseStatusSignal.setUpdateFrequencyForAll(
            50.0,
            drivePosition,
            driveVelocity,
            driveAppliedVolts,
            driveSupplyCurrentAmps,
            driveTorqueCurrentAmps,
            turnAbsolutePosition,
            turnPosition,
            turnVelocity,
            turnAppliedVolts,
            turnSupplyCurrentAmps,
            turnTorqueCurrentAmps,
            drivePro, turnPro, fusionFault,
        )

        ParentDevice.optimizeBusUtilizationForAll(driveTalon, turnTalon, encoder)
        // Clear the power-up flags; a later reset invalidates the running sensor reference.
        driveTalon.hasResetOccurred()
        turnTalon.hasResetOccurred()
        encoder.hasResetOccurred()
    }

    override fun updateInputs(inputs: ModuleIO.ModuleIOInputs) {
        val driveReset = driveTalon.hasResetOccurred()
        val turnReset = turnTalon.hasResetOccurred()
        val encoderReset = encoder.hasResetOccurred()
        if (driveReset || turnReset || encoderReset) {
            configured = false
            resetAlert.set(true)
        }
        BaseStatusSignal.refreshAll(
            drivePosition,
            driveVelocity,
            driveAppliedVolts,
            driveSupplyCurrentAmps,
            driveTorqueCurrentAmps,
            turnAbsolutePosition,
            turnPosition,
            turnVelocity,
            turnAppliedVolts,
            turnSupplyCurrentAmps,
            turnTorqueCurrentAmps,
            drivePro, turnPro, fusionFault,
        )

        val licensed = BaseStatusSignal.isAllGood(drivePro, turnPro) && drivePro.value == true && turnPro.value == true
        val fusionHealthy = fusionFault.status.isOK && fusionFault.value == false
        proAlert.set(!licensed)
        fusionAlert.set(!fusionHealthy)
        Logger.recordOutput("$logName/Configured", configured)
        Logger.recordOutput("$logName/ProLicensed", licensed)

        inputs.data.driveConnected =
            configured && licensed && BaseStatusSignal.isAllGood(
                drivePosition,
                driveVelocity,
                driveAppliedVolts,
                driveSupplyCurrentAmps,
                driveTorqueCurrentAmps,
            )
        inputs.data.driveAppliedVolts = driveAppliedVolts.valueAsDouble
        inputs.data.driveSupplyCurrentAmps = driveSupplyCurrentAmps.valueAsDouble
        inputs.data.driveTorqueCurrentAmps = driveTorqueCurrentAmps.valueAsDouble

        inputs.data.turnConnected =
            configured && licensed && fusionHealthy && BaseStatusSignal.isAllGood(
                turnPosition,
                turnVelocity,
                turnAppliedVolts,
                turnSupplyCurrentAmps,
                turnTorqueCurrentAmps,
            )
        inputs.data.turnEncoderConnected = BaseStatusSignal.isAllGood(turnAbsolutePosition)
        // Offset is applied once here, via MagnetOffset in the CANcoder config.
        // Do NOT subtract config.encoderOffset again.
        inputs.data.turnAbsolutePosition = Rotation2d.fromRotations(turnAbsolutePosition.valueAsDouble)
        inputs.data.turnPosition = Rotation2d.fromRotations(turnPosition.valueAsDouble)
        inputs.data.turnVelocityRadPerSec = Units.rotationsToRadians(turnVelocity.valueAsDouble)
        inputs.data.turnAppliedVolts = turnAppliedVolts.valueAsDouble
        inputs.data.turnSupplyCurrentAmps = turnSupplyCurrentAmps.valueAsDouble
        inputs.data.turnTorqueCurrentAmps = turnTorqueCurrentAmps.valueAsDouble

        if (inputs.data.driveConnected && inputs.data.turnConnected && inputs.data.turnEncoderConnected) {
            inputs.data.drivePositionRad = coupling.wheelPosition(
                Units.rotationsToRadians(drivePosition.valueAsDouble),
                Units.rotationsToRadians(turnPosition.valueAsDouble),
            )
            inputs.data.driveVelocityRadPerSec = coupling.wheelVelocity(
                Units.rotationsToRadians(driveVelocity.valueAsDouble), inputs.data.turnVelocityRadPerSec,
            )
        }

        inputs.odometryDrivePositionsRad = doubleArrayOf(inputs.data.drivePositionRad)
        inputs.odometryTurnPositions = arrayOf(inputs.data.turnPosition)
    }

    override fun runDriveOpenLoop(output: Double) {
        driveTalon.setVoltage(output)
    }

    override fun runTurnOpenLoop(output: Double) {
        turnTalon.setVoltage(output)
    }

    override fun runDriveVelocity(
        velocityRadPerSec: Double,
        feedforward: Double,
    ) {
        if (!configured) { driveTalon.stopMotor(); return }
        val status = driveTalon.setControl(
            velocityTorqueRequest
                .withVelocity(Units.radiansToRotations(coupling.driveVelocity(
                    velocityRadPerSec, Units.rotationsToRadians(turnVelocity.valueAsDouble),
                )))
                // Torque-current feedforward is amperes, not voltage.
                .withFeedForward(feedforward),
        )
        Logger.recordOutput("$logName/DriveControlStatus", status.toString())
        if (!status.isOK) {
            configured = false
            resetAlert.set(true)
            driveTalon.stopMotor()
            turnTalon.stopMotor()
        }
    }

    override fun runTurnPosition(rotation: Rotation2d) {
        if (!configured) { turnTalon.stopMotor(); return }
        val status = turnTalon.setControl(positionTorqueRequest.withPosition(rotation.rotations))
        Logger.recordOutput("$logName/SteerControlStatus", status.toString())
        if (!status.isOK) {
            configured = false
            resetAlert.set(true)
            driveTalon.stopMotor()
            turnTalon.stopMotor()
        }
    }

    override fun setDrivePID(
        kP: Double,
        kI: Double,
        kD: Double,
    ) {
        driveConfig.Slot0.kP = kP
        driveConfig.Slot0.kI = kI
        driveConfig.Slot0.kD = kD
        for (i in 0..4) {
            if (driveTalon.configurator.apply(driveConfig.Slot0, 0.25).isOK) break
        }
    }

    override fun setTurnPID(
        kP: Double,
        kI: Double,
        kD: Double,
    ) {
        turnConfig.Slot0.kP = kP
        turnConfig.Slot0.kI = kI
        turnConfig.Slot0.kD = kD
        for (i in 0..4) {
            if (turnTalon.configurator.apply(turnConfig.Slot0, 0.25).isOK) break
        }
    }

    override fun setBrakeMode(enabled: Boolean) {
        brakeModeExecutor.execute {
            synchronized(driveConfig) {
                driveConfig.MotorOutput.NeutralMode = if (enabled) NeutralModeValue.Brake else NeutralModeValue.Coast
                for (i in 0..4) {
                    if (driveTalon.configurator.apply(driveConfig.MotorOutput, 0.25).isOK) break
                }
            }
        }
        brakeModeExecutor.execute {
            synchronized(turnConfig) {
                turnConfig.MotorOutput.NeutralMode = if (enabled) NeutralModeValue.Brake else NeutralModeValue.Coast
                for (i in 0..4) {
                    if (turnTalon.configurator.apply(turnConfig.MotorOutput, 0.25).isOK) break
                }
            }
        }
    }
}
