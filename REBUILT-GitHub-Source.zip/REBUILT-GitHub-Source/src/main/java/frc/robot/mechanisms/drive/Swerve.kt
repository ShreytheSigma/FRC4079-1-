package frc.robot.mechanisms.drive

import frc.robot.RobotState
import frc.robot.mechanisms.drive.gyro.GyroIO
import frc.robot.mechanisms.drive.gyro.GyroIOInputsAutoLogged
import frc.robot.mechanisms.drive.module.ModuleIO
import frc.robot.mechanisms.drive.module.SwerveModule
import frc.robot.utils.RobotParameters.SwerveParameters
import org.littletonrobotics.junction.Logger
import org.wpilib.command3.Command
import org.wpilib.command3.Mechanism
import org.wpilib.math.geometry.Rotation2d
import org.wpilib.math.kinematics.ChassisVelocities
import org.wpilib.math.kinematics.SwerveModulePosition
import org.wpilib.math.kinematics.SwerveModuleVelocity
import org.wpilib.math.kinematics.SwerveDriveKinematics
import org.wpilib.system.Timer
import java.util.Optional

class Swerve(
    private val moduleIOs: Array<ModuleIO>,
    private val gyroIO: GyroIO,
) : Mechanism {
    private val gyroInputs = GyroIOInputsAutoLogged()
    private val modules: Array<SwerveModule> = initializeModules()

    private var previousFieldRelVelocities = ChassisVelocities()
    private var setStates = Array(modules.size) { SwerveModuleVelocity() }

    private var driverHeadingOffset = Rotation2d.ZERO
    private var heading = Rotation2d.ZERO
    private var gyroOffset = Rotation2d.ZERO
    private var hadGyro = false
    private var hasUpdated = false
    private var hadModuleFeedback = false
    private var lastPositions = Array(modules.size) { SwerveModulePosition() }

    private fun initializeModules(): Array<SwerveModule> =
        Array(SwerveParameters.MODULE_CONFIGS.size) { index ->
            SwerveModule(
                moduleIOs[index],
                index,
            )
        }

    fun periodic() {
        gyroIO.updateInputs(gyroInputs)
        Logger.processInputs("Swerve/Gyro", gyroInputs)
        for (module in modules) {
            module.updateInputs()
        }

        for (module in modules) {
            module.periodic()
        }

        val positions = modulePositions
        val modulesHealthy = modules.all { it.connected }
        val gyroHealthy = gyroInputs.data.connected && gyroInputs.data.yawPosition.radians.isFinite()
        if (gyroHealthy) {
            if (hasUpdated && !hadGyro) gyroOffset = heading.minus(gyroInputs.data.yawPosition)
            heading = gyroInputs.data.yawPosition.plus(gyroOffset)
        } else if (hasUpdated && modulesHealthy && hadModuleFeedback) {
            val twist = SwerveParameters.PhysicalParameters.kinematics.toTwist2d(lastPositions, positions)
            heading = heading.plus(Rotation2d.fromRadians(twist.dtheta))
        }
        hadGyro = gyroHealthy
        hasUpdated = true
        hadModuleFeedback = modulesHealthy
        if (modulesHealthy) lastPositions = positions else stop()

        RobotState.getInstance().addDriveSpeeds(autoSpeeds)
        Logger.recordOutput("Swerve/States/Measured", SwerveModuleVelocity.struct, *moduleStates)
        Logger.recordOutput("Swerve/States/Setpoints", SwerveModuleVelocity.struct, *setStates)

        previousFieldRelVelocities = fieldRelativeVelocity
    }

    fun setDriveSpeeds(
        forwardSpeed: Double,
        leftSpeed: Double,
        turnSpeed: Double,
        isFieldOriented: Boolean = SwerveParameters.Thresholds.IS_FIELD_ORIENTED,
    ) {
        val speeds =
            if (isFieldOriented) {
                ChassisVelocities(forwardSpeed, leftSpeed, turnSpeed).toRobotRelative(gyroYaw.minus(driverHeadingOffset))
            } else {
                ChassisVelocities(forwardSpeed, leftSpeed, turnSpeed)
            }.discretize(LOOP_PERIOD_SECS)

        runVelocity(speeds)
    }

    fun runVelocity(speeds: ChassisVelocities) {
        if (!speeds.vx.isFinite() || !speeds.vy.isFinite() || !speeds.omega.isFinite()) {
            stop()
            return
        }
        moduleStates = SwerveParameters.PhysicalParameters.kinematics.toSwerveModuleVelocities(speeds)
    }

    val fieldRelativeVelocity: ChassisVelocities
        get() = autoSpeeds.toFieldRelative(gyroYaw)

    val gyroYaw: Rotation2d
        get() = heading

    val readyForAuto: Boolean
        get() = hasUpdated && modules.all { it.connected } && heading.radians.isFinite()

    val autoSpeeds: ChassisVelocities
        get() = SwerveParameters.PhysicalParameters.kinematics.toChassisVelocities(*moduleStates)

    fun chassisSpeedsDrive(chassisSpeeds: ChassisVelocities?) {
        if (chassisSpeeds == null) return
        runVelocity(chassisSpeeds)
    }

    var moduleStates: Array<SwerveModuleVelocity>
        get() = Array(modules.size) { index -> modules[index].state }
        set(states) {
            require(states.size == modules.size) { "One state per swerve module is required" }
            if (modules.any { !it.connected }) { stop(); return }
            if (states.any { !it.velocity.isFinite() || !it.angle.radians.isFinite() }) {
                stop()
                return
            }
            setStates = SwerveDriveKinematics.desaturateWheelVelocities(
                states, SwerveParameters.PhysicalParameters.MAX_SPEED,
            )
            for (i in modules.indices) {
                modules[i].state = setStates[i]
            }
        }

    val modulePositions: Array<SwerveModulePosition>
        get() = Array(modules.size) { index -> modules[index].position }

    fun addOdometryObservation() {
        RobotState.getInstance().addOdometryObservation(
            RobotState.OdometryObservation(
                timestamp = Timer.getTimestamp(),
                wheelPositions = modulePositions,
                yaw = Optional.of(gyroYaw),
            ),
        )
    }

    fun stop() {
        setStates = Array(modules.size) { SwerveModuleVelocity(0.0, modules[it].angle ?: Rotation2d.ZERO) }
        for (module in modules) {
            module.stop()
        }
    }

    fun setAutoPID() {
        for (module in modules) {
            module.setAutoPID()
        }
    }

    fun setTelePID() {
        for (module in modules) {
            module.setTelePID()
            module.applyTelePIDValues()
        }
    }

    fun resetDrive() {
        for (module in modules) {
            module.resetDrivePosition()
        }
    }

    fun updateModuleTelePIDValues() {
        for (module in modules) {
            module.updateTelePID()
        }
    }

    fun setBrakeMode(enabled: Boolean) {
        for (module in modules) {
            module.setBrakeMode(enabled)
        }
    }

    fun resetGyro() {
        // Driver zero must not rotate the field pose used by odometry and aiming.
        driverHeadingOffset = gyroYaw
    }

    fun pathFindToGoal(): Command? = null

    fun pathFindTest(): Command? = null

    private val LOOP_PERIOD_SECS = 0.02
}
