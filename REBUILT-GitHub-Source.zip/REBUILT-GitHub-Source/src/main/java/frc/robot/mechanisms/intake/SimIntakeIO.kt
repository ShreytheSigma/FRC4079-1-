package frc.robot.mechanisms.intake

import frc.robot.utils.RobotParameters.IntakeParameters
import org.wpilib.math.controller.PIDController
import org.wpilib.math.system.DCMotor
import org.wpilib.math.system.Models
import org.wpilib.simulation.DCMotorSim
import java.lang.Math.clamp
import kotlin.math.abs

class SimIntakeIO : IntakeIO {
    companion object {
        private val intakeMotorModel: DCMotor = DCMotor.getKrakenX60Foc(1)
    }

    private val intakeMotorSim =
        DCMotorSim(
            Models.singleJointedArmFromPhysicalConstants(
                intakeMotorModel,
                IntakeParameters.PhysicalParameters.SIM_INERTIA_KG_METERS_SQUARED,
                IntakeParameters.PhysicalParameters.INTAKE_GEAR_RATIO,
            ),
            intakeMotorModel,
        )

    private var intakeClosedLoop = false
    private var intakeVelocityControl = false
    private var intakeController = PIDController(IntakeParameters.PIDParameters.INTAKE_PID.p / (2.0 * Math.PI), 0.0, 0.0)
    private var intakeAppliedVolts = 0.0

    override fun updateInputs(inputs: IntakeIO.IntakeIOInputs) {
        if (!intakeClosedLoop) {
            intakeController.reset()
        }

        if (intakeClosedLoop) {
            intakeAppliedVolts = intakeController.calculate(
                if (intakeVelocityControl) intakeMotorSim.angularVelocity else intakeMotorSim.angularPosition,
            )
        }

        intakeAppliedVolts = clamp(intakeAppliedVolts, -12.0, 12.0)
        intakeMotorSim.setInputVoltage(intakeAppliedVolts)
        intakeMotorSim.update(0.02)

        inputs.data.intakeConnected = true
        inputs.data.intakePositionRad = intakeMotorSim.angularPosition
        inputs.data.intakeVelocityRadPerSec = intakeMotorSim.angularVelocity
        inputs.data.intakeAppliedVolts = intakeAppliedVolts
        inputs.data.intakeSupplyCurrentAmps = abs(intakeMotorSim.currentDraw)
        inputs.data.intakeTorqueCurrentAmps = 0.0
        inputs.data.leftConnected = true
        inputs.data.rightConnected = true
        inputs.data.rightPositionRad = inputs.data.intakePositionRad
        inputs.data.rightVelocityRadPerSec = inputs.data.intakeVelocityRadPerSec
        inputs.data.rightAppliedVolts = intakeAppliedVolts
        inputs.data.rightSupplyCurrentAmps = inputs.data.intakeSupplyCurrentAmps
    }

    override fun setVoltage(volts: Double) {
        intakeClosedLoop = false
        intakeAppliedVolts = volts
    }

    override fun setPosition(positionRad: Double) {
        intakeClosedLoop = true
        intakeVelocityControl = false
        intakeController.setSetpoint(positionRad)
    }

    override fun setVelocity(velocityRadPerSec: Double) {
        intakeClosedLoop = true
        intakeVelocityControl = true
        intakeController.setSetpoint(velocityRadPerSec)
    }

    override fun setIntakePID(
        kP: Double,
        kI: Double,
        kD: Double,
    ) {
        intakeController.setPID(kP / (2.0 * Math.PI), kI / (2.0 * Math.PI), kD / (2.0 * Math.PI))
    }

    override fun stop() {
        setVoltage(0.0)
    }
}
