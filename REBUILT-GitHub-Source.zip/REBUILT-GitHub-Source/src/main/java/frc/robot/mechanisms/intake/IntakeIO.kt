package frc.robot.mechanisms.intake

import frc.robot.utils.logging.ReflectiveLoggableInputs
import org.littletonrobotics.junction.AutoLog

interface IntakeIO {
    @AutoLog
    open class IntakeIOInputs {
        @JvmField
        var data: IntakeIOData =
            IntakeIOData(
                intakeConnected = false,
                intakePositionRad = 0.0,
                intakeVelocityRadPerSec = 0.0,
                intakeAppliedVolts = 0.0,
                intakeSupplyCurrentAmps = 0.0,
                intakeTorqueCurrentAmps = 0.0,
            )
    }

    data class IntakeIOData(
        var intakeConnected: Boolean,
        var intakePositionRad: Double,
        var intakeVelocityRadPerSec: Double,
        var intakeAppliedVolts: Double,
        var intakeSupplyCurrentAmps: Double,
        var intakeTorqueCurrentAmps: Double,
        var leftConnected: Boolean = false,
        var rightConnected: Boolean = false,
        var rightPositionRad: Double = 0.0,
        var rightVelocityRadPerSec: Double = 0.0,
        var rightAppliedVolts: Double = 0.0,
        var rightSupplyCurrentAmps: Double = 0.0,
        var rightTorqueCurrentAmps: Double = 0.0,
    ) : ReflectiveLoggableInputs()

    fun updateInputs(inputs: IntakeIOInputs) {}

    fun setVoltage(volts: Double) {}

    fun setPosition(positionRad: Double) {}

    fun setVelocity(velocityRadPerSec: Double) {}

    fun setIntakePID(
        kP: Double,
        kI: Double,
        kD: Double,
    ) {}

    fun stop() {}
}
