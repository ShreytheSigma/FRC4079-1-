package frc.robot.mechanisms.hood

import frc.robot.utils.RobotParameters.HoodParameters

data class HoodCalibration(
    val homeAngleRad: Double = HoodParameters.HOME_ANGLE_RAD,
    val minAngleRad: Double = HoodParameters.MIN_ANGLE_RAD,
    val maxAngleRad: Double = HoodParameters.MAX_ANGLE_RAD,
    val gearRatio: Double = HoodParameters.HOOD_GEAR_RATIO,
) {
    val valid: Boolean
        get() = homeAngleRad.isFinite() && minAngleRad.isFinite() && maxAngleRad.isFinite() &&
            gearRatio.isFinite() && gearRatio > 0.0 && minAngleRad < maxAngleRad &&
            homeAngleRad in minAngleRad..maxAngleRad

    fun contains(positionRad: Double): Boolean =
        valid && positionRad.isFinite() && positionRad in minAngleRad..maxAngleRad
}

/** Shared by hardware and simulation so request rejection always removes output and readiness. */
internal class HoodPositionSafety(
    private val calibration: HoodCalibration,
    private val stopOutput: () -> Unit,
) {
    var homed: Boolean = false
        private set
    private var acceptedTargetRad: Double? = null

    val positionControlReady: Boolean
        get() = homed && calibration.valid && acceptedTargetRad != null

    fun isPositionRequestAccepted(positionRad: Double): Boolean =
        positionControlReady && positionRad.isFinite() && acceptedTargetRad == positionRad

    fun stop() {
        acceptedTargetRad = null
        stopOutput()
    }

    fun invalidateHome() {
        homed = false
        stop()
    }

    fun home(disabled: Boolean, available: Boolean, setReference: () -> Boolean): Boolean {
        invalidateHome()
        if (!disabled || !available || !calibration.valid) return false
        homed = setReference()
        return homed
    }

    fun requestPosition(positionRad: Double, available: Boolean, apply: (Double) -> Boolean) {
        acceptedTargetRad = null
        if (!available || !homed || !calibration.contains(positionRad) || !apply(positionRad)) {
            stop()
            return
        }
        acceptedTargetRad = positionRad
    }

    fun requestPower(power: Double, available: Boolean, apply: (Double) -> Boolean) {
        acceptedTargetRad = null
        if (!available || !homed || !calibration.valid || !power.isFinite() ||
            !apply(power.coerceIn(-1.0, 1.0))
        ) stop()
    }
}
