package frc.robot.mechanisms.pivot

import frc.robot.utils.RobotParameters
import org.wpilib.math.controller.PIDController
import org.wpilib.math.system.DCMotor
import org.wpilib.math.system.Models
import org.wpilib.simulation.DCMotorSim
import java.lang.Math.clamp
import kotlin.math.abs

class SimPivotIO : PivotIO {
    private val pivotMotorModel: DCMotor = DCMotor.getKrakenX60Foc(1)

    private val pivotSim =
        DCMotorSim(
            Models.singleJointedArmFromPhysicalConstants(
                pivotMotorModel,
                0.25,
                RobotParameters.PivotParameters.PIVOT_GEAR_RATIO,
            ),
            pivotMotorModel,
        )

    private var pivotClosedLoop = false
    private val pivotController = PIDController(RobotParameters.PivotParameters.PIDParameters.PIVOT_PID.p / (2.0 * Math.PI), 0.0, 0.0)
    private var pivotFFVolts = 0.0
    private var pivotAppliedVolts = 0.0

    override fun updateInputs(inputs: PivotIO.PivotIOInputs) {
        if (pivotClosedLoop) {
            pivotAppliedVolts =
                pivotFFVolts + pivotController.calculate(pivotSim.angularPosition)
        } else {
            pivotController.reset()
        }

        // Update simulation state
        pivotAppliedVolts = clamp(pivotAppliedVolts, -12.0, 12.0)
        pivotSim.setInputVoltage(pivotAppliedVolts)
        pivotSim.update(0.02)

        inputs.data.pivotConnected = true
        inputs.data.pivotPositionRad = pivotSim.angularPosition
        inputs.data.pivotAppliedVolts = pivotAppliedVolts
        inputs.data.pivotSupplyCurrentAmps = abs(pivotSim.currentDraw)
        inputs.data.pivotTorqueCurrentAmps = 0.0
        inputs.data.pivotVelocityRadPerSec = pivotSim.angularVelocity

    }

    /** Targets arm radians; the motor-to-arm reduction is part of the physics model. */
    override fun setPivotPosition(state: PivotIO.PivotState) {
        if (!state.positionRad.isFinite()) { disablePower(); return }
        pivotClosedLoop = true
        pivotController.setSetpoint(state.positionRad)
    }

    override fun disablePower() {
        pivotClosedLoop = false
        pivotAppliedVolts = 0.0
        pivotSim.setInputVoltage(0.0)
    }
}
