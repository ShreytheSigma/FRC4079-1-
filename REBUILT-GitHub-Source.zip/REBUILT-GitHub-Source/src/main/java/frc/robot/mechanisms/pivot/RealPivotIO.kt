package frc.robot.mechanisms.pivot

import com.ctre.phoenix6.BaseStatusSignal
import com.ctre.phoenix6.CANBus
import com.ctre.phoenix6.configs.TalonFXConfiguration
import com.ctre.phoenix6.controls.PositionVoltage
import com.ctre.phoenix6.hardware.TalonFX
import com.ctre.phoenix6.signals.InvertedValue
import com.ctre.phoenix6.signals.NeutralModeValue
import frc.robot.utils.RobotParameters.PivotParameters
import frc.robot.utils.phoenix.PhoenixConfiguration
import org.littletonrobotics.junction.Logger
import org.wpilib.driverstation.RobotState
import org.wpilib.math.util.Units
import org.wpilib.util.Alert

class RealPivotIO : PivotIO {
    private val motor = TalonFX(PivotParameters.pivotMotor, CANBus(PivotParameters.PIVOT_CANPORT))
    private val config = TalonFXConfiguration()
    private val request = PositionVoltage(0.0).withSlot(0)
    private val position = motor.position
    private val velocity = motor.velocity
    private val voltage = motor.motorVoltage
    private val supplyCurrent = motor.supplyCurrent
    private val torqueCurrent = motor.torqueCurrent
    private val notHomed = Alert("Pivot", "NotHomed", "Intake pivot needs calibrated limits and disabled homing at stow.", Alert.Level.HIGH)
    private val controlAlert = Alert("Pivot", "ControlFailed", "Pivot control request failed; re-home while disabled.", Alert.Level.HIGH)
    private var homed = false
    private var connected = false
    private val configured: Boolean

    init {
        config.MotorOutput.NeutralMode = NeutralModeValue.Brake
        config.MotorOutput.Inverted = InvertedValue.Clockwise_Positive
        config.Slot0.kP = PivotParameters.PIDParameters.PIVOT_PID.p
        config.Slot0.kI = PivotParameters.PIDParameters.PIVOT_PID.i
        config.Slot0.kD = PivotParameters.PIDParameters.PIVOT_PID.d
        config.Feedback.SensorToMechanismRatio = PivotParameters.PIVOT_GEAR_RATIO
        config.CurrentLimits.StatorCurrentLimit = PivotParameters.PhysicalParameters.PIVOT_CURRENT_LIMIT
        config.CurrentLimits.StatorCurrentLimitEnable = true
        config.ClosedLoopRamps.VoltageClosedLoopRampPeriod = 0.02
        if (PivotParameters.positionCalibrated) {
            config.SoftwareLimitSwitch.ForwardSoftLimitEnable = true
            config.SoftwareLimitSwitch.ReverseSoftLimitEnable = true
            config.SoftwareLimitSwitch.ForwardSoftLimitThreshold = Units.radiansToRotations(PivotParameters.MAX_ANGLE_RAD)
            config.SoftwareLimitSwitch.ReverseSoftLimitThreshold = Units.radiansToRotations(PivotParameters.MIN_ANGLE_RAD)
        }
        configured = PhoenixConfiguration.apply("Pivot CAN ${PivotParameters.pivotMotor}") {
            motor.configurator.apply(config, 0.25)
        }
        BaseStatusSignal.setUpdateFrequencyForAll(50.0, position, velocity, voltage, supplyCurrent, torqueCurrent)
        motor.optimizeBusUtilization()
    }

    override fun updateInputs(inputs: PivotIO.PivotIOInputs) {
        BaseStatusSignal.refreshAll(position, velocity, voltage, supplyCurrent, torqueCurrent)
        if (motor.hasResetOccurred()) { homed = false; disablePower() }
        notHomed.set(!homed || !PivotParameters.positionCalibrated)
        inputs.data.pivotConnected = configured &&
            BaseStatusSignal.isAllGood(position, velocity, voltage, supplyCurrent, torqueCurrent) &&
            position.valueAsDouble.isFinite() && velocity.valueAsDouble.isFinite()
        connected = inputs.data.pivotConnected
        if (!connected) { homed = false; disablePower() }
        inputs.data.pivotPositionRad = Units.rotationsToRadians(position.valueAsDouble)
        inputs.data.pivotVelocityRadPerSec = Units.rotationsToRadians(velocity.valueAsDouble)
        inputs.data.pivotAppliedVolts = voltage.valueAsDouble
        inputs.data.pivotSupplyCurrentAmps = supplyCurrent.valueAsDouble
        inputs.data.pivotTorqueCurrentAmps = torqueCurrent.valueAsDouble
    }

    override fun zeroAtStow(): Boolean {
        homed = false
        disablePower()
        if (!RobotState.isDisabled() || !connected || !configured || !PivotParameters.positionCalibrated) return false
        motor.hasResetOccurred()
        homed = PhoenixConfiguration.apply("Pivot home at stow") {
            motor.setPosition(Units.radiansToRotations(PivotParameters.STOW_ANGLE_RAD), 0.25)
        }
        return homed
    }

    override fun setPivotPosition(state: PivotIO.PivotState) {
        if (!connected || !homed || !configured || !PivotParameters.positionCalibrated || !state.positionRad.isFinite() ||
            state.positionRad !in PivotParameters.MIN_ANGLE_RAD..PivotParameters.MAX_ANGLE_RAD
        ) {
            disablePower()
            return
        }
        val status = motor.setControl(request.withPosition(Units.radiansToRotations(state.positionRad)))
        Logger.recordOutput("Pivot/ControlStatus", status.toString())
        controlAlert.set(!status.isOK)
        if (!status.isOK) {
            homed = false
            notHomed.set(true)
            disablePower()
        }
    }

    override fun disablePower() { motor.stopMotor() }
}
