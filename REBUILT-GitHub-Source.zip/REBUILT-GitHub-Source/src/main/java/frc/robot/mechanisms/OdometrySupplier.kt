package frc.robot.mechanisms

import com.limelightvision.Limelight
import com.limelightvision.PoseEstimateType
import frc.robot.mechanisms.drive.Swerve
import frc.robot.utils.PoseLookup
import frc.robot.utils.RobotParameters
import org.littletonrobotics.junction.Logger
import org.wpilib.command3.Mechanism
import org.wpilib.math.estimator.SwerveDrivePoseEstimator
import org.wpilib.math.geometry.Pose2d
import org.wpilib.math.geometry.Rotation2d
import org.wpilib.math.linalg.VecBuilder
import org.wpilib.math.util.Units
import org.wpilib.smartdashboard.Field2d
import org.wpilib.system.Timer
import kotlin.math.atan2

class OdometrySupplier(
    private val swerve: Swerve,
    private val vision: Vision,
    private val now: () -> Double = { Timer.getTimestamp() },
) : Mechanism {
    companion object {
        private const val MAX_VISION_POSE_DIFFERENCE_METERS = 1.0
    }

    private val poseEstimator: SwerveDrivePoseEstimator =
        SwerveDrivePoseEstimator(
            RobotParameters.SwerveParameters.PhysicalParameters.kinematics,
            swerve.gyroYaw,
            swerve.modulePositions,
            Pose2d(),
            VecBuilder.fill(0.05, 0.05, Units.degreesToRadians(5.0)),
            VecBuilder.fill(0.5, 0.5, Units.degreesToRadians(30.0)),
        )

    val pose: Pose2d
        get() = poseEstimator.estimatedPosition

    val field: Field2d = Field2d()
    private var fieldPoseInitialized = false
    private var lastUpdate = Double.NaN
    private var hadDriveFeedback = false

    val readyForShooting: Boolean
        get() {
            val age = now() - lastUpdate
            return fieldPoseInitialized && swerve.readyForAuto && age.isFinite() && age in 0.0..0.1 &&
                pose.x.isFinite() && pose.y.isFinite() && pose.rotation.radians.isFinite()
        }

    fun periodic() {
        val yaw = swerve.gyroYaw
        val modulePositions = swerve.modulePositions
        val timestamp = now()
        if (swerve.readyForAuto && timestamp.isFinite()) {
            if (hadDriveFeedback) {
                poseEstimator.update(yaw, modulePositions)
            } else {
                // Rebase wheel samples after a gap, without claiming the missing travel is known.
                poseEstimator.resetPosition(yaw, modulePositions, pose)
            }
            if (lastUpdate.isFinite() && (timestamp < lastUpdate || timestamp - lastUpdate > 0.1)) {
                fieldPoseInitialized = false
            }
            lastUpdate = timestamp
            hadDriveFeedback = true
        } else {
            fieldPoseInitialized = false
            lastUpdate = Double.NaN
            hadDriveFeedback = false
        }

        // The gyro's boot frame may differ from the explicitly initialized field frame.
        Limelight.setSharedRobotOrientation(pose.rotation.degrees)

        for (camera in vision.cameras) {
            for (estimate in camera.readAcceptedPoseEstimates(PoseEstimateType.MT2_WPIBLUE)) {
                if (fieldPoseInitialized && swerve.readyForAuto && isVisionPoseCloseToEstimate(estimate.pose)) {
                    poseEstimator.addVisionMeasurement(
                        estimate.pose,
                        estimate.timestampSeconds,
                        estimate.stdDevs,
                    )
                }
            }
        }

        field.robotPose = pose
        Logger.recordOutput("Swerve/Pose", pose)
        Logger.recordOutput("Swerve/FieldPoseInitialized", fieldPoseInitialized)
        Logger.recordOutput("Shoot/PoseReady", readyForShooting)
    }

    /** Explicit known field pose, in the WPILib blue-origin frame. Never inferred from boot zero. */
    fun resetPose(pose: Pose2d): Boolean {
        val timestamp = now()
        if (!swerve.readyForAuto || !timestamp.isFinite() || !pose.x.isFinite() || !pose.y.isFinite() ||
            !pose.rotation.radians.isFinite()) {
            fieldPoseInitialized = false
            return false
        }
        poseEstimator.resetPosition(
            swerve.gyroYaw,
            swerve.modulePositions,
            pose,
        )
        fieldPoseInitialized = true
        hadDriveFeedback = true
        lastUpdate = timestamp
        return true
    }

    fun isVisionPoseCloseToEstimate(pose: Pose2d): Boolean =
        pose.x.isFinite() && pose.y.isFinite() && pose.rotation.radians.isFinite() &&
            this.pose.translation.getDistance(pose.translation) <= MAX_VISION_POSE_DIFFERENCE_METERS

    fun getDistanceToPoseMeters(targetPose: Pose2d): Double = pose.translation.getDistance(targetPose.translation)

    /**
     * Distance from the robot's current pose to the hub.
     *
     * @return the distance in meters
     */
    fun getDistanceToHub(): Double = if (readyForShooting) getDistanceToPoseMeters(PoseLookup.hubPose) else Double.NaN

    /**
     * Field relative heading from the robot's current pose to the hub that the robot needs to point
     * at in order to shoot.
     *
     * @return the heading the robot should face
     */
    fun getAngleToHub(): Rotation2d {
        val robot = pose.translation
        val hub = PoseLookup.hubPose.translation
        return Rotation2d.fromRadians(atan2(hub.y - robot.y, hub.x - robot.x))
    }
}
