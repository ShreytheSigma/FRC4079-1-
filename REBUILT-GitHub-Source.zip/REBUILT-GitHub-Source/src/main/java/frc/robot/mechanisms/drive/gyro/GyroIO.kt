package frc.robot.mechanisms.drive.gyro

import frc.robot.utils.logging.ReflectiveLoggableInputs
import org.littletonrobotics.junction.AutoLog
import org.wpilib.math.geometry.Rotation2d

interface GyroIO {
    @AutoLog
    open class GyroIOInputs {
        @JvmField
        var data: GyroIOData =
            GyroIOData(
                connected = false,
                yawPosition = Rotation2d.ZERO,
                yawVelocityRadPerSec = 0.0,
                pitchPosition = Rotation2d.ZERO,
                pitchVelocityRadPerSec = 0.0,
                rollPosition = Rotation2d.ZERO,
                rollVelocityRadPerSec = 0.0,
            )

        @JvmField
        var odometryYawTimestamps: DoubleArray = doubleArrayOf()

        @JvmField
        var odometryYawPositions: Array<Rotation2d> = arrayOf()
    }

    data class GyroIOData(
        var connected: Boolean,
        var yawPosition: Rotation2d,
        var yawVelocityRadPerSec: Double,
        var pitchPosition: Rotation2d,
        var pitchVelocityRadPerSec: Double,
        var rollPosition: Rotation2d,
        var rollVelocityRadPerSec: Double,
    ) : ReflectiveLoggableInputs()

    fun updateInputs(inputs: GyroIOInputs) {}

    fun reset() {}
}
