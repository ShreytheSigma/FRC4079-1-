package frc.robot.mechanisms.drive.module

import frc.robot.utils.RobotParameters.SwerveParameters.PhysicalParameters
import org.wpilib.math.controller.PIDController
import org.wpilib.math.geometry.Rotation2d
import org.wpilib.math.system.DCMotor
import org.wpilib.math.system.Models
import org.wpilib.simulation.DCMotorSim

/** Mechanism physics for software tests, not a model of measured tire friction or robot mass. */
class SimModuleIO : ModuleIO {
    private val driveMotor = DCMotor.getKrakenX60Foc(1)
    // Preserve the supplied code's motor model; CAD materials are not authoritative.
    private val turnMotor = DCMotor.getKrakenX60Foc(1)
    private val drive = DCMotorSim(Models.singleJointedArmFromPhysicalConstants(driveMotor, 0.025, PhysicalParameters.DRIVE_MOTOR_GEAR_RATIO), driveMotor)
    private val turn = DCMotorSim(Models.singleJointedArmFromPhysicalConstants(turnMotor, 0.004, PhysicalParameters.STEER_MOTOR_GEAR_RATIO), turnMotor)
    private val driveController = PIDController(0.1, 0.0, 0.0)
    private val turnController = PIDController(8.0, 0.0, 0.1).apply { enableContinuousInput(-Math.PI, Math.PI) }
    private var driveTarget: Double? = null
    private var turnTarget: Double? = null
    private var driveVolts = 0.0
    private var turnVolts = 0.0

    override fun updateInputs(inputs: ModuleIO.ModuleIOInputs) {
        driveTarget?.let {
            driveVolts = driveController.calculate(drive.angularVelocity, it) + it * PhysicalParameters.DRIVE_MOTOR_GEAR_RATIO / driveMotor.Kv
        }
        turnTarget?.let { turnVolts = turnController.calculate(turn.angularPosition, it) }
        driveVolts = driveVolts.coerceIn(-12.0, 12.0)
        turnVolts = turnVolts.coerceIn(-12.0, 12.0)
        drive.setInputVoltage(driveVolts)
        turn.setInputVoltage(turnVolts)
        drive.update(0.02)
        turn.update(0.02)
        inputs.data.driveConnected = true
        inputs.data.turnConnected = true
        inputs.data.turnEncoderConnected = true
        inputs.data.drivePositionRad = drive.angularPosition
        inputs.data.driveVelocityRadPerSec = drive.angularVelocity
        inputs.data.driveAppliedVolts = driveVolts
        inputs.data.turnPosition = Rotation2d.fromRadians(turn.angularPosition)
        inputs.data.turnAbsolutePosition = inputs.data.turnPosition
        inputs.data.turnVelocityRadPerSec = turn.angularVelocity
        inputs.data.turnAppliedVolts = turnVolts
        inputs.odometryDrivePositionsRad = doubleArrayOf(drive.angularPosition)
        inputs.odometryTurnPositions = arrayOf(inputs.data.turnPosition)
    }

    override fun runDriveOpenLoop(output: Double) { driveTarget = null; driveVolts = output; driveController.reset() }
    override fun runTurnOpenLoop(output: Double) { turnTarget = null; turnVolts = output; turnController.reset() }
    override fun runDriveVelocity(velocityRadPerSec: Double, feedforward: Double) { driveTarget = velocityRadPerSec }
    override fun runTurnPosition(rotation: Rotation2d) { turnTarget = rotation.radians }
}
