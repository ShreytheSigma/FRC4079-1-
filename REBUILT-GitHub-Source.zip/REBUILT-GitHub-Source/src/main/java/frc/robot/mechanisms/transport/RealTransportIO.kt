package frc.robot.mechanisms.transport

import com.ctre.phoenix6.BaseStatusSignal
import com.ctre.phoenix6.CANBus
import com.ctre.phoenix6.StatusCode
import com.ctre.phoenix6.StatusSignal
import com.ctre.phoenix6.configs.Slot0Configs
import com.ctre.phoenix6.configs.TalonFXConfiguration
import com.ctre.phoenix6.controls.VelocityVoltage
import com.ctre.phoenix6.hardware.ParentDevice
import com.ctre.phoenix6.hardware.TalonFX
import com.ctre.phoenix6.signals.InvertedValue
import com.ctre.phoenix6.signals.NeutralModeValue
import frc.robot.utils.RobotParameters
import frc.robot.utils.RobotParameters.TransportParameters
import frc.robot.utils.phoenix.PhoenixConfiguration
import org.littletonrobotics.junction.Logger
import org.wpilib.math.util.Units
import org.wpilib.units.measure.Angle

class RealTransportIO () : TransportIO {
    private var configured = false
    private var connected = false
    private val indexerTalon = TalonFX(RobotParameters.TransportParameters.indexerMotor, CANBus(RobotParameters.TransportParameters.INDEXER_CANPORT))
    private val indexerConfig = TalonFXConfiguration()
    private val indexerVelocityRequest: VelocityVoltage = VelocityVoltage(0.0).withSlot(0)

    private val hopperTalon = TalonFX(RobotParameters.TransportParameters.hopperMotor, CANBus(RobotParameters.TransportParameters.HOPPER_CANPORT))
    private val hopperConfig = TalonFXConfiguration()
    private val hopperVelocityRequest: VelocityVoltage = VelocityVoltage(0.0).withSlot(0)

    private val indexerPosition: StatusSignal<Angle>
    private val hopperPosition: StatusSignal<Angle>
    private val indexerVelocity = indexerTalon.velocity
    private val indexerVoltage = indexerTalon.motorVoltage
    private val indexerSupplyCurrent = indexerTalon.supplyCurrent
    private val indexerTorqueCurrent = indexerTalon.torqueCurrent
    private val hopperVelocity = hopperTalon.velocity
    private val hopperVoltage = hopperTalon.motorVoltage
    private val hopperSupplyCurrent = hopperTalon.supplyCurrent
    private val hopperTorqueCurrent = hopperTalon.torqueCurrent

    init {
        // Configure indexer motor ouughh...
        indexerConfig.MotorOutput.NeutralMode = NeutralModeValue.Brake
        indexerConfig.MotorOutput.Inverted = InvertedValue.Clockwise_Positive

        indexerConfig.Slot0 =
            Slot0Configs()
                .withKP(TransportParameters.PIDParameters.INDEXER_PID.p)
                .withKI(TransportParameters.PIDParameters.INDEXER_PID.i)
                .withKD(TransportParameters.PIDParameters.INDEXER_PID.d)
        indexerConfig.Feedback.SensorToMechanismRatio = TransportParameters.INDEXER_GEAR_RATIO

        // TODO: Replace these values with real values
        indexerConfig.TorqueCurrent.PeakForwardTorqueCurrent = TransportParameters.PhysicalParameters.TRANSPORT_CURRENT_LIMIT
        indexerConfig.TorqueCurrent.PeakReverseTorqueCurrent = -TransportParameters.PhysicalParameters.TRANSPORT_CURRENT_LIMIT
        indexerConfig.CurrentLimits.StatorCurrentLimit = TransportParameters.PhysicalParameters.TRANSPORT_CURRENT_LIMIT
        indexerConfig.CurrentLimits.StatorCurrentLimitEnable = true
        indexerConfig.ClosedLoopRamps.VoltageClosedLoopRampPeriod = 0.02

        val indexerConfigured = PhoenixConfiguration.apply("Transport indexer") {
            indexerTalon.configurator.apply(indexerConfig, 0.25)
        }

        // Configure hopper motor ouughh...
        hopperConfig.MotorOutput.NeutralMode = NeutralModeValue.Brake
        hopperConfig.MotorOutput.Inverted = InvertedValue.Clockwise_Positive

        hopperConfig.Slot0 =
            Slot0Configs()
                .withKP(TransportParameters.PIDParameters.HOPPER_PID.p)
                .withKI(TransportParameters.PIDParameters.HOPPER_PID.i)
                .withKD(TransportParameters.PIDParameters.HOPPER_PID.d)
        hopperConfig.Feedback.SensorToMechanismRatio = TransportParameters.HOPPER_GEAR_RATIO

        // TODO: Replace these values with real values
        hopperConfig.TorqueCurrent.PeakForwardTorqueCurrent = TransportParameters.PhysicalParameters.TRANSPORT_CURRENT_LIMIT
        hopperConfig.TorqueCurrent.PeakReverseTorqueCurrent = -TransportParameters.PhysicalParameters.TRANSPORT_CURRENT_LIMIT
        hopperConfig.CurrentLimits.StatorCurrentLimit = TransportParameters.PhysicalParameters.TRANSPORT_CURRENT_LIMIT
        hopperConfig.CurrentLimits.StatorCurrentLimitEnable = true
        hopperConfig.ClosedLoopRamps.VoltageClosedLoopRampPeriod = 0.02

        val hopperConfigured = PhoenixConfiguration.apply("Transport hopper") {
            hopperTalon.configurator.apply(hopperConfig, 0.25)
        }
        configured = indexerConfigured && hopperConfigured

        // Configure signals
        indexerPosition = indexerTalon.position
        hopperPosition = hopperTalon.position
        BaseStatusSignal.setUpdateFrequencyForAll(
            50.0,
            indexerPosition,
            hopperPosition,
            indexerVelocity, indexerVoltage, indexerSupplyCurrent, indexerTorqueCurrent,
            hopperVelocity, hopperVoltage, hopperSupplyCurrent, hopperTorqueCurrent,
        )

        ParentDevice.optimizeBusUtilizationForAll(indexerTalon, hopperTalon)


    }

    override fun updateInputs(inputs: TransportIO.TransportIOInputs) {
        BaseStatusSignal.refreshAll(
            indexerPosition, indexerVelocity, indexerVoltage, indexerSupplyCurrent, indexerTorqueCurrent,
            hopperPosition, hopperVelocity, hopperVoltage, hopperSupplyCurrent, hopperTorqueCurrent,
        )
        inputs.data.indexerConnected =
            configured && BaseStatusSignal.isAllGood(
                indexerPosition,
                indexerVelocity, indexerVoltage, indexerSupplyCurrent, indexerTorqueCurrent,
            )
        inputs.data.indexerPositionRad = Units.rotationsToRadians(indexerPosition.valueAsDouble)
        inputs.data.indexerAppliedVolts = indexerVoltage.valueAsDouble
        inputs.data.indexerSupplyCurrentAmps = indexerSupplyCurrent.valueAsDouble
        inputs.data.indexerTorqueCurrentAmps = indexerTorqueCurrent.valueAsDouble
        inputs.data.indexerVelocityRadPerSec = Units.rotationsToRadians(indexerVelocity.valueAsDouble)

        inputs.data.hopperConnected =
            configured && BaseStatusSignal.isAllGood(
                hopperPosition,
                hopperVelocity, hopperVoltage, hopperSupplyCurrent, hopperTorqueCurrent,
            )
        inputs.data.hopperPositionRad = Units.rotationsToRadians(hopperPosition.valueAsDouble)
        inputs.data.hopperAppliedVolts = hopperVoltage.valueAsDouble
        inputs.data.hopperSupplyCurrentAmps = hopperSupplyCurrent.valueAsDouble
        inputs.data.hopperTorqueCurrentAmps = hopperTorqueCurrent.valueAsDouble
        inputs.data.hopperVelocityRadPerSec = Units.rotationsToRadians(hopperVelocity.valueAsDouble)
        connected = inputs.data.indexerConnected && inputs.data.hopperConnected
        if (!connected) disablePower()
    }

    /**
     * Sets the velocity of the transport motors based on state.
     *
     * @param state The desired state of the pivot.
     */
    override fun setTransportState(state: TransportIO.TransportState) {
        if (!connected || state == TransportIO.TransportState.STOP) { disablePower(); return }
        val hopperStatus = hopperTalon.setControl(hopperVelocityRequest.withVelocity(Units.radiansToRotations(state.velocityRadPerSec)))
        val indexerStatus = indexerTalon.setControl(indexerVelocityRequest.withVelocity(Units.radiansToRotations(state.velocityRadPerSec)))
        Logger.recordOutput("Transport/HopperControlStatus", hopperStatus.toString())
        Logger.recordOutput("Transport/IndexerControlStatus", indexerStatus.toString())
        if (!hopperStatus.isOK || !indexerStatus.isOK) disablePower()
    }

    override fun disablePower() {
        hopperTalon.stopMotor()
        indexerTalon.stopMotor()
    }

//    override fun setVoltage(volts: Double) {
//        intakeMotor.setControl(voltageControl.withOutput(volts))
//    }
//
//    override fun setPosition(positionRad: Double) {
//        intakeMotor.setControl(positionControl.withPosition(positionRad))
//    }
//
//    override fun setVelocity(velocityRadPerSec: Double) {
//        intakeMotor.setControl(velocityControl.withVelocity(velocityRadPerSec))
//    }

    override fun setHopperPID(
        hopkP: Double,
        hopkI: Double,
        hopkD: Double,
    ) {
        hopperConfig.Slot0.kP = hopkP
        hopperConfig.Slot0.kI = hopkI
        hopperConfig.Slot0.kD = hopkD

            for (i in 0..4) {
                if (hopperTalon.configurator.apply(hopperConfig.Slot0, 0.25).isOK) break
            }
    }

    override fun setIndexerPID(
        indkP: Double,
        indkI: Double,
        indkD: Double,
    ) {
        indexerConfig.Slot0.kP = indkP
        indexerConfig.Slot0.kI = indkI
        indexerConfig.Slot0.kD = indkD
        for (i in 0..4) {
            if (indexerTalon.configurator.apply(indexerConfig.Slot0, 0.25).isOK) break
        }
    }
//
//    override fun stop() {
//        intakeMotor.setControl(voltageControl.withOutput(0.0))
//    }

}
