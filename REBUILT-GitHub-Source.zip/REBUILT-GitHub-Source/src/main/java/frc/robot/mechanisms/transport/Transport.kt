package frc.robot.mechanisms.transport

import org.littletonrobotics.junction.Logger
import org.wpilib.command3.Mechanism
import org.wpilib.math.filter.Debouncer
import org.wpilib.util.Alert

class Transport (
    private val io: TransportIO,
    private val readyToFeed: () -> Boolean = { false },
): Mechanism {
    private val inputs = TransportIOInputsAutoLogged()
    private var targetState = TransportIO.TransportState.STOP

    // Connected debouncers
    private val motorConnectedDebouncer: Debouncer = Debouncer(0.5, Debouncer.DebounceType.FALLING)

    // Connection alerts
    private val alertType: String = "Transport Alerts"
    private val transportDisconnectedAlert: Alert

    init {
        transportDisconnectedAlert =
            Alert(alertType, "One of the transport motors is down oouuughhhhh", Alert.Level.MEDIUM)
    }

    fun periodic() {
        updateInputs()
        applyOutputs()
    }

    fun updateInputs() {
        io.updateInputs(inputs)
        Logger.processInputs("Transport", inputs)

        transportDisconnectedAlert.set(!motorConnectedDebouncer.calculate(inputs.data.hopperConnected && inputs.data.indexerConnected))

    }

    /** Called after the scheduler, so canceled or invalid shots cannot leave the feeder running. */
    fun applyOutputs() {
        val allowed = targetState != TransportIO.TransportState.STOP && readyToFeed()
        Logger.recordOutput("Transport/FeedPermitted", allowed)
        if (allowed) io.setTransportState(targetState) else io.disablePower()
    }

    fun setState(state: TransportIO.TransportState) {
        targetState = state
        inputs.data.transportState = state
    }

    fun disable() {
        setState(TransportIO.TransportState.STOP)
        io.disablePower()
    }
}
