package frc.robot.mechanisms.hood

import org.littletonrobotics.junction.Logger
import org.wpilib.command3.Mechanism
import org.wpilib.math.filter.Debouncer
import org.wpilib.util.Alert

class Hood(
    private val io: HoodIO
) : Mechanism {
    private val inputs = HoodIOInputsAutoLogged()
    private var targetPositionRad: Double? = null

    // Connected debouncer
    private val hoodMotorConnectedDebouncer: Debouncer = Debouncer(0.5, Debouncer.DebounceType.FALLING)

    // Connection alerts
    private val alertType: String = "Hood Alerts"
    private val hoodDisconnectedAlert: Alert

    init {
        hoodDisconnectedAlert =
            Alert(alertType, "Disconnected hood motor.", Alert.Level.MEDIUM)
    }

    fun periodic() {
        io.updateInputs(inputs)
        Logger.processInputs("Hood", inputs)

        hoodDisconnectedAlert.set(!hoodMotorConnectedDebouncer.calculate(inputs.data.hoodConnected))

        val target = targetPositionRad
        if (target != null) {
            setPosition(target)
        }
    }

    fun setState(state: HoodIO.HoodPositionState) {
        inputs.data.hoodPositionState = state
        setPosition(state.positionRad)
    }

    fun setPosition(positionRad: Double) {
        if (!positionRad.isFinite()) { disable(); return }
        targetPositionRad = positionRad
        io.setPosition(positionRad)
        if (!io.isPositionRequestAccepted(positionRad)) disable()
    }

    fun setPower(power: Double) {
        targetPositionRad = null
        inputs.data.positionControlReady = false
        io.setPower(power)
    }

    val atPosition: Boolean
        get() = targetPositionRad?.let {
            io.isPositionRequestAccepted(it) && inputs.data.hoodConnected && inputs.data.positionControlReady &&
                kotlin.math.abs(inputs.data.hoodPositionRad - it) <= Math.toRadians(2.0)
        } ?: false

    fun disable() {
        targetPositionRad = null
        inputs.data.positionControlReady = false
        io.disablePower()
        inputs.data.hoodPositionState = HoodIO.HoodPositionState.HOME
    }

    fun zeroAtHome(): Boolean {
        disable()
        return io.zeroAtHome()
    }
}
