package frc.robot.mechanisms.shooter

import frc.robot.utils.enums.State
import org.littletonrobotics.junction.Logger
import org.wpilib.command3.Mechanism
import org.wpilib.math.filter.Debouncer
import org.wpilib.util.Alert

class Shooter(
    private val io: ShooterIO,
) : Mechanism {
    private val inputs = ShooterIOInputsAutoLogged()
    private var targetVelocityRadPerSec: Double? = null

    // Connected debouncers
    private val topMotorConnectedDebouncer: Debouncer = Debouncer(0.5, Debouncer.DebounceType.FALLING)
    private val bottomMotorConnectedDebouncer: Debouncer = Debouncer(0.5, Debouncer.DebounceType.FALLING)

    // Connection alerts
    private val alertType: String = "Shooter Alerts"
    private val topDisconnectedAlert: Alert
    private val bottomDisconnectedAlert: Alert

    init {
        topDisconnectedAlert = Alert("$alertType - Top", "Disconnected top shooter motor.", Alert.Level.MEDIUM)
        bottomDisconnectedAlert = Alert("$alertType - Bottom", "Disconnected bottom shooter motor.", Alert.Level.MEDIUM)
    }

    fun periodic() {
        io.updateInputs(inputs)
        Logger.processInputs("Shooter", inputs)

        topDisconnectedAlert.set(!topMotorConnectedDebouncer.calculate(inputs.data.topMotorConnected))
        bottomDisconnectedAlert.set(!bottomMotorConnectedDebouncer.calculate(inputs.data.bottomMotorConnected))

        val target = targetVelocityRadPerSec
        if (target != null) {
            io.setVelocity(target)
        }
    }

    fun setState(state: ShooterIO.ShooterState) {
        inputs.data.shooterState = state
        if (state == ShooterIO.ShooterState.IDLE) disable() else setVelocity(state.velocityRadPerSec)
    }

    fun setVelocity(velocityRadPerSec: Double) {
        if (!velocityRadPerSec.isFinite()) { disable(); return }
        targetVelocityRadPerSec = velocityRadPerSec
        io.setVelocity(velocityRadPerSec)
    }

    val atSpeed: Boolean
        get() {
            val target = targetVelocityRadPerSec ?: return false
            val tolerance = maxOf(10.0, kotlin.math.abs(target) * 0.05)
            return target > 0.0 && io.isVelocityRequestAccepted(target) &&
                inputs.data.topMotorConnected && inputs.data.bottomMotorConnected &&
                kotlin.math.abs(inputs.data.topVelocityRadPerSec - target) <= tolerance &&
                kotlin.math.abs(inputs.data.bottomVelocityRadPerSec - target) <= tolerance
        }

    fun setPower(
        topPower: Double,
        bottomPower: Double,
    ) {
        targetVelocityRadPerSec = null
        io.setPower(topPower, bottomPower)
    }

    fun disable() {
        targetVelocityRadPerSec = null
        io.disablePower()
        inputs.data.shooterState = ShooterIO.ShooterState.IDLE
    }
}
