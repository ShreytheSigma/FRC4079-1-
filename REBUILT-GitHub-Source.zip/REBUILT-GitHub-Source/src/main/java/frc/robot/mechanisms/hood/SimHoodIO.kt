package frc.robot.mechanisms.hood

import frc.robot.utils.RobotParameters
import org.wpilib.driverstation.RobotState
import org.wpilib.math.controller.PIDController
import org.wpilib.math.system.DCMotor
import org.wpilib.math.system.Models
import org.wpilib.simulation.DCMotorSim
import java.lang.Math.clamp
import kotlin.math.abs

class SimHoodIO(
    private val calibration: HoodCalibration = HoodCalibration(),
) : HoodIO {
    private val hoodMotorModel: DCMotor = DCMotor.getKrakenX60Foc(1)

    private val hoodSim =
        DCMotorSim(
            Models.singleJointedArmFromPhysicalConstants(
                hoodMotorModel,
                0.1,
                calibration.gearRatio.takeIf { it.isFinite() && it > 0.0 } ?: 1.0,
            ),
            hoodMotorModel,
        )

    private var closedLoop = false
    private val hoodController = PIDController(RobotParameters.HoodParameters.PIDParameters.HOOD_PID.p / (2.0 * Math.PI), 0.0, 0.0)
    private var targetPositionRad = 0.0
    private var hoodAppliedVolts = 0.0
    private val safety = HoodPositionSafety(calibration) {
        closedLoop = false
        hoodAppliedVolts = 0.0
        hoodSim.setInputVoltage(0.0)
        hoodController.reset()
    }

    init {
        if (calibration.valid) hoodSim.setState(calibration.homeAngleRad, 0.0)
    }

    override fun updateInputs(inputs: HoodIO.HoodIOInputs) {
        if (!safety.homed || !calibration.valid) disablePower()
        if (closedLoop) {
            hoodAppliedVolts = hoodController.calculate(hoodSim.angularPosition, targetPositionRad)
            hoodAppliedVolts = clamp(hoodAppliedVolts, -12.0, 12.0)
        } else {
            hoodController.reset()
        }

        hoodAppliedVolts = limitVoltage(hoodAppliedVolts)
        hoodSim.setInputVoltage(hoodAppliedVolts)
        hoodSim.update(0.02)

        // DCMotorSim has no mechanical stops; constrain both travel and outward velocity.
        if (calibration.valid) {
            val position = hoodSim.angularPosition.coerceIn(calibration.minAngleRad, calibration.maxAngleRad)
            val velocity = hoodSim.angularVelocity
            val atStop = (position <= calibration.minAngleRad && velocity < 0.0) ||
                (position >= calibration.maxAngleRad && velocity > 0.0)
            if (position != hoodSim.angularPosition || atStop) {
                hoodSim.setState(position, if (atStop) 0.0 else velocity)
            }
            hoodAppliedVolts = limitVoltage(hoodAppliedVolts)
            hoodSim.setInputVoltage(hoodAppliedVolts)
        }

        inputs.data.hoodConnected = true
        inputs.data.positionControlReady = safety.positionControlReady
        inputs.data.hoodPositionRad = hoodSim.angularPosition
        inputs.data.hoodVelocityRadPerSec = hoodSim.angularVelocity
        inputs.data.hoodAppliedVolts = hoodAppliedVolts
        inputs.data.hoodSupplyCurrentAmps = abs(hoodSim.currentDraw)
        inputs.data.hoodTorqueCurrentAmps = 0.0
    }

    override fun setPower(power: Double) {
        safety.requestPower(power, true) {
            closedLoop = false
            hoodAppliedVolts = limitVoltage(it * 12.0)
            hoodSim.setInputVoltage(hoodAppliedVolts)
            true
        }
    }

    override fun setHoodState(state: HoodIO.HoodPositionState) {
        setPosition(state.positionRad)
    }

    override fun setPosition(positionRad: Double) {
        safety.requestPosition(positionRad, true) {
            closedLoop = true
            targetPositionRad = it
            true
        }
    }

    override fun isPositionRequestAccepted(positionRad: Double): Boolean =
        safety.isPositionRequestAccepted(positionRad)

    override fun zeroAtHome(): Boolean = safety.home(RobotState.isDisabled(), true) {
        hoodSim.setState(calibration.homeAngleRad, 0.0)
        true
    }

    fun simulateMotorReset() { safety.invalidateHome() }

    override fun disablePower() {
        safety.stop()
    }

    private fun limitVoltage(volts: Double): Double {
        if (!calibration.valid || !volts.isFinite()) return 0.0
        if (hoodSim.angularPosition <= calibration.minAngleRad && volts < 0.0) return 0.0
        if (hoodSim.angularPosition >= calibration.maxAngleRad && volts > 0.0) return 0.0
        return volts
    }
}
